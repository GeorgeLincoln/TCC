### Downloads

1.  Baixar o [Visual Studio Code](https://code.visualstudio.com)
2.  Baixar o [NodeJs](https://nodejs.org/en/)
3.  Baixar o [Git](https://git-scm.com)
4.  Clonar o repositório `https://github.com/cleitianne/SAGA.git`
5.  Entrar na pasta do Projeto `cd webapp`
6.  Baixar todas as dependências `npm install`
