const state = {
  main: [
    {
      id: 1,
      body: 'Message 1'
    },
    {
      id: 2,
      body: 'Message 2'
    },
    {
      id: 3,
      body: 'Message 3'
    },
    {
      id: 4,
      body: 'Message 4'
    },
    {
      id: 5,
      body: 'Message 5'
    },
    {
      id: 5,
      body: 'Message 5'
    }
  ]
}

const mutations = {

}

export default {
  state,
  mutations
}
