import products from './products'

export default {
  products
}
