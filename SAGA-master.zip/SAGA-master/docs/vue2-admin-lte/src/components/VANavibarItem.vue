<template>
  <li class="dropdown">
  </li>
</template>

<script>
export default {
  name: 'va-navibar-item',
  created () {

  }
}
</script>

<style>
</style>
