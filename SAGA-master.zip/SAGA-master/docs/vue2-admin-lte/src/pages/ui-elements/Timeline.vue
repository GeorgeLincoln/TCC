<template>
  <div>
    Timeline Page
  </div>
</template>

<script>
export default {
  name: 'Timeline',
  created () {

  }
}
</script>
