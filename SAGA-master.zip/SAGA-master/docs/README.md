﻿![TeamsLux](http://app.teamslux.com/img/lux-logo.svg)

# Configuração

Abaixo um breve passo a passo para preparar o ambiente de trabalho. Será
interessante manter a organização no código, para isso vamos padronizar nossa
escrita com o Standard.

### Downloads

1. Baixar o [Visual Studio Code](https://code.visualstudio.com)
2. Baixar o [NodeJs](https://nodejs.org/en/)
3. Baixar o [Git](https://git-scm.com)
4. Clonar o repositório `git clone https://teamsifce@bitbucket.org/luxtiembrapii/teams-front.git`
5. Entrar na pasta do Projeto `cd teams-front`
6. Baixar todas as dependências `npm install`

### Extensões para o Visual Studio Code

Com o atalho (Ctrl+;) abra a aba de extensões e pesquise e instale:

1. [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
2. [Prettier - JavaScript formatter](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
3. [Vetur](https://marketplace.visualstudio.com/items?itemName=octref.vetur)
4. [vscode-icons](https://marketplace.visualstudio.com/items?itemName=robertohuertasm.vscode-icons)
5. [Beautify](https://marketplace.visualstudio.com/items?itemName=HookyQR.beautify)

### Integrar as Extensões com a IDE

Tecle (Ctrl+,) e insira o código abaixo na coluna a direita

```
{
  "workbench.iconTheme": "vscode-icons",
  "editor.tabSize": 2,
  "editor.formatOnSave": true,
  "prettier.eslintIntegration": true,
  "prettier.trailingComma": "all",
  "prettier.singleQuote": true,
  "git.confirmSync": false,
  "terminal.integrated.shell.windows": "C:\\Program Files\\Git\\bin\\bash.exe",
  "beautify.language": {
    "html": ["htm", "html", "vue"]
  }
}
```

### Beautify selection

Há duas maneiras de se chegar nesta configuração:

1. `File` > `Preferences` > `Keyboard Shortcuts`
2. Tecle `Ctrl + K` e após `Ctrl + S` Já na tela de configuração de atalhos,
   procure por `Beautify selection` e defina um atalho de sua escolha,
   particularmente optei por `Ctrl + Shift + B`. Salve sua configuração e sempre
   que quiser identar seu código, tecle seu atalho escolhido anteriormente e
   selecione a opção HTML, logo após, tecle `Ctrl + S` para que o `Prettier`
   idente seu JS e CSS da maneira adequada.

##### Links úteis

1. [VueJs documentação](https://br.vuejs.org/v2/guide/)
2. [Material Icons](https://material.io/icons/)
3. [Bootstrap](https://getbootstrap.com/docs/3.3/components/)

[![JavaScript Style Guide](https://cdn.rawgit.com/standard/standard/master/badge.svg)](https://github.com/standard/standard)

Estamos Utilizando o JavaScript Standard Style Guide, para mais detalhes sobre o
padrão de estilo no código, consulte a
[documentação](https://standardjs.com/rules-ptbr.html)

## Ícones

Para adicionar um ícone ao sistema, é necessário definir a classe `.icon-lux` a
um determinado elemento, preferencialmente um `<i>` e informar qual o nome do
ícone desejado. Para ilustração será incluso um ícone de grupo chamado `group`.
Veja o exemplo abaixo:

```html
<i class="icon-lux">group</i>
```

O resultado produzido será ![group](static/icons/group.svg).

### Coleção `.icon-lux`

> Atualmente contamos com 71 ícones, listados abaixo

* ![playlist_play](static/icons/playlist_play.svg) `playlist_play`
* ![menu](static/icons/menu.svg) `menu`
* ![checkbox_marked](static/icons/checkbox_marked.svg) `checkbox_marked`
* ![right](static/icons/right.svg) `right`
* ![close](static/icons/close.svg) `close`
* ![delete](static/icons/delete.svg) `delete`
* ![link](static/icons/link.svg) `link`
* ![at](static/icons/at.svg) `at`
* ![play_circle](static/icons/play_circle.svg) `play_circle`
* ![exit_to_app](static/icons/exit_to_app.svg) `exit_to_app`
* ![file_document_box](static/icons/file_document_box.svg) `file_document_box`
* ![file_chart](static/icons/file_chart.svg) `file_chart`
* ![account](static/icons/account.svg) `account`
* ![add_box](static/icons/add_box.svg) `add_box`
* ![add_circle](static/icons/add_circle.svg) `add_circle`
* ![apps](static/icons/apps.svg) `apps`
* ![arrow_back](static/icons/arrow_back.svg) `arrow_back`
* ![attach_file](static/icons/attach_file.svg) `attach_file`
* ![attachment](static/icons/attachment.svg) `attachment`
* ![border_all](static/icons/border_all.svg) `border_all`
* ![check_circle](static/icons/check_circle.svg) `check_circle`
* ![comment](static/icons/comment.svg) `comment`
* ![contact_calendar](static/icons/contact_calendar.svg) `contact_calendar`
* ![contacts](static/icons/contacts.svg) `contacts`
* ![create](static/icons/create.svg) `create`
* ![dashboard](static/icons/dashboard.svg) `dashboard`
* ![date_range](static/icons/date_range.svg) `date_range`
* ![description](static/icons/description.svg) `description`
* ![done](static/icons/done.svg) `done`
* ![edit](static/icons/edit.svg) `edit`
* ![error](static/icons/error.svg) `error`
* ![error_outline](static/icons/error_outline.svg) `error_outline`
* ![event](static/icons/event.svg) `event`
* ![extension](static/icons/extension.svg) `extension`
* ![file_download](static/icons/file_download.svg) `file_download`
* ![group](static/icons/group.svg) `group`
* ![help](static/icons/help.svg) `help`
* ![highlight_off](static/icons/highlight_off.svg) `highlight_off`
* ![info](static/icons/info.svg) `info`
* ![insert_chart](static/icons/insert_chart.svg) `insert_chart`
* ![insert_invitation](static/icons/insert_invitation.svg) `insert_invitation`
* ![label](static/icons/label.svg) `label`
* ![lan](static/icons/lan.svg) `lan`
* ![lead-pencil](static/icons/lead-pencil.svg) `lead-pencil`
* ![local_offer](static/icons/local_offer.svg) `local_offer`
* ![media](static/icons/media.svg) `media`
* ![message](static/icons/message.svg) `message`
* ![mode_edit](static/icons/mode_edit.svg) `mode_edit`
* ![my_location](static/icons/my_location.svg) `my_location`
* ![notifications_none](static/icons/notifications_none.svg)
  `notifications_none`
* ![pencil](static/icons/pencil.svg) `pencil`
* ![person](static/icons/person.svg) `person`
* ![photo](static/icons/photo.svg) `photo`
* ![picture_as_pdf](static/icons/picture_as_pdf.svg) `picture_as_pdf`
* ![radio_button_checked](static/icons/radio_button_checked.svg)
  `radio_button_checked`
* ![reorder](static/icons/reorder.svg) `reorder`
* ![search](static/icons/search.svg) `search`
* ![send](static/icons/send.svg) `send`
* ![settings](static/icons/settings.svg) `settings`
* ![settings_phone](static/icons/settings_phone.svg) `settings_phone`
* ![sitemap](static/icons/sitemap.svg) `sitemap`
* ![timeline](static/icons/timeline.svg) `timeline`
* ![trending_up](static/icons/trending_up.svg) `trending_up`
* ![update](static/icons/update.svg) `update`
* ![view_column](static/icons/view_column.svg) `view_column`
* ![view_comfy](static/icons/view_comfy.svg) `view_comfy`
* ![view_quilt](static/icons/view_quilt.svg) `view_quilt`
* ![view_week](static/icons/view_week.svg) `view_week`
* ![visibility](static/icons/visibility.svg) `visibility`
* ![warning](static/icons/warning.svg) `warning`
* ![widgets](static/icons/widgets.svg) `widgets`

## Regras

* **Use 2 espaços** para identação.

```js
function hello(name) {
  console.log('oi', name);
}
```

* **Use aspas simples para strings** exceto para evitar escapamento.

```js
console.log('olá, meu povo');
$("<div class='box'>");
```

* **Sem variáveis não-utilizadas.**

```js
function myFunction() {
  var result = something(); // ✗ evite
}
```

* **Adicione um espaço após as keywords.**

```js
if (condition) { ... }   // ✓ ok
if(condition) { ... }    // ✗ evite
```

* **Adicione um espaço antes do parêntese de declaração de funções.**

```js
function name (arg) { ... }   // ✓ ok
function name(arg) { ... }    // ✗ evite

run(function () { ... })      // ✓ ok
run(function() { ... })       // ✗ evite
```

* **Sempre use** `===` ao invés de `==`. Exceção: `obj == null` é permitido pra
  checar se `null || undefined`.

```js
if (name === 'John')   // ✓ ok
if (name == 'John')    // ✗ evite
```

```js
if (name !== 'John')   // ✓ ok
if (name != 'John')    // ✗ evite
```

* **Operadores infix** devem ser espaçados.

```js
// ✓ ok
var x = 2;
var message = 'hello, ' + name + '!';
```

```js
// ✗ evite
var x = 2;
var message = 'hello, ' + name + '!';
```

* **Vírgulas devem ter um espaço** depois delas.

```js
// ✓ ok
var list = [1, 2, 3, 4]
function greet (name, options) { ... }
```

```js
// ✗ evite
var list = [1,2,3,4]
function greet (name,options) { ... }
```

* **Mantenha os else** na mesma linha das suas chaves.

```js
// ✓ ok
if (condition) {
  // ...
} else {
  // ...
}
```

```js
// ✗ evite
if (condition) {
  // ...
} else {
  // ...
}
```

* **Para ifs com mais de uma linha,** use chaves.

```js
// ✓ ok
if (options.quiet !== true) console.log('done');
```

```js
// ✓ ok
if (options.quiet !== true) {
  console.log('done');
}
```

```js
// ✗ evite
if (options.quiet !== true) console.log('done');
```

* **Sempre lide** com o parâmetro `err` .

```js
// ✓ ok
run(function(err) {
  if (err) throw err;
  window.alert('done');
});
```

```js
// ✗ evite
run(function(err) {
  window.alert('done');
});
```

* **Sempre prefixe globais de browser** com `window.`. Exceções: `document`,
  `console` e `navigator`.

```js
window.alert('hi'); // ✓ ok
```

* **Não é permitido múltiplas linhas em branco.**

```js
// ✓ ok
var value = 'hello world';
console.log(value);
```

```js
// ✗ evite
var value = 'hello world';

console.log(value);
```

* **Se for usar operador ternário** em múltiplas linhas, deixe `?` e `:` em suas
  próprias linhas.

```js
// ✓ ok
var location = env.development ? 'localhost' : 'www.api.com';

// ✓ ok
var location = env.development ? 'localhost' : 'www.api.com';

// ✗ evite
var location = env.development ? 'localhost' : 'www.api.com';
```

* **Para declarações de var**, escreva cada declaração na sua própria instrução.

```js
// ✓ ok
var silent = true;
var verbose = true;

// ✗ evite
var silent = true,
  verbose = true;

// ✗ evite
var silent = true,
  verbose = true;
```

* **Coloque parẽnteses adicionais** em declarações em condições. Isso torna mais
  claro que a expressão é uma declaração (`=`) e não um typo de equidade (`===`)

```js
// ✓ ok
while ((m = text.match(expr))) {
  // ...
}

// ✗ evite
while ((m = text.match(expr))) {
  // ...
}
```

\*

## Ponto-e-vírgula

* Não use. (veja:
  [1](http://blog.izs.me/post/2353458699/an-open-letter-to-javascript-leaders-regarding),
  [2](http://inimino.org/%7Einimino/blog/javascript_semicolons),
  [3](https://www.youtube.com/watch?v=gsfbh17Ax9I))

```js
window.alert('hi'); // ✓ ok
window.alert('hi'); // ✗ evite
```

* Nunca comece uma linha com `(`, `[`, ou `` ` ``. Esse é o único problema em
  omitir ponto-e-vírgula, e standard te protege desse problema em potencial.

```js
// ✓ ok
(function() {
  window.alert('ok');
})()(
  // ✗ evite
  (function() {
    window.alert('ok');
  })(),
);
```

```js
// ✓ ok
[1, 2, 3]
  .forEach(bar)

  [
    // ✗ evite
    (1, 2, 3)
  ].forEach(bar);
```

```js
// ✓ ok
`hello`.indexOf('o')`hello`.indexOf('o'); // ✗ evite
```

Nota: Se você frequentemente escreve código assim, você pode estar querendo ser
o inteligentão. Cuidado.

Atalhos inteligentes são desencorajados, em favor de expressões mais limpas e
legíveis, sempre que possível.

Ao invés disso:

```js
[1, 2, 3].forEach(bar);
```

Isso é bem melhor

```js
var nums = [1, 2, 3];
nums.forEach(bar);
```

## Uma leitura boa

* [An Open Letter to JavaScript Leaders Regarding Semicolons][1]
* [JavaScript Semicolon Insertion – Everything you need to know][2]

##### E um vídeo bem explicativo:

* [Are Semicolons Necessary in JavaScript? - YouTube][3]

Todos os minificadores de código populares usam minificação baseada em AST,
logo, podem lidar com JavaScript sem ponto-e-vírgula sem problemas (já que
ponto-e-vírgula não é obrigatório no JavaScript).

##### Um pedaço de _["An Open Letter to JavaScript Leaders Regarding Semicolons"][1]_, traduzido:

[Depender de inserção automática de ponto-e-vírgula] é algo bem seguro, e é
perfeitamente válido, de forma que qualquer navegador entende. Compilador
Closure, yuicompressos, packer e jsmin... todos conseguem minificar sem
problemas. Não há impacto de performance.

Lamento que ao invés de educar, os líderes da comunidade dessa linguagem mentem
pra você, te deixam com medo. Isso é vergonhoso. Eu recomendo aprender como
declarações no JS são terminadas (e em que caso elas não são terminadas), para
que você possa escrever os códigos que acha bonito.

De forma geral, `\n` termina uma declaração a menos que:

1. A declaração possua um parêntese que não foi fechado, um array literal ou um
   objeto literal, ou termina de alguma outra forma que não seja um fim de
   declaração válido (por exemplo, `.` ou `,`)
2. A linha é apenas `--` ou `++` (nesse caso vai decrementar ou incrementar o
   próximo token)
3. Ela seja um `for()`, `while()`, `while()`, `do`, `if()`, ou `else`, e não
   possui `{`
4. A próxima linha começa com `[`, `(`, `+`, `*`, `/`, `-`, `,`, `.`, ou algum
   outro operador binário que só pode ser encontrado entre 2 tokens em uma única
   expressão.

A primeira linha é bem óbvia. Qualquer JSLint não vê problemas em `\n` em json e
construtores "aparêntetizados", e com declarações `var` que se extendem por
múltiplas linhas, terminado em `,`; A segunda é muito esquisita. Nunca vi um
caso (fora de ambientes específicos pra esse caso) onde você iria querer
escrever `i\n++\nj`, mas pra todos os fins, isso é um `i; ++j`, e não `i++; j`.

A terceira é bem difundida, embora geralmente deixada pra lá. `if (x)\ny()` é
equivalente a `if (x) { y() }`. O construtor não termina até que ache um bloco,
ou uma declaração.

`;` é uma declaração válida, logo `if(x);` `if(x){}` ou, “se X, não faça nada".
Isso é mais comum quando aplicado em loops onde a checagem do loop é a própria
função de update. Incomum, mas não totalmente desconhecida.

A quarta é geralmente o que deixa a galera louca, tipo "meu deus, você precisa
de ponto-e-vírgula!" Mas é bem fácil _prefixar_ essas linhas com ponto-e-vírgula
se você não quer que elas sejam continuações da linha anterior. Por exempl, ao
invés disso:

```js
foo();
[1, 2, 3].forEach(bar);
```

você pode fazer isso

```js
foo();
[1, 2, 3].forEach(bar);
```

A vantagem disso é que prefixos são mais fáceis de perceber, uma vez que você
acostuma a nunca mias ver linhas com `(` e `[` sem semis.

_Fim da citação de "An Open Letter to JavaScript Leaders Regarding Semicolons"._

[1]: http://blog.izs.me/post/2353458699/an-open-letter-to-javascript-leaders-regarding
[2]: http://inimino.org/~inimino/blog/javascript_semicolons
[3]: https://www.youtube.com/watch?v=gsfbh17Ax9I
