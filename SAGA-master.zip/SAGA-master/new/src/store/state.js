export default {
  layout: {
    menuCollapsed : false
  }
}
