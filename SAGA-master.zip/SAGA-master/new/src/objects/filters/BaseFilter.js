export default {
  Page: 1,
  PageSize: 20,
  SortBy: 'id',
  IsAscending: false,
};
