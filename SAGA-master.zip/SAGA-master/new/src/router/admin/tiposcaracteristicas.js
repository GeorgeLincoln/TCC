import Form from '@/components/views/admin/tiposcaracteristicas/Form'
import Table from '@/components/views/admin/tiposcaracteristicas/Table'

export default [
    {
        // http://localhost:8080/#/admin/tiposcaracteristicas/form
        path : '/admin/tiposcaracteristicas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/tiposcaracteristicas/table
        path : '/admin/tiposcaracteristicas/table',
        component: Table
    }
];

