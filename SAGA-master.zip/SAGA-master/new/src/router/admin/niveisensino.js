import Form from '@/components/views/admin/niveisensino/Form'
import Table from '@/components/views/admin/niveisensino/Table'

export default [
    {
        // http://localhost:8080/#/admin/niveisensino/form
        path : '/admin/niveisensino/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/niveisensino/table
        path : '/admin/niveisensino/table',
        component: Table
    }
];

