import Form from '@/components/views/admin/ambientespedagogicos/Form'
import Table from '@/components/views/admin/ambientespedagogicos/Table'

export default [{
    // http://localhost:8080/#/admin/ambientespedagogicos/form
    path: '/admin/ambientes/form',
    component: Form
  },
  {
    // http://localhost:8080/#/admin/ambientespedagogicos/table
    path: '/admin/ambientes/table',
    component: Table
  }
];
