import Form from '@/components/views/admin/disciplinastipos/Form'
import Table from '@/components/views/admin/disciplinastipos/Table'

export default [
    {
        // http://localhost:8080/#/admin/disciplinastipos/form
        path : '/admin/disciplinastipos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/disciplinastipos/table
        path : '/admin/disciplinastipos/table',
        component: Table
    }
];

