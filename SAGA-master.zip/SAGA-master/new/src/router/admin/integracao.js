import Importacao from '@/components/views/admin/integracao/Importacao'
export default [{

    path: '/admin/integracao/importacao',
    component: Importacao
  }

];
