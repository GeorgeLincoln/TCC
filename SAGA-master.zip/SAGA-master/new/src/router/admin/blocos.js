import Form from '@/components/views/admin/blocos/Form'
import Table from '@/components/views/admin/blocos/Table'

export default [
    {
        // http://localhost:8080/#/admin/blocos/form
        path : '/admin/blocos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/blocos/table
        path : '/admin/blocos/table',
        component: Table
    }
];

