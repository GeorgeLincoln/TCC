import Form from '@/components/views/admin/parametros/Form'
import Table from '@/components/views/admin/parametros/Table'


export default [{
    // http://localhost:8080/#/admin/parametros/form
    path: '/admin/parametros/form',
    component: Form
  },
  {
    // http://localhost:8080/#/admin/parametros/table
    path: '/admin/parametros/table',
    component: Table
  },

];
