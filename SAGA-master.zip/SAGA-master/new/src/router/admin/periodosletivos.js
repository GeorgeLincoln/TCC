import Form from '@/components/views/admin/periodosletivos/Form'
import Table from '@/components/views/admin/periodosletivos/Table'

export default [
    {
        // http://localhost:8080/#/admin/periodosletivos/form
        path : '/admin/periodosletivos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/periodosletivos/table
        path : '/admin/periodosletivos/table',
        component: Table
    }
];

