import Form from '@/components/views/admin/caracteristicasambientes/Form'
import Table from '@/components/views/admin/caracteristicasambientes/Table'

export default [
    {
        // http://localhost:8080/#/admin/caracteristicasambientes/form
        path : '/admin/caracteristicasambientes/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/caracteristicasambientes/table
        path : '/admin/caracteristicasambientes/table',
        component: Table
    }
];

