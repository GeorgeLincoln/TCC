import Form from '@/components/views/admin/disciplinas/Form'
import Table from '@/components/views/admin/disciplinas/Table'

export default [
    {
        // http://localhost:8080/#/admin/disciplinas/form
        path : '/admin/disciplinas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/disciplinas/table
        path : '/admin/disciplinas/table',
        component: Table
    }
];

