import Form from '@/components/views/admin/gestores/Form'
import Table from '@/components/views/admin/gestores/Table'

export default [
    {
        // http://localhost:8080/#/admin/gestores/form
        path : '/admin/gestores/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/gestores/table
        path : '/admin/gestores/table',
        component: Table
    }
];

