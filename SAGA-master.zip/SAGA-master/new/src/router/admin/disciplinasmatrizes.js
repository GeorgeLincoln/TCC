import Form from '@/components/views/admin/disciplinasmatrizes/Form'
import Table from '@/components/views/admin/disciplinasmatrizes/Table'

export default [
    {
        // http://localhost:8080/#/admin/disciplinasmatrizes/form
        path : '/admin/disciplinasmatrizes/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/disciplinasmatrizes/table
        path : '/admin/disciplinasmatrizes/table',
        component: Table
    }
];

