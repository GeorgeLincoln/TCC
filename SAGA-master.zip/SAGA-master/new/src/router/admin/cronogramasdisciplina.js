import Form from '@/components/views/admin/cronogramasdisciplina/Form'
import Table from '@/components/views/admin/cronogramasdisciplina/Table'

export default [
    {
        // http://localhost:8080/#/admin/cronogramasdisciplina/form
        path : '/admin/cronogramasdisciplina/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/cronogramasdisciplina/table
        path : '/admin/cronogramasdisciplina/table',
        component: Table
    }
];

