import Form from '@/components/views/admin/cursos/Form'
import Table from '@/components/views/admin/cursos/Table'

export default [
    {
        // http://localhost:8080/#/admin/cursos/form
        path : '/admin/cursos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/cursos/table
        path : '/admin/cursos/table',
        component: Table
    }
];

