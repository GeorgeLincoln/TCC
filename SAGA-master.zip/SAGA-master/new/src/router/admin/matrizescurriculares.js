import Form from '@/components/views/admin/matrizescurriculares/Form'
import Table from '@/components/views/admin/matrizescurriculares/Table'

export default [
    {
        // http://localhost:8080/#/admin/matrizescurriculares/form
        path : '/admin/matrizescurriculares/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/matrizescurriculares/table
        path : '/admin/matrizescurriculares/table',
        component: Table
    }
];

