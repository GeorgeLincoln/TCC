import Form from '@/components/views/admin/instituicoes/Form'
import Table from '@/components/views/admin/instituicoes/Table'

export default [
    {
        // http://localhost:8080/#/admin/instituicoes/form
        path : '/admin/instituicoes/form',
        component: Form
    },
    {
        // http://localhost:8080/#/admin/instituicoes/table
        path : '/admin/instituicoes/table',
        component: Table
    }
];

