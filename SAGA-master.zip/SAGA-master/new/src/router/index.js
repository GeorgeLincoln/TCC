import Vue from 'vue';
import Router from 'vue-router';
import Home from '@/components/Home.vue';
import Login from '@/components/Login.vue';
import Dashboard from '@/components/Dashboard.vue';
import App from '@/App.vue';

import Academico from '@/components/views/acad/Index.vue';
import Administrativo from '@/components/views/admin/Index.vue';
import Comum from '@/components/views/comum/Index.vue';

// Academico
import alunos from '@/router/acad/alunos';
import aulas from '@/router/acad/aulas';
import cartoesrfid from '@/router/acad/cartoesrfid';
import disciplinasofertadas from '@/router/acad/disciplinasofertadas';
import dispositivoscoletarfid from '@/router/acad/dispositivoscoletarfid';
import etapas from '@/router/acad/etapas';
import horarios from '@/router/acad/horarios';
import logpresenca from '@/router/acad/logpresenca';
import logsaulas from '@/router/acad/logsaulas';
import mapassalas from '@/router/acad/mapassalas';
import materiaisdidaticos from '@/router/acad/materiaisdidaticos';
import materiaisdisciplinas from '@/router/acad/materiaisdisciplinas';
import matriculasalunos from '@/router/acad/matriculasalunos';
import metodologiasativas from '@/router/acad/metodologiasativas';
import notas from '@/router/acad/notas';
import presencas from '@/router/acad/presencas';
import professores from '@/router/acad/professores';
import turnos from '@/router/acad/turnos';

// Administrativo
import ambientespedagogicos from '@/router/admin/ambientespedagogicos';
import blocos from '@/router/admin/blocos';
import caracteristicasambientes from '@/router/admin/caracteristicasambientes';
import cronogramasdisciplina from '@/router/admin/cronogramasdisciplina';
import cursos from '@/router/admin/cursos';
import disciplinas from '@/router/admin/disciplinas';
import disciplinasmatrizes from '@/router/admin/disciplinasmatrizes';
import disciplinastipos from '@/router/admin/disciplinastipos';
import gestores from '@/router/admin/gestores';
import instituicoes from '@/router/admin/instituicoes';
import matrizescurriculares from '@/router/admin/matrizescurriculares';
import niveisensino from '@/router/admin/niveisensino';
import parametros from '@/router/admin/parametros';
import periodosletivos from '@/router/admin/periodosletivos';
import tiposcaracteristicas from '@/router/admin/tiposcaracteristicas';
import integracao from '@/router/admin/integracao'

// Comum
import grupos from '@/router/comum/grupos';
import grupospessoas from '@/router/comum/grupospessoas';
import notificacaopessoa from '@/router/comum/notificacaopessoa';
import notificacoes from '@/router/comum/notificacoes';
import ocorrencias from '@/router/comum/ocorrencias';
import pessoas from '@/router/comum/pessoas';
import tiposnotificacoes from '@/router/comum/tiposnotificacoes';
import tiposocorrencia from '@/router/comum/tiposocorrencia';
import usuarios from '@/router/comum/usuarios';

const base_routes = [{
    path: '/',
    redirect: {
      name: 'home',
    },
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: Dashboard,
  },
  {
    path: '/acad',
    name: 'acad',
    component: Academico,
  },
  {
    path: '/admin',
    name: 'admin',
    component: Administrativo,
  },
  {
    path: '/comum',
    name: 'comum',
    component: Comum,
  },
  {
    path: '*',
    redirect: {
      name: 'home',
    },
  },
];

const routes = base_routes.concat(
  // Academico
  alunos,
  aulas,
  cartoesrfid,
  disciplinasofertadas,
  dispositivoscoletarfid,
  etapas,
  horarios,
  logpresenca,
  logsaulas,
  mapassalas,
  materiaisdidaticos,
  materiaisdisciplinas,
  matriculasalunos,
  metodologiasativas,
  notas,
  presencas,
  professores,
  turnos,
  // Administrativo
  ambientespedagogicos,
  blocos,
  caracteristicasambientes,
  cronogramasdisciplina,
  cursos,
  disciplinas,
  disciplinasmatrizes,
  disciplinastipos,
  gestores,
  instituicoes,
  matrizescurriculares,
  niveisensino,
  parametros,
  periodosletivos,
  tiposcaracteristicas,
  integracao,
  // Comum
  grupos,
  grupospessoas,
  notificacaopessoa,
  notificacoes,
  ocorrencias,
  pessoas,
  tiposnotificacoes,
  tiposocorrencia,
  usuarios
);

export default new Router({
  routes,
});

Vue.use(Router);
