import Form from '@/components/views/acad/logsaulas/Form'
import Table from '@/components/views/acad/logsaulas/Table'

export default [
    {
        // http://localhost:8080/#/acad/logsaulas/form
        path : '/acad/logsaulas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/logsaulas/table
        path : '/acad/logsaulas/table',
        component: Table
    }
];

