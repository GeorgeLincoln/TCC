import Form from '@/components/views/acad/alunos/Form'
import Table from '@/components/views/acad/alunos/Table'

export default [
    {
        // http://localhost:8080/#/acad/alunos/form
        path : '/acad/alunos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/alunos/table
        path : '/acad/alunos/table',
        component: Table
    }
];

