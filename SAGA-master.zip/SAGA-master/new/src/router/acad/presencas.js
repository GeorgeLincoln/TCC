import Form from '@/components/views/acad/presencas/Form'
import Table from '@/components/views/acad/presencas/Table'

export default [
    {
        // http://localhost:8080/#/acad/presencas/form
        path : '/acad/presencas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/presencas/table
        path : '/acad/presencas/table',
        component: Table
    }
];

