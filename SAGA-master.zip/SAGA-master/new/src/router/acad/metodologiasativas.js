import Form from '@/components/views/acad/metodologiasativas/Form'
import Table from '@/components/views/acad/metodologiasativas/Table'

export default [
    {
        // http://localhost:8080/#/acad/metodologiasativas/form
        path : '/acad/metodologiasativas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/metodologiasativas/table
        path : '/acad/metodologiasativas/table',
        component: Table
    }
];

