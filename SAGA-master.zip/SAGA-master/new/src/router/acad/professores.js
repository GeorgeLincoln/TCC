import Form from '@/components/views/acad/professores/Form'
import Table from '@/components/views/acad/professores/Table'
import Frequencia from '@/components/views/acad/professores/GerenciaPresenca'
import FrequenciaAulas from '@/components/views/acad/aulas/GerenciaPresenca'
import FrequenciaAlunos from '@/components/views/acad/alunos/GerenciaPresenca'

export default [{
    // http://localhost:8080/#/acad/professores/form
    path: '/acad/professores/form',
    component: Form
  },
  {
    // http://localhost:8080/#/acad/professores/table
    path: '/acad/professores/table',
    component: Table
  },
  {
    // http://localhost:8080/#/acad/professores/frequencia
    path: '/acad/professores/frequencia',
    component: Frequencia,
  },
  {
    // http://localhost:8080/#/acad/professores/frequencia
    path: '/acad/professores/frequencia/:name',
    component: FrequenciaAulas,
    name: 'FrequenciaAulas'
  },
  {
    // http://localhost:8080/#/acad/professores/frequencia
    path: '/acad/professores/frequencia/:disciplina/:name',
    component: FrequenciaAlunos,
    name: 'FrequenciaAlunos'
  }


];
