import Form from '@/components/views/acad/aulas/Form'
import Table from '@/components/views/acad/aulas/Table'
import Vinculacao from '@/components/views/acad/aulas/Vinculacao'

export default [{
    // http://localhost:8080/#/acad/aulas/form
    path: '/acad/aulas/form',
    component: Form
  },
  {
    // http://localhost:8080/#/acad/aulas/table
    path: '/acad/aulas/table',
    component: Table
  },
  {
    path: '/acad/aulas/vinculacao',
    component: Vinculacao
  }
];
