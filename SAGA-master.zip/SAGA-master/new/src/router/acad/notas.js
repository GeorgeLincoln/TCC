import Form from '@/components/views/acad/notas/Form'
import Table from '@/components/views/acad/notas/Table'

export default [
    {
        // http://localhost:8080/#/acad/notas/form
        path : '/acad/notas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/notas/table
        path : '/acad/notas/table',
        component: Table
    }
];

