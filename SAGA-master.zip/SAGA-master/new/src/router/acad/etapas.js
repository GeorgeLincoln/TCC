import Form from '@/components/views/acad/etapas/Form'
import Table from '@/components/views/acad/etapas/Table'

export default [
    {
        // http://localhost:8080/#/acad/etapas/form
        path : '/acad/etapas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/etapas/table
        path : '/acad/etapas/table',
        component: Table
    }
];

