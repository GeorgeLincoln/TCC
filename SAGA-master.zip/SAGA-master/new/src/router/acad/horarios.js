import Form from '@/components/views/acad/horarios/Form'
import Table from '@/components/views/acad/horarios/Table'

export default [
    {
        // http://localhost:8080/#/acad/horarios/form
        path : '/acad/horarios/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/horarios/table
        path : '/acad/horarios/table',
        component: Table
    }
];

