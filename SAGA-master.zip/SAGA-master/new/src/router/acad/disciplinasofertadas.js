import Form from '@/components/views/acad/disciplinasofertadas/Form'
import Table from '@/components/views/acad/disciplinasofertadas/Table'

export default [
    {
        // http://localhost:8080/#/acad/disciplinasofertadas/form
        path : '/acad/disciplinasofertadas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/disciplinasofertadas/table
        path : '/acad/disciplinasofertadas/table',
        component: Table
    }
];

