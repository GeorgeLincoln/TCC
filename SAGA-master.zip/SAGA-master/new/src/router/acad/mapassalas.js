import Form from '@/components/views/acad/mapassalas/Form'
import Table from '@/components/views/acad/mapassalas/Table'

export default [
    {
        // http://localhost:8080/#/acad/mapassalas/form
        path : '/acad/mapassalas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/mapassalas/table
        path : '/acad/mapassalas/table',
        component: Table
    }
];

