import Form from '@/components/views/acad/turnos/Form'
import Table from '@/components/views/acad/turnos/Table'

export default [
    {
        // http://localhost:8080/#/acad/turnos/form
        path : '/acad/turnos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/turnos/table
        path : '/acad/turnos/table',
        component: Table
    }
];

