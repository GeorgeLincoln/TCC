import Form from '@/components/views/acad/materiaisdisciplinas/Form'
import Table from '@/components/views/acad/materiaisdisciplinas/Table'

export default [
    {
        // http://localhost:8080/#/acad/materiaisdisciplinas/form
        path : '/acad/materiaisdisciplinas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/materiaisdisciplinas/table
        path : '/acad/materiaisdisciplinas/table',
        component: Table
    }
];

