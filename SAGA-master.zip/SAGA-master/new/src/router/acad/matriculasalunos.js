import Form from '@/components/views/acad/matriculasalunos/Form'
import Table from '@/components/views/acad/matriculasalunos/Table'

export default [
    {
        // http://localhost:8080/#/acad/matriculasalunos/form
        path : '/acad/matriculasalunos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/matriculasalunos/table
        path : '/acad/matriculasalunos/table',
        component: Table
    }
];

