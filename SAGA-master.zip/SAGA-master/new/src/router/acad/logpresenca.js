import Form from '@/components/views/acad/logpresenca/Form'
import Table from '@/components/views/acad/logpresenca/Table'

export default [
    {
        // http://localhost:8080/#/acad/logpresenca/form
        path : '/acad/logpresenca/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/logpresenca/table
        path : '/acad/logpresenca/table',
        component: Table
    }
];

