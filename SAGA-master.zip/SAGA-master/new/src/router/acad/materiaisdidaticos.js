import Form from '@/components/views/acad/materiaisdidaticos/Form'
import Table from '@/components/views/acad/materiaisdidaticos/Table'

export default [
    {
        // http://localhost:8080/#/acad/materiaisdidaticos/form
        path : '/acad/materiaisdidaticos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/materiaisdidaticos/table
        path : '/acad/materiaisdidaticos/table',
        component: Table
    }
];

