import Form from '@/components/views/acad/cartoesrfid/Form'
import Table from '@/components/views/acad/cartoesrfid/Table'

export default [
    {
        // http://localhost:8080/#/acad/cartoesrfid/form
        path : '/acad/cartoesrfid/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/cartoesrfid/table
        path : '/acad/cartoesrfid/table',
        component: Table
    }
];

