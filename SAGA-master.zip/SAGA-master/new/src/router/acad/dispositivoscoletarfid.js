import Form from '@/components/views/acad/dispositivoscoletarfid/Form'
import Table from '@/components/views/acad/dispositivoscoletarfid/Table'

export default [
    {
        // http://localhost:8080/#/acad/dispositivoscoletarfid/form
        path : '/acad/dispositivoscoletarfid/form',
        component: Form
    },
    {
        // http://localhost:8080/#/acad/dispositivoscoletarfid/table
        path : '/acad/dispositivoscoletarfid/table',
        component: Table
    }
];

