import Form from '@/components/views/comum/tiposocorrencia/Form'
import Table from '@/components/views/comum/tiposocorrencia/Table'

export default [
    {
        // http://localhost:8080/#/comum/tiposocorrencia/form
        path : '/comum/tiposocorrencia/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/tiposocorrencia/table
        path : '/comum/tiposocorrencia/table',
        component: Table
    }
];

