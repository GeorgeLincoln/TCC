import Form from '@/components/views/comum/ocorrencias/Form'
import Table from '@/components/views/comum/ocorrencias/Table'

export default [
    {
        // http://localhost:8080/#/comum/ocorrencias/form
        path : '/comum/ocorrencias/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/ocorrencias/table
        path : '/comum/ocorrencias/table',
        component: Table
    }
];

