import Form from '@/components/views/comum/grupos/Form'
import Table from '@/components/views/comum/grupos/Table'

export default [
    {
        // http://localhost:8080/#/comum/grupos/form
        path : '/comum/grupos/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/grupos/table
        path : '/comum/grupos/table',
        component: Table
    }
];

