import Form from '@/components/views/comum/pessoas/Form'
import Table from '@/components/views/comum/pessoas/Table'

export default [
    {
        // http://localhost:8080/#/comum/pessoas/form
        path : '/comum/pessoas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/pessoas/table
        path : '/comum/pessoas/table',
        component: Table
    }
];

