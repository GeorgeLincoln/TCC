import Form from '@/components/views/comum/grupospessoas/Form'
import Table from '@/components/views/comum/grupospessoas/Table'

export default [
    {
        // http://localhost:8080/#/comum/grupospessoas/form
        path : '/comum/grupospessoas/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/grupospessoas/table
        path : '/comum/grupospessoas/table',
        component: Table
    }
];

