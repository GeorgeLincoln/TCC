import Form from '@/components/views/comum/tiposnotificacoes/Form'
import Table from '@/components/views/comum/tiposnotificacoes/Table'

export default [
    {
        // http://localhost:8080/#/comum/tiposnotificacoes/form
        path : '/comum/tiposnotificacoes/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/tiposnotificacoes/table
        path : '/comum/tiposnotificacoes/table',
        component: Table
    }
];

