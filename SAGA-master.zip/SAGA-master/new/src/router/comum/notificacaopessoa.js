import Form from '@/components/views/comum/notificacaopessoa/Form'
import Table from '@/components/views/comum/notificacaopessoa/Table'

export default [
    {
        // http://localhost:8080/#/comum/notificacaopessoa/form
        path : '/comum/notificacaopessoa/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/notificacaopessoa/table
        path : '/comum/notificacaopessoa/table',
        component: Table
    }
];

