import Form from '@/components/views/comum/notificacoes/Form'
import Table from '@/components/views/comum/notificacoes/Table'

export default [
    {
        // http://localhost:8080/#/comum/notificacoes/form
        path : '/comum/notificacoes/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/notificacoes/table
        path : '/comum/notificacoes/table',
        component: Table
    }
];

