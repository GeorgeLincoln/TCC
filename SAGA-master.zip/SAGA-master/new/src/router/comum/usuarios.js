import Form from '@/components/views/comum/usuarios/Form'
import Table from '@/components/views/comum/usuarios/Table'

export default [
    {
        // http://localhost:8080/#/comum/usuarios/form
        path : '/comum/usuarios/form',
        component: Form
    },
    {
        // http://localhost:8080/#/comum/usuarios/table
        path : '/comum/usuarios/table',
        component: Table
    }
];

