 import axios from 'axios'

 // Base Api Url
 const baseUrl = 'http://localhost:63637/api/'

 export default class ApiService {

   constructor(serviceName) {
     this.serviceName = serviceName;
     if (serviceName != null && serviceName != undefined) {
       this.url = baseUrl + this.serviceName + '/';
     } else {
       this.url = baseUrl;

     }
   }

   // GetAll
   getAll(filter = {}, sub = '') {
     let params = {
       params: filter
     }
     return axios
       .get(this.url + sub, params)
       .then(response => response.data)
       .catch(err => {
         console.log(err);
       });
   }

   getById(id, sub = '') {
     return new Promise((resolve, reject) => {
       axios
         .get(this.url + sub + id)
         .then(res => {
           resolve(res.data);
         })
         .catch(err => {
           reject(err.response);
         });
     });
   }

   create(newObject = {}, sub = '') {
     return new Promise((resolve, reject) => {
       axios
         .post(this.url + sub, newObject)
         .then(res => {
           resolve(res.data)
         })
         .catch(err => {
           reject(err.response)
         })
     })
   }

   update(newObject, id, sub = '') {
     return new Promise((resolve, reject) => {
       axios
         .put(this.url + sub + id, newObject)
         .then(res => {
           resolve(res.data)
         })
         .catch(err => {
           reject(err.response)
         })
     })
   }

   delete(id, sub = '') {
     return new Promise((resolve, reject) => {
       axios
         .delete(this.url + sub + id)
         .then(res => {
           resolve(res.data);
         })
         .catch(err => {
           reject(err.response);
         });
     });
   }

   count() {}

   uploadCsv(csv, sub = '') {
     let config = {
       headers: {
         'Content-Type': 'text/csv',
       },
     };
     return new Promise((resolve, reject) => {
       axios
         .post(this.url + sub + '/import', csv, config)
         .then(res => {
           console.log(res);
           resolve(res.data);
         })
         .catch(err => {
           console.log('ERROR', err.response);
           reject(err.response);
         });
     });
   }
 }
