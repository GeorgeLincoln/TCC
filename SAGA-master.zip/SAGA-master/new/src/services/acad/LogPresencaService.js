
import ApiService from '../ApiService'

export default class LogPresencaService extends ApiService {
  constructor () {
    super('logpresenca')
  }
}
