
import ApiService from '../ApiService'

export default class DisciplinasOfertadasService extends ApiService {
  constructor () {
    super('disciplinasofertadas')
  }
}
