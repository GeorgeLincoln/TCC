
import ApiService from '../ApiService'

export default class CartoesRFIDService extends ApiService {
  constructor () {
    super('cartoesrfid')
  }
}
