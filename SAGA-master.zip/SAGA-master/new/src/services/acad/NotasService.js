
import ApiService from '../ApiService'

export default class NotasService extends ApiService {
  constructor () {
    super('notas')
  }
}
