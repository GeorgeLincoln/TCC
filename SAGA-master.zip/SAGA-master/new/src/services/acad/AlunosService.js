
import ApiService from '../ApiService'

export default class AlunosService extends ApiService {
  constructor () {
    super('alunos')
  }
 
}
