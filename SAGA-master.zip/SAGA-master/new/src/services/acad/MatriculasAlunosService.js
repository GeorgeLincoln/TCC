
import ApiService from '../ApiService'

export default class MatriculasAlunosService extends ApiService {
  constructor () {
    super('matriculasalunos')
  }
}
