
import ApiService from '../ApiService'

export default class MapasSalasService extends ApiService {
  constructor () {
    super('mapassalas')
  }
}
