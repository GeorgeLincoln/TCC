
import ApiService from '../ApiService'

export default class PresencasService extends ApiService {
  constructor () {
    super('presencas')
  }
}
