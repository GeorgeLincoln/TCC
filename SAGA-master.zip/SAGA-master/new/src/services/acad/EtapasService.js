
import ApiService from '../ApiService'

export default class EtapasService extends ApiService {
  constructor () {
    super('etapas')
  }
}
