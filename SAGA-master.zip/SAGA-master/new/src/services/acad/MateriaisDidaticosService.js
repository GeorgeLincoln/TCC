
import ApiService from '../ApiService'

export default class MateriaisDidaticosService extends ApiService {
  constructor () {
    super('materiaisdidaticos')
  }
}
