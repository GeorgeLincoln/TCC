
import ApiService from '../ApiService'

export default class TurnosService extends ApiService {
  constructor () {
    super('turnos')
  }
}
