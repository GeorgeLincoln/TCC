
import ApiService from '../ApiService'

export default class MetodologiasAtivasService extends ApiService {
  constructor () {
    super('metodologiasativas')
  }
}
