
import ApiService from '../ApiService'

export default class LogsAulasService extends ApiService {
  constructor () {
    super('logsaulas')
  }
}
