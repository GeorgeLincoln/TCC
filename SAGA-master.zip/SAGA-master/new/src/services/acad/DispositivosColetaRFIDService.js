
import ApiService from '../ApiService'

export default class DispositivosColetaRFIDService extends ApiService {
  constructor () {
    super('dispositivoscoletarfid')
  }
}
