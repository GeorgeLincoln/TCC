
import ApiService from '../ApiService'

export default class ProfessoresService extends ApiService {
  constructor () {
    super('professores')
  }
}
