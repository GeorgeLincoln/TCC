
import ApiService from '../ApiService'

export default class HorariosService extends ApiService {
  constructor () {
    super('horarios')
  }
}
