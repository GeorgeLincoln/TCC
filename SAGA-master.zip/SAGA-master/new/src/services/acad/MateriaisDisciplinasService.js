
import ApiService from '../ApiService'

export default class MateriaisDisciplinasService extends ApiService {
  constructor () {
    super('materiaisdisciplinas')
  }
}
