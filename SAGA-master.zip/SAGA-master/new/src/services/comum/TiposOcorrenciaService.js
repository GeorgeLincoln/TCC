
import ApiService from '../ApiService'

export default class TiposOcorrenciaService extends ApiService {
  constructor () {
    super('tiposocorrencia')
  }
}
