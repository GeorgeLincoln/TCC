
import ApiService from '../ApiService'

export default class UsuariosService extends ApiService {
  constructor () {
    super('usuarios')
  }
}
