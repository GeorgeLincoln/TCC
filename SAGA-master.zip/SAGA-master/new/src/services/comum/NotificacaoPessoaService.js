
import ApiService from '../ApiService'

export default class NotificacaoPessoaService extends ApiService {
  constructor () {
    super('notificacaopessoa')
  }
}
