
import ApiService from '../ApiService'

export default class BaseService extends ApiService {
  constructor () {
    super('base')
  }
}
