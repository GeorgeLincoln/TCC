
import ApiService from '../ApiService'

export default class NotificacoesService extends ApiService {
  constructor () {
    super('notificacoes')
  }
}
