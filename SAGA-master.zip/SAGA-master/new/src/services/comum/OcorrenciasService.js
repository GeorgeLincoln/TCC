
import ApiService from '../ApiService'

export default class OcorrenciasService extends ApiService {
  constructor () {
    super('ocorrencias')
  }
}
