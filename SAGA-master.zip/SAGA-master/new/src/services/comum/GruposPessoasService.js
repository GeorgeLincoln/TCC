
import ApiService from '../ApiService'

export default class GruposPessoasService extends ApiService {
  constructor () {
    super('grupospessoas')
  }
}
