
import ApiService from '../ApiService'

export default class TiposNotificacoesService extends ApiService {
  constructor () {
    super('tiposnotificacoes')
  }
}
