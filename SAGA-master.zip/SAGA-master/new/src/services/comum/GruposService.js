
import ApiService from '../ApiService'

export default class GruposService extends ApiService {
  constructor () {
    super('grupos')
  }
}
