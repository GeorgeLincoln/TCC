
import ApiService from '../ApiService'

export default class PessoasService extends ApiService {
  constructor () {
    super('pessoas')
  }
}
