import ApiService from '../ApiService'

export default class AmbientesPedagogicosService extends ApiService {
  constructor() {
    super('ambientes')
  }
}
