
import ApiService from '../ApiService'

export default class CursosService extends ApiService {
  constructor () {
    super('cursos')
  }
}
