
import ApiService from '../ApiService'

export default class BlocosService extends ApiService {
  constructor () {
    super('blocos')
  }
}
