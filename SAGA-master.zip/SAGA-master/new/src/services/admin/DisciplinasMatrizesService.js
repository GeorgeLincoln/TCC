
import ApiService from '../ApiService'

export default class DisciplinasMatrizesService extends ApiService {
  constructor () {
    super('disciplinasmatrizes')
  }
}
