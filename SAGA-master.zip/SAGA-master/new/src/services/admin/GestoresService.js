
import ApiService from '../ApiService'

export default class GestoresService extends ApiService {
  constructor () {
    super('gestores')
  }
}
