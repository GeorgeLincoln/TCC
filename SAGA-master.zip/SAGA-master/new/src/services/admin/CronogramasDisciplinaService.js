
import ApiService from '../ApiService'

export default class CronogramasDisciplinaService extends ApiService {
  constructor () {
    super('cronogramasdisciplina')
  }
}
