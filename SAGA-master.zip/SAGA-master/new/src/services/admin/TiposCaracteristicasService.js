
import ApiService from '../ApiService'

export default class TiposCaracteristicasService extends ApiService {
  constructor () {
    super('tiposcaracteristicas')
  }
}
