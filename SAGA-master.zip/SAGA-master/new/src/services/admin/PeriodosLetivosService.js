
import ApiService from '../ApiService'

export default class PeriodosLetivosService extends ApiService {
  constructor () {
    super('periodosletivos')
  }
}
