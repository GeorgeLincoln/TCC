
import ApiService from '../ApiService'

export default class NiveisEnsinoService extends ApiService {
  constructor () {
    super('niveisensino')
  }
}
