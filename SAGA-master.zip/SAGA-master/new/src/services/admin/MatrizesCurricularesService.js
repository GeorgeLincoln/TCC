
import ApiService from '../ApiService'

export default class MatrizesCurricularesService extends ApiService {
  constructor () {
    super('matrizescurriculares')
  }
}
