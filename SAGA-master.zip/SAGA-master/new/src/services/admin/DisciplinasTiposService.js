import ApiService from '../ApiService'

export default class DisciplinasTiposService extends ApiService {
  constructor() {
    super('disciplinastipos')
  }
}
