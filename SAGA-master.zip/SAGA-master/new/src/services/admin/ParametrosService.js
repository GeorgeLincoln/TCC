import ApiService from '../ApiService';

export default class ParametrosService extends ApiService {
  constructor () {
    super ('parametros');
  }
}
