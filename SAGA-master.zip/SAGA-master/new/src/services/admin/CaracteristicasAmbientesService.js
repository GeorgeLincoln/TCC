import ApiService from '../ApiService'

export default class CaracteristicasAmbientesService extends ApiService {
  constructor () {
    super('caracteristicasambiente')
  }
}
