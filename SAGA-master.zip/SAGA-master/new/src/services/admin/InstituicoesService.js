
import ApiService from '../ApiService'

export default class InstituicoesService extends ApiService {
  constructor () {
    super('instituicoes')
  }
}
