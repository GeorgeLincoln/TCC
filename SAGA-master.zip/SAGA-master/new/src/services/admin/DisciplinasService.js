
import ApiService from '../ApiService'

export default class DisciplinasService extends ApiService {
  constructor () {
    super('disciplinas')
  }
}
