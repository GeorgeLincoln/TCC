<template>
  <div id="app">
    <layout-default></layout-default>
  </div>
</template>

<script>
import LayoutDefault from './components/layouts/Default';

export default {
	name: 'App',
	components: {
		LayoutDefault,
	},
};
</script>
