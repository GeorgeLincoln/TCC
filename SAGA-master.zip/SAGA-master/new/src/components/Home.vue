<template>
<div class="home">
    <h1>{{title}} (to do)</h1>
    <a></a>
</div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      title: 'Aquicultura'
    }
  }
}
</script>

<style>

</style>