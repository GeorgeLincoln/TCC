<template>
  <div id="parametroImportacao">
    <div class="container">
      <!--UPLOAD-->
      <form enctype="multipart/form-data">
        
        <div class="alert alert-success" role="alert" v-if="isSuccess">
          Arquivo importado com sucesso!!
        </div>
        <div class="alert alert-danger" role="alert" v-if="isFailed">
          Falha ao importar!!
        </div>
		<label for="importacao" class="text-secondary">{{titulo[0].label}}</label>
        <input id="importacao" type="file" @change="onFileChange" :name="uploadFieldName" accept=".csv" class="form-control-file"  :disabled="isSaving">


        <div class="footer"> 
          <div v-if="isSaving" class="loader"></div>
        </div>


        <!-- <button  @click="reset" type="button" class="btn btn-secondary">Reset</button> -->
      </form>

      

    </div>
  </div>
</template>

<script>
import Service from '@/services/ApiService';
const STATUS_INITIAL = 0,
	STATUS_SAVING = 1,
	STATUS_SUCCESS = 2,
	STATUS_FAILED = 3;
export default {
	data() {
		return {
			uploadError: null,
			currentStatus: null,
			uploadFieldName: 'Csv',
			fileinput: '',
		};
	},
	props: ['titulo', 'rota'],
	computed: {
		isInitial() {
			return this.currentStatus === STATUS_INITIAL;
		},
		isSaving() {
			return this.currentStatus === STATUS_SAVING;
		},
		isSuccess() {
			return this.currentStatus === STATUS_SUCCESS;
		},
		isFailed() {
			return this.currentStatus === STATUS_FAILED;
		},
	},

	methods: {
		reset() {
			// reset form to initial state
			this.currentStatus = STATUS_INITIAL;
			this.fileinput = '';
			this.uploadError = null;
		},
		onFileChange(e) {
			var files = e.target.files || e.dataTransfer.files;
			if (!files.length) return;
			this.createInput(files[0]);
		},
		createInput(file) {
			var reader = new FileReader();
			var vm = this;
			reader.onload = e => {
				vm.fileinput = e.target.result;
				this.save();
			};

			reader.readAsText(file);
		},
		save() {
			let service = new Service();
			this.currentStatus = STATUS_SAVING;
			let promise = service.uploadCsv(this.fileinput, this.rota[0]);
			promise
				// .then(data => {
				// 	this.fileinput = data;
				// 	this.currentStatus = STATUS_SUCCESS;
				// })
				.then(
					success => {
						//this.fileinput = success;
						this.currentStatus = STATUS_SUCCESS;
					},
					err => {
						this.currentStatus = STATUS_FAILED;
					},
				);
		},
	},

	created() {
		this.reset();
	},
};
</script>

<style lang="scss">
.dropbox p {
	font-size: 1.2em;
	text-align: center;
	padding: 50px 0;
}

.sucess {
	color: #31708f;
}

.error {
	color: #a94442;
}

.loader {
	border: 5px solid #fdfbfb;
	/* Light grey */
	border-top: 5px solid #8979e2;
	/* Blue */
	border-radius: 50%;
	border-top: 5px solid #8979e2;
	border-bottom: 5px solid #8979e2;
	width: 50px;
	height: 50px;
	animation: spin 2s linear infinite;
}

.footer {
	position: absolute;
	bottom: 0;
	width: 100%;
}

@keyframes spin {
	0% {
		transform: rotate(0deg);
	}
	100% {
		transform: rotate(360deg);
	}
}
</style>
