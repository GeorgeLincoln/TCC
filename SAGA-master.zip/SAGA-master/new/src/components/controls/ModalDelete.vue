<template>
<!-- Modal -->
<div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-light bg-tit">
        <h5 class="modal-title" id="exampleModalLabel">Confirmar Exclusão</h5>
      </div>
      <div class="modal-body">
        Você tem certeza que deseja realmente excluir esta informação ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" @click="emitClick()">Excluir</button>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      data: [],
      dto: {},
      errors: [],
    };
  },
  methods: {
    emitClick() {
      this.$emit('emit-click');
    },
  },
};
</script>


<style scoped>
.bg-tit {
  background-color: #37394e;
}
</style>
