<template>
<div id="divTurno">
    <h1>Turno</h1>
    <form id="formTurno">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>
    </form>

</div>
</template>

<script>

</script>
