<template>
<div id="divTurno">
    <table id="tableTurno" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Descricao</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.descricao }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/acad/TurnosService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
