<template>
<div id="divMaterialDidatico">
    <table id="tableMaterialDidatico" class="table">
        <thead>
            <tr>
                <td>Descricao</td>
                <td>Arquivo</td>
                <td>DataSubmissao</td>
                <td>ProfessorId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.descricao }}</td>
                <td>{{ row.arquivo }}</td>
                <td>{{ row.dataSubmissao }}</td>
                <td>{{ row.professorId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/acad/MateriaisDidaticosService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
