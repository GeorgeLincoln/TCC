<template>
<div id="divMaterialDidatico">
    <h1>MaterialDidatico</h1>
    <form id="formMaterialDidatico">
                <div class="form-group">
                    <label for="arquivo">Arquivo</label>
                    <input type="text" class="form-control" id="arquivo" placeholder="Arquivo">
                </div>

                <div class="form-group">
                    <label for="datasubmissao">DataSubmissao</label>
                    <input type="datetime-local" class="form-control" id="datasubmissao" placeholder="DataSubmissao">
                </div>

                <div class="form-group">
                    <label for="professorid">ProfessorId</label>
                    <select class="form-control" id="professorid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
