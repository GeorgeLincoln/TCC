<template>
  <div id="gerencia-presenca">
    <table id="tableDisciplinaOfertada" class="table">
        <thead>
            <tr>
                <td>Disciplina</td>
                <td>Data Início</td>
                <td>Data Término</td>
                <td>Professor</td>
                <td>Periodo Letivo</td>
                <td>Disciplina</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in Disciplinas" v-bind:key="row.id">
                <td>{{ row.disciplinaNome }}</td>
                <td>{{ row.dataInicio }}</td>
                <td>{{ row.dataTermino }}</td>
                <td>{{ row.professorNome }}</td>
                <td>{{ row.periodoLetivoNome }}</td>
                <td>{{ row.disciplinaNome }}</td>
                
                <td><router-link class="fa fa-book"   :to="{
                 name: 'FrequenciaAulas',
                 params: {name: row.id}
             }"></router-link></td>
            </tr>
        </tbody>
    </table>
  </div>
 
  
</template>

</<script>
import Service from '@/services/acad/DisciplinasOfertadasService'
export default { 
  data(){ 
    return { Disciplinas: [],
         
    } 
  },
  created(){ 
  let service = new Service(); 
  service.getAll({ ProfessorId: 5,
                   WithNames: true,
                   WithDisciplinaMatriz: true,
                   WithProfessor: true,
                   WithPeriodo: true }, 'filter')
  .then(sucess => { 
          this.Disciplinas = sucess;},
        err => {console.log(err);}
      ); 
  }}
</script>
