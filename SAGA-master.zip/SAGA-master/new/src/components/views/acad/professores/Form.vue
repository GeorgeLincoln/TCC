<template>
<div id="divProfessor">
    <h1>Professor</h1>
    <form id="formProfessor">
                <div class="form-group">
                    <label for="pessoaid">PessoaId</label>
                    <select class="form-control" id="pessoaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="matricula">Matricula</label>
                    <input type="text" class="form-control" id="matricula" placeholder="Matricula">
                </div>
    </form>

</div>
</template>

<script>

</script>
