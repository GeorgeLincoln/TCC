<template>
<div id="divMetodologiaAtiva">
    <h1>MetodologiaAtiva</h1>
    <form id="formMetodologiaAtiva">    </form>

</div>
</template>

<script>

</script>
