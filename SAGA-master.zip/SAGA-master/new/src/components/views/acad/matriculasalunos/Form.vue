<template>
<div id="divMatriculaAluno">
    <h1>MatriculaAluno</h1>
    <form id="formMatriculaAluno">
                <div class="form-group">
                    <label for="datamatricula">DataMatricula</label>
                    <input type="datetime-local" class="form-control" id="datamatricula" placeholder="DataMatricula">
                </div>

                <div class="form-group">
                    <label for="situacao">Situacao</label>
                    <input type="text" class="form-control" id="situacao" placeholder="Situacao">
                </div>

                <div class="form-group">
                    <label for="alunoid">AlunoId</label>
                    <select class="form-control" id="alunoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disciplinaofertadaid">DisciplinaOfertadaId</label>
                    <select class="form-control" id="disciplinaofertadaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
