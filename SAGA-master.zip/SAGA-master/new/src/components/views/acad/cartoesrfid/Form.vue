<template>
<div id="divCartaoRFID">
    <h1>CartaoRFID</h1>
    <form id="formCartaoRFID">    </form>

</div>
</template>

<script>

</script>
