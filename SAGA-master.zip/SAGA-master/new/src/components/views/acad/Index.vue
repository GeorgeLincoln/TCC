<template>
    <h1> Acadêmico</h1>
</template>

<script>

</script>