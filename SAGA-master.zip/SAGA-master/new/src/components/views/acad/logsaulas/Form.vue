<template>
<div id="divLogPresenca">
    <h1>LogPresenca</h1>
    <form id="formLogPresenca">
                <div class="form-group">
                    <label for="logaulaid">LogAulaId</label>
                    <select class="form-control" id="logaulaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="alunoid">AlunoId</label>
                    <select class="form-control" id="alunoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="data">Data</label>
                    <input type="datetime-local" class="form-control" id="data" placeholder="Data">
                </div>
    </form>

</div>
</template>

<script>

</script>
