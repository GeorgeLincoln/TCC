<template>
<div id="divNota">
    <h1>Nota</h1>
    <form id="formNota">
                <div class="form-group">
                    <label for="doublevalor">doubleValor</label>
                    <input type="text" class="form-control" id="doublevalor" placeholder="doubleValor">
                </div>

                <div class="form-group">
                    <label for="matriculaalunoid">MatriculaAlunoId</label>
                    <select class="form-control" id="matriculaalunoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="etapaid">EtapaId</label>
                    <select class="form-control" id="etapaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
