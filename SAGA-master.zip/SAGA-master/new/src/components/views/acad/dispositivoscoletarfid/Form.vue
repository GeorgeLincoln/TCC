<template>
<div id="divDispositivoColetaRFID">
    <h1>DispositivoColetaRFID</h1>
    <form id="formDispositivoColetaRFID">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome">
                </div>
    </form>

</div>
</template>

<script>

</script>
