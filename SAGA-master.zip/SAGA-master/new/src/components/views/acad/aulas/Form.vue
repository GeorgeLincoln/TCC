<template>
<div id="divAula">
    <h1>Aula</h1>
    <form id="formAula">
                <div class="form-group">
                    <label for="numero">Número</label>
                    <input type="text" class="form-control" id="numero" placeholder="Numero">
                </div>

                <div class="form-group">
                    <label for="datahorainicialplanejada">Data Hora Inicial Planejada</label>
                    <input type="datetime-local" class="form-control" id="datahorainicialplanejada" placeholder="Data Hora Inicial Planejada">
                </div>

                <div class="form-group">
                    <label for="datahoraterminoplanejada">Data Hora Término Planejada</label>
                    <input type="datetime-local" class="form-control" id="datahoraterminoplanejada" placeholder="Data Hora Termino Planejada">
                </div>

                <div class="form-group">
                    <label for="conteudoplanejado">Conteudo Planejado</label>
                    <input type="text" class="form-control" id="conteudoplanejado" placeholder="Conteudo Planejado">
                </div>

                <div class="form-group">
                    <label for="datahorainicialministrada">Data Hora Inicial Ministrada</label>
                    <input type="datetime-local" class="form-control" id="datahorainicialministrada" placeholder="Data Hora Inicial Ministrada">
                </div>

                <div class="form-group">
                    <label for="datahoraterminoministrada">Data Hora Término Ministrada</label>
                    <input type="datetime-local" class="form-control" id="datahoraterminoministrada" placeholder="Data Hora Termino Ministrada">
                </div>

                <div class="form-group">
                    <label for="conteudoministrado">Conteudo Ministrado</label>
                    <input type="text" class="form-control" id="conteudoministrado" placeholder="Conteudo Ministrado">
                </div>

                <div class="form-group">
                    <label for="disciplinaofertadaid">Disciplina Ofertada Id</label>
                    <select class="form-control" id="disciplinaofertadaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="ambientepedagogicoid">Ambiente Pedagogico Id</label>
                    <select class="form-control" id="ambientepedagogicoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
