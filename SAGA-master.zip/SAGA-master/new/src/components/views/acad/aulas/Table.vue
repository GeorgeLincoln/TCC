<template>
<div id="divAula">
    <table id="tableAula" class="table">
        <thead>
            <tr>
                <td>Número</td>
                <td>Data Hora Inicial Planejada</td>
                <td>Data Hora Término Planejada</td>
                <td>Data Hora Inicial Ministrada</td>
                <td>Data Hora Término Ministrada</td>
                <td>Disciplina Ofertada Id</td>
                <td>Ambient ePedagogico Id</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.numero }}</td>
                <td>{{ row.dataHoraInicialPlanejada }}</td>
                <td>{{ row.dataHoraTerminoPlanejada }}</td>
                <td>{{ row.dataHoraInicialMinistrada }}</td>
                <td>{{ row.dataHoraTerminoMinistrada }}</td>
                <td>{{ row.disciplinaOfertadaId }}</td>
                <td>{{ row.ambientePedagogicoId }}</td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import AulasService  from '@/services/acad/AulasService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new AulasService();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
