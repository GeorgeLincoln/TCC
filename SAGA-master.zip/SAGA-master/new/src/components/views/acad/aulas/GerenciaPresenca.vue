<template>
  <div id="gerencia-presenca">
      
      <table id="table-aulas" class="table">
        <thead>
            <tr>
                <td>Disciplina</td>
                <td>Data Início</td>
                <td>Data Término</td>
                
                
                
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in Aulas" v-bind:key="row.id">
                <td>{{ row.disciplinaNome }}</td>
                <td>{{ row.dataHoraInicialPlanejada }}</td>
                <td>{{ row.dataHoraTerminoPlanejada }}</td>
             
                
                
                <td><router-link class="fas fa-user"  :to="{
                 name: 'FrequenciaAlunos',
                 params: {name: row.id,
                          disciplina: $route.params.name}
             }" ></router-link></td>
            </tr>
        </tbody>
    </table>
  </div>
 
  
</template>

<script>
import Service from '@/services/acad/AulasService'
export default { 
  data(){ 
    return { 
      Aulas: []
    } 
  },
  created(){ 
   
    let service = new Service(); 
    service.getAll({
    DisciplinaOfertadaId: this.$route.params.name,
    WithDisciplinaMatricula: true,
    WithDisciplinaNome: true


   }, 'filter')
  .then(sucess => { 
          this.Aulas = sucess;},
        err => {console.log(err);}
      ); 
  }
}
</script>
