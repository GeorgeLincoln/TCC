<template>
<div id="divAluno">
    <h1>Aluno</h1>
    <h2> Alunoooo </h2>
    <form id="formAluno">
                <div class="form-group">
                    <label for="matricula">Matrícula</label>
                    <input type="text" class="form-control" id="matricula" placeholder="Matricula">
                </div>
               
                <div class="form-group">
                    <label for="pessoaid">Pessoa Id</label>
                    <select class="form-control" id="pessoaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
               
    </form>

</div>
</template>

<script>

</script>
