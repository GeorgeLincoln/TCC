<template>
<div id="divAluno">
    <table id="tableAluno" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Matricula</td>
                <td>PessoaId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.matricula }}</td>
                <td>{{ row.pessoaId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import AlunosService  from '@/services/acad/AlunosService'

export default {
  data() {
    return {
      data: [],

      errors: [],

    }
  },

  created(){
    let service = new AlunosService();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,

    });
    promise.then(data => this.data = data);
    
  }
}
</script>
