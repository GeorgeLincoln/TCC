<template>
  <div id="gerencia-presenca">
     
      <table id="table-matricula" class="table">
        <thead>
            <tr>
                <td>Aluno</td>
                <td>Matricula</td>
                <td>Situação</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in Matriculas" v-bind:key="row.id">
                <td>{{ row.alunoNome }}</td>
                <td>{{ row.alunoMatricula }}</td>
                <td>{{ row.situacao }}</td>
                <td><input type="checkbox"></td>
            </tr>
        </tbody>
    </table>
      
  </div>
 
  
</template>

</<script>
import Service from '@/services/acad/MatriculasAlunosService'
export default {
   
  data(){ 
    return { 
      Matriculas: []
    } 
  },
  created(){ 
    let service = new Service();
    service.getAll({
    AlunoId: this.$route.params.disciplina,
    WithAluno: true,
    WithAlunoNome: true


   }, 'filter')
  .then(sucess => { 
          this.Matriculas = sucess;},
        err => {console.log(err);}
      ); 
  }
  
}
</script>
