<template>
<div id="divPresenca">
    <h1>Presenca</h1>
    <form id="formPresenca">
                <div class="form-group">
                    <label for="data">Data</label>
                    <input type="datetime-local" class="form-control" id="data" placeholder="Data">
                </div>

                <div class="form-group">
                    <label for="observacao">Observacao</label>
                    <input type="text" class="form-control" id="observacao" placeholder="Observacao">
                </div>

                <div class="form-group">
                    <label for="boolabonado">boolAbonado</label>
                    <input type="text" class="form-control" id="boolabonado" placeholder="boolAbonado">
                </div>

                <div class="form-group">
                    <label for="matriculaalunoid">MatriculaAlunoId</label>
                    <select class="form-control" id="matriculaalunoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="aulaministradaid">AulaMinistradaId</label>
                    <select class="form-control" id="aulaministradaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
