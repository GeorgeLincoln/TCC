<template>
<div id="divPresenca">
    <table id="tablePresenca" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Data</td>
                <td>Observacao</td>
                <td>boolAbonado</td>
                <td>MatriculaAlunoId</td>
                <td>AulaMinistradaId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.data }}</td>
                <td>{{ row.observacao }}</td>
                <td>{{ row.boolAbonado }}</td>
                <td>{{ row.matriculaAlunoId }}</td>
                <td>{{ row.aulaMinistradaId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/acad/PresencasService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
