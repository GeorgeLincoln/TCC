<template>
<div id="divDisciplinaOfertada">
    <h1>DisciplinaOfertada</h1>
    <form id="formDisciplinaOfertada">
                <div class="form-group">
                    <label for="codigo">Código</label>
                    <input type="text" class="form-control" id="codigo" placeholder="Codigo">
                </div>

                <div class="form-group">
                    <label for="datainicio">Data Início</label>
                    <input type="datetime-local" class="form-control" id="datainicio" placeholder="DataInicio">
                </div>

                <div class="form-group">
                    <label for="datatermino">Data Término</label>
                    <input type="datetime-local" class="form-control" id="datatermino" placeholder="DataTermino">
                </div>

                <div class="form-group">
                    <label for="professorid">Professor Id</label>
                    <select class="form-control" id="professorid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="periodoletivoid">Período Letivo Id</label>
                    <select class="form-control" id="periodoletivoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disciplinamatrizid">Disciplina Matriz Id</label>
                    <select class="form-control" id="disciplinamatrizid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
