<template>
<div id="divDisciplinaOfertada">
    <table id="tableDisciplinaOfertada" class="table">
        <thead>
            <tr>
                <td>Código</td>
                <td>Data Início</td>
                <td>Data Término</td>
                <td>Professor Id</td>
                <td>Periodo Letivo Id</td>
                <td>Disciplina Matriz Id</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.codigo }}</td>
                <td>{{ row.dataInicio }}</td>
                <td>{{ row.dataTermino }}</td>
                <td>{{ row.professorId }}</td>
                <td>{{ row.periodoLetivoId }}</td>
                <td>{{ row.disciplinaMatrizId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/acad/DisciplinasOfertadasService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
