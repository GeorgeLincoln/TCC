<template>
<div id="divMaterialDisciplina">
    <h1>MaterialDisciplina</h1>
    <form id="formMaterialDisciplina">
                <div class="form-group">
                    <label for="disciplinaofertadaid">DisciplinaOfertadaId</label>
                    <select class="form-control" id="disciplinaofertadaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disciplinaofertadadisciplinaofertada">DisciplinaOfertadaDisciplinaOfertada</label>
                    <input type="text" class="form-control" id="disciplinaofertadadisciplinaofertada" placeholder="DisciplinaOfertadaDisciplinaOfertada">
                </div>
    </form>

</div>
</template>

<script>

</script>
