<template>
<div id="divHorario">
    <table id="tableHorario" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>DiaDaSemana</td>
                <td>Legenda</td>
                <td>HoraInicio</td>
                <td>HoraTermino</td>
                <td>TurnoId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.diaDaSemana }}</td>
                <td>{{ row.legenda }}</td>
                <td>{{ row.horaInicio }}</td>
                <td>{{ row.horaTermino }}</td>
                <td>{{ row.turnoId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/acad/HorariosService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
