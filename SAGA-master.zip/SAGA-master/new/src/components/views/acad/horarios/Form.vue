<template>
<div id="divHorario">
    <h1>Horario</h1>
    <form id="formHorario">
                <div class="form-group">
                    <label for="diadasemana">DiaDaSemana</label>
                    <input type="text" class="form-control" id="diadasemana" placeholder="DiaDaSemana">
                </div>

                <div class="form-group">
                    <label for="legenda">Legenda</label>
                    <input type="text" class="form-control" id="legenda" placeholder="Legenda">
                </div>

                <div class="form-group">
                    <label for="horainicio">HoraInicio</label>
                    <input type="datetime-local" class="form-control" id="horainicio" placeholder="HoraInicio">
                </div>

                <div class="form-group">
                    <label for="horatermino">HoraTermino</label>
                    <input type="datetime-local" class="form-control" id="horatermino" placeholder="HoraTermino">
                </div>

                <div class="form-group">
                    <label for="turnoid">TurnoId</label>
                    <select class="form-control" id="turnoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
