<template>
<div id="divLogAula">
    <h1>LogAula</h1>
    <form id="formLogAula">
                <div class="form-group">
                    <label for="datainicio">DataInicio</label>
                    <input type="datetime-local" class="form-control" id="datainicio" placeholder="DataInicio">
                </div>

                <div class="form-group">
                    <label for="datatermino">DataTermino</label>
                    <input type="datetime-local" class="form-control" id="datatermino" placeholder="DataTermino">
                </div>

                <div class="form-group">
                    <label for="ambientepedagogicoid">AmbientePedagogicoId</label>
                    <select class="form-control" id="ambientepedagogicoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="professorid">ProfessorId</label>
                    <select class="form-control" id="professorid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="boolterminadaprivate">boolTerminadaprivate</label>
                    <input type="text" class="form-control" id="boolterminadaprivate" placeholder="boolTerminadaprivate">
                </div>
    </form>

</div>
</template>

<script>

</script>
