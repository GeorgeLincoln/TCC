<template>
<div id="divPessoa">
    <h1>Pessoa</h1>
    <form id="formPessoa">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome">
                </div>

                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" id="cpf" placeholder="CPF">
                </div>

                <div class="form-group">
                    <label for="sexo">Sexo</label>
                    <input type="text" class="form-control" id="sexo" placeholder="Sexo">
                </div>

                <div class="form-group">
                    <label for="datanascimento">DataNascimento</label>
                    <input type="datetime-local" class="form-control" id="datanascimento" placeholder="DataNascimento">
                </div>

                <div class="form-group">
                    <label for="imagem">Imagem</label>
                    <input type="text" class="form-control" id="imagem" placeholder="Imagem">
                </div>

                <div class="form-group">
                    <label for="telefone1">Telefone1</label>
                    <input type="text" class="form-control" id="telefone1" placeholder="Telefone1">
                </div>

                <div class="form-group">
                    <label for="telefone2">Telefone2</label>
                    <input type="text" class="form-control" id="telefone2" placeholder="Telefone2">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" placeholder="Email">
                </div>

                <div class="form-group">
                    <label for="instituicaoid">InstituicaoId</label>
                    <select class="form-control" id="instituicaoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
