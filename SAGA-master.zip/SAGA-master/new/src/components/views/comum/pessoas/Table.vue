<template>
<div id="divPessoa">
    <table id="tablePessoa" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Nome</td>
                <td>CPF</td>
                <td>Sexo</td>
                <td>DataNascimento</td>
                <td>Imagem</td>
                <td>Telefone1</td>
                <td>Telefone2</td>
                <td>Email</td>
                <td>InstituicaoId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.nome }}</td>
                <td>{{ row.cPF }}</td>
                <td>{{ row.sexo }}</td>
                <td>{{ row.dataNascimento }}</td>
                <td>{{ row.imagem }}</td>
                <td>{{ row.telefone1 }}</td>
                <td>{{ row.telefone2 }}</td>
                <td>{{ row.email }}</td>
                <td>{{ row.instituicaoId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/comum/PessoasService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
