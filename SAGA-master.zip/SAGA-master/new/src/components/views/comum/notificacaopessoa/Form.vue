<template>
<div id="divNotificacaoPessoa">
    <h1>NotificacaoPessoa</h1>
    <form id="formNotificacaoPessoa">
                <div class="form-group">
                    <label for="pessoaid">PessoaId</label>
                    <select class="form-control" id="pessoaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="notificacaoid">NotificacaoId</label>
                    <select class="form-control" id="notificacaoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="data">Data</label>
                    <input type="datetime-local" class="form-control" id="data" placeholder="Data">
                </div>
    </form>

</div>
</template>

<script>

</script>
