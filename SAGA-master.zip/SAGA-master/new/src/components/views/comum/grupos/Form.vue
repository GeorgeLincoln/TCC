<template>
<div id="divGrupo">
    <h1>Grupo</h1>
    <form id="formGrupo">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" placeholder="Email">
                </div>
    </form>

</div>

</template>

<script>

</script>
