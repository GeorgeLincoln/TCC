<template>
<div id="divOcorrencia">
    <table id="tableOcorrencia" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Descricao</td>
                <td>DataRegistro</td>
                <td>DataResolucao</td>
                <td>PessoaId</td>
                <td>TipoOcorrenciaId</td>
                <td>AmbientePedagógicoId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.descricao }}</td>
                <td>{{ row.dataRegistro }}</td>
                <td>{{ row.dataResolucao }}</td>
                <td>{{ row.pessoaId }}</td>
                <td>{{ row.tipoOcorrenciaId }}</td>
                <td>{{ row.ambientePedagógicoId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/comum/OcorrenciasService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
