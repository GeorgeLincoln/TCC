<template>
<div id="divOcorrencia">
    <h1>Ocorrencia</h1>
    <form id="formOcorrencia">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="dataregistro">DataRegistro</label>
                    <input type="datetime-local" class="form-control" id="dataregistro" placeholder="DataRegistro">
                </div>

                <div class="form-group">
                    <label for="dataresolucao">DataResolucao</label>
                    <input type="datetime-local" class="form-control" id="dataresolucao" placeholder="DataResolucao">
                </div>

                <div class="form-group">
                    <label for="pessoaid">PessoaId</label>
                    <select class="form-control" id="pessoaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tipoocorrenciaid">TipoOcorrenciaId</label>
                    <select class="form-control" id="tipoocorrenciaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="ambientepedagã³gicoid">AmbientePedagÃ³gicoId</label>
                    <select class="form-control" id="ambientepedagã³gicoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
