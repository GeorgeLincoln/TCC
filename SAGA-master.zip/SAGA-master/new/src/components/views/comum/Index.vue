<template>
    <h1> Comum</h1>
</template>

<script>

</script>