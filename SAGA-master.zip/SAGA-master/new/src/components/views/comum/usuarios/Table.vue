<template>
<div id="divUsuario">
    <table id="tableUsuario" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Login</td>
                <td>Senha</td>
                <td>CPF</td>
                <td>Email</td>
                <td>EmailSecundario</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.login }}</td>
                <td>{{ row.senha }}</td>
                <td>{{ row.cPF }}</td>
                <td>{{ row.email }}</td>
                <td>{{ row.emailSecundario }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>

</template>

<script>
import Service  from '@/services/comum/UsuariosService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
