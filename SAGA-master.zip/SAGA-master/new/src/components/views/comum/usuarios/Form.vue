<template>
<div id="divUsuario">
    <h1>Usuario</h1>
    <form id="formUsuario">
                <div class="form-group">
                    <label for="login">Login</label>
                    <input type="text" class="form-control" id="login" placeholder="Login">
                </div>

                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="text" class="form-control" id="senha" placeholder="Senha">
                </div>

                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" id="cpf" placeholder="CPF">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" placeholder="Email">
                </div>

                <div class="form-group">
                    <label for="emailsecundario">EmailSecundario</label>
                    <input type="text" class="form-control" id="emailsecundario" placeholder="EmailSecundario">
                </div>
    </form>

</div>
</template>

<script>

export default {
    data () {
    return {
      selectList: [
        'IFCE',
        'FVJ',
        'Outros'
      ]
    }
  },

    components: {

    },

}
</script>
