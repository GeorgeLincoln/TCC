<template>
<div id="divNotificacaoPessoa">
    <table id="tableNotificacaoPessoa" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>PessoaId</td>
                <td>NotificacaoId</td>
                <td>Data</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.pessoaId }}</td>
                <td>{{ row.notificacaoId }}</td>
                <td>{{ row.data }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Service  from '@/services/comum/NotificacoesService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
