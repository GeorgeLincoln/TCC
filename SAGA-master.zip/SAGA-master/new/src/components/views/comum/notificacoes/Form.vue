<template>
<div id="divNotificacao">
    <h1>Notificacao</h1>
    <form id="formNotificacao">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="data">Data</label>
                    <input type="datetime-local" class="form-control" id="data" placeholder="Data">
                </div>

                <div class="form-group">
                    <label for="tiponotificacaoid">TipoNotificacaoId</label>
                    <select class="form-control" id="tiponotificacaoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
