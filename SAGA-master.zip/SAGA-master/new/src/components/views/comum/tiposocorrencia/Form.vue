<template>
<div id="divTipoOcorrencia">
    <h1>TipoOcorrencia</h1>
    <form id="formTipoOcorrencia">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="grupoid">GrupoId</label>
                    <select class="form-control" id="grupoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>
</template>

<script>

</script>
