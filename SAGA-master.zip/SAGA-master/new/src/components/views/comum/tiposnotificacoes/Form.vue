<template>
<div id="divTipoNotificacao">
    <h1>TipoNotificacao</h1>
    <form id="formTipoNotificacao">
                <div class="form-group">
                    <label for="descricao">Descricao</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="instituicaoid">InstituicaoId</label>
                    <select class="form-control" id="instituicaoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
    </form>

</div>

</template>

<script>

</script>
