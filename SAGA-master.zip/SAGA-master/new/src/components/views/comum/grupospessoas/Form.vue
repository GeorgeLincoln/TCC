<template>

<div id="divGrupoPessoa">
    <h1>GrupoPessoa</h1>
    <form id="formGrupoPessoa">
                <div class="form-group">
                    <label for="grupoid">GrupoId</label>
                    <select class="form-control" id="grupoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="pessoaid">PessoaId</label>
                    <select class="form-control" id="pessoaid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="datainicio">DataInicio</label>
                    <input type="datetime-local" class="form-control" id="datainicio" placeholder="DataInicio">
                </div>

                <div class="form-group">
                    <label for="datatermino">DataTermino</label>
                    <input type="datetime-local" class="form-control" id="datatermino" placeholder="DataTermino">
                </div>

                <div class="form-group">
                    <label for="boolresponsavel">boolResponsavel</label>
                    <input type="text" class="form-control" id="boolresponsavel" placeholder="boolResponsavel">
                </div>
    </form>

</div>
</template>

<script>

</script>
