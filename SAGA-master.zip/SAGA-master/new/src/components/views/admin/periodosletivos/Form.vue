<template>
  <div id="divPeriodoLetivo">
    <form id="formPeriodoLetivo">
      <div class="form-group">
        <label for="codigo">Código Externo</label>
        <input v-if="dto" type="text" class="form-control" id="codigoExterno" ref="codigoExterno" :value="getattr(dto,'codigoExterno')">
        <input v-else type="text" class="form-control" id="codigoExterno" ref="codigoExterno" :value="getattr(dto,'codigoExterno')">
      </div>

      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" ref="nome" :value="getattr(dto,'nome')">
      </div>

      <div class="form-row">
        <div class="col-12">
          <DatePicker id="dataInicio" name="dataInicio" ref="dataInicio" v-bind:defaultDate="dataInicio" @emit-click="getDataInicio">
            <span slot="label">Data de Início {{getattr(dto,'dataInicio')}}</span>
          </DatePicker>
        </div>
        <div class="col-12">
          <DatePicker id="dataTermino" name="dataTermino" ref="dataTermino" v-bind:defaultDate="dataTermino" @emit-click="getDataTermino">
            <span slot="label">Data de Término {{getattr(dto,'dataTermino')}}</span>
          </DatePicker>
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="emitClick(dto)" data-dismiss="modal">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/admin/PeriodosLetivosService';
import BaseFilter from '@/objects/filters/BaseFilter';
import InstituicoesService from '@/services/admin/InstituicoesService';
import DatePicker from '@/components/controls/DatePicker';

const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data() {
    return {
      instituicaoId: null,
      dataInicio: null, // data de inicio selecionada
      dataTermino: null, // data de termino selecionada
      first_form_loading: true,
    };
  },
  components: {
    DatePicker,
  },
  mixins: [getattr],
  methods: {
    getDataInicio(dataInicio) {
      //console.log('[form][getDataInicio]');
      //console.log(dataInicio);
      this.dataInicio = dataInicio;
    },
    getDataTermino(dataTermino) {
      //console.log('[form][getDataTermino]');
      //console.log(dataTermino);
      this.dataTermino = dataTermino;
    },
    clearFields() {
      //console.log('[form][Clear Fields]');
      this.dataInicio = '';
      this.dataTermino = '';
      this.first_form_loading = true;
    },
    emitClick(dto) {
      console.log(dto);
      // get content from input control
      const codigoExterno = this.$refs.codigoExterno.value;
      const nome = this.$refs.nome.value;
      const datainicio = this.dataInicio;
      const datatermino = this.dataTermino;

      let service = new Service();
      if (dto != null) {
        /* Update */
        let objPromisse = service
          .getById(dto.id)
          .then(data => {
            // Atualiza dados
            data.codigoExterno = codigoExterno;
            data.nome = nome;
            data.datainicio = datainicio;
            data.datatermino = datatermino;

            let promise = service
              .update(data, data.id)
              .then(success => {}, err => {});
            this.$emit('emit-click', data);
          })
          .catch(err => {
            console.log(err);
          });
      } else {
        /* Create */
        let newObject = {
          codigoExterno: codigoExterno,
          nome: nome,
          datainicio: datainicio,
          datatermino: datatermino,
          instituicaoId: this.instituicaoId,
        };

        // validacao
        // to do ...
        console.log(newObject);

        let promise = service.create(newObject).then(success => {}, err => {});
        this.$emit('emit-click', newObject);
      }
    },
  },
  props: ['dto'],
  created() {
    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService().getAll(BaseFilter).then(data => {
      this.instituicaoId = data[0].id;
    });
  },
  updated() {
    console.log(new Date());
    console.log('[updated]');

    // Se o form esta sendo carregado pela primeira vez
    if (this.first_form_loading) {
      // dto undefined significa um form de criacao
      if (this.dto != undefined) {
        this.dataInicio = this.dto.dataInicio;
        this.dataTermino = this.dto.dataTermino;
        this.first_form_loading = false;
      }
    }
  },
};
</script>
