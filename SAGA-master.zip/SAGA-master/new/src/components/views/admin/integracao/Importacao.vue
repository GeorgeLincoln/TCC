<template>
  <div id="parametroImportacao">
    <h1>Importação de dados legados</h1>
    <div class="container">
      
      <Imp :titulo="[{label: 'Importação de parâmetros'}]" :rota="['parametros']"></Imp>
      <Imp :titulo="[{label: 'Importação de Nívies de Ensino'}]" :rota="['niveisensino']"></Imp>
      <Imp :titulo="[{label: 'Importação de Blocos'}]" :rota="['blocos']"></Imp>
      <Imp :titulo="[{label: 'Importação de Períodos Letivos'}]" :rota="['periodosletivos']"></Imp>
      <Imp :titulo="[{label: 'Importação de Ambientes Pedagógicos'}]" :rota="['ambientes']"></Imp>
      <!-- <button  @click="reset" type="button" class="btn btn-secondary">Reset</button> -->
    </div>
  </div>
</template>

<script>
import Service from '@/services/admin/ParametrosService';
import Imp from '@/components/controls/Importacao';

export default {
	data() {
		return {};
	},
	components: {
		Imp,
	},
	computed: {},

	methods: {},
};
</script>

<style lang="scss">

</style>
