<template>
  <div id="divBlocos">
    <form id="formBlocos">
      <div class="form-group">
        <label for="nome">Nome</label>
        <input v-if="dto" type="text" class="form-control" id="nome" ref="nome" :value="getattr(dto,'nome')">
        <input v-else type="text" class="form-control" id="nome"  ref="nome" :value="getattr(dto,'nome')">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="emitClick(dto)" data-dismiss="modal">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/admin/BlocosService';
import BaseFilter from '@/objects/filters/BaseFilter';
import InstituicoesService from '@/services/admin/InstituicoesService';

export default {
  data() {
    return {
      instituicaoId: null,
      parametro: null,
    };
  },
  mixins: [getattr],
  methods: {
    emitClick(dto) {
      let service = new Service();
      if (dto != null) {
        /* Update */
        let objPromisse = service
          .getById(dto.id)
          .then(
            data => {
              data.nome = this.$refs.nome.value;
              let promise = service.update(data, data.id).then(
                success => {
                  this.$emit('emit-click', data);
                },
                err => {},
              );
            },
            err => {},
          )
          .catch(err => {
            // ...
          });
      } else {
        /* Create */
        let newObject = {
          nome: this.$refs.nome.value,
          instituicaoId: this.instituicaoId,
        };
        let promise = service.create(newObject).then(success => {}, err => {});
        this.$emit('emit-click', newObject);
      }
    },
  },
  props: ['dto'],
  created() {
    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService().getAll(BaseFilter).then(data => {
      this.instituicaoId = data[0].id;
    });
  },
};
</script>
