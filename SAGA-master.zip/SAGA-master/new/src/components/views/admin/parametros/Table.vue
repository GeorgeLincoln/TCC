<template>
  <div id="divParametro">
    <table id="tableParametro" class="table table-hover">
      <thead class="table-active">
        <tr>
          <th>Chave</th>
          <th>Valor</th>
          <th class="text-right">
            <a class="fa fa-plus-circle" href="#" data-toggle="modal" data-target="#modal" @click="selectRow(index=null)"></a>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(row, index)  in data" v-bind:key="row.id">
          <td>{{ row.chave }}</td>
          <td>{{ row.valor }}</td>
          <td class="text-right">
            <a class="fa fa-edit" href="#" data-toggle="modal" data-target="#modal" @click="selectRow(index)"></a>
            <a class="fa fa-trash" href="#" data-toggle="modal" data-target="#modalDelete" @click="selectRow(index)"></a>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span slot="title" v-if="dto!=null">Editar</span>
      <span slot="title" v-else>Cadastrar</span>
      <div slot="body">
        <Form v-bind="{ dto: dto}" @emit-click="getChanges" />
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"></ModalDelete>

  </div>
</template>

<script>
import Form from '@/components/views/admin/parametros/Form';
import Service from '@/services/admin/ParametrosService';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChange';
import ModalDelete from '@/components/controls/ModalDelete';

const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data() {
    return {
      data: [],
      dto: {},
      index: null,
      currentStatus: null,
      errors: [],
    };
  },
  components: {
    Form,
    ModalChange,
    ModalDelete,
  },
  methods: {
    /**
     * @description Atualiza a linha selecionada na tabela
     * @param {index} indice selecionado na tabela
     * @param {row} linha selecionada na tabela
     */
    selectRow(index) {
      // Atualiza a linha selecionada
      this.index = index;

      // Atualiza o objeto selecionado
      this.dto = this.data[this.index];
    },

    /**
     * @description Obtem o registro modificado de form
     * @param {dto} parametro
     */
    getChanges(dto) {
      if (this.index != null) {
        this.data[this.index].valor = dto.valor;
      } else {
        this.data.push(dto);
      }
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected() {
      // remove pelo id
      let id = this.data[this.index].id;
      new Service().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.data.splice(this.index, 1);
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        },
      );
    },
  },

  created() {
    // carrega dados em tabela
    let promise = new Service().getAll(BaseFilter);
    promise.then(
      //data => {
      //this.data = data;
      //}
      success => {
        this.data = success;
        this.currentStatus = STATUS_SUCCESS;
      },
      err => {
        this.currentStatus = STATUS_FAILED;
      },
    );
  },
};
</script>
