<template>
  <div id="divParametro">
    <form id="formParametro">
      <div class="form-group">
        <label for="chave">Chave</label>
        <input v-if="dto" type="text" class="form-control" id="chave" :value="getattr(dto,'chave')" disabled>
        <input v-else type="text" class="form-control" id="chave"  ref="chave" :value="getattr(dto,'chave')">
      </div>

      <div class="form-group">
        <label for="valor">Valor</label>
        <input type="text" class="form-control" id="valor"  name="valor" ref="valor" :value="getattr(dto,'valor')">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="emitClick(dto)" data-dismiss="modal">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/admin/ParametrosService';
import BaseFilter from '@/objects/filters/BaseFilter';
import InstituicoesService from '@/services/admin/InstituicoesService';

export default {
  data() {
    return {
      instituicaoId: null,
      parametro: null,
      errors: [],
    };
  },
  mixins: [getattr],
  methods: {
    emitClick(dto) {
      let formData = {
        valor: this.$refs.valor.value,
        instituicaoId: this.instituicaoId,
      };
      // Obtem dados do formulario
      if (dto != null) {
        /* Update */
        formData.id = dto.id;

        console.log('Update');
        let objPromisse = new Service()
          .getById(dto.id)
          .then(data => {
            // Atualiza dados
            data.valor = formData.valor;
            let promise = new Service()
              .update(data, data.id)
              .then(success => {}, err => {});
            this.$emit('emit-click', data);
          })
          .catch(err => {
            console.log(err);
            this.errors.push(err);
          });
      } else {
        // Create
        formData.chave = this.$refs.chave.value;

        let promise = new Service().create(formData).then(
          success => {
            this.$emit('emit-click', success);
          },
          err => {
            console.log(err);
            errors.push(err);
          },
        );
      }
    },
  },
  props: ['dto'],
  created() {
    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService().getAll(BaseFilter).then(data => {
      this.instituicaoId = data[0].id;
    });
  },
};
</script>
