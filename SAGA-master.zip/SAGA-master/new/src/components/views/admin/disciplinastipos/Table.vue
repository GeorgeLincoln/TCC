<template>
<div id="divDisciplinaTipo">
    <table id="tableDisciplinaTipo" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Descricao</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.descricao }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/disciplinastipos/Form';
import Service from '@/services/admin/DisciplinasTiposService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},
  created() {
    let service = new Service();
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
