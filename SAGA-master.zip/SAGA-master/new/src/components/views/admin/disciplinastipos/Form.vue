<template>
<div id="divDisciplinaTipo">
    <h1>Disciplina Tipo</h1>
    <form id="formDisciplinaTipo">
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>
</div>
</template>

<script>
</script>
