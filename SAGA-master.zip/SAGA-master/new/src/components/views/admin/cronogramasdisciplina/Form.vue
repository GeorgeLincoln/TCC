<template>
<div id="divCronogramaDisciplina">
    <h1>Etapa do Cronograma</h1>
    <form id="formCronogramaDisciplina">
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="numero">Número</label>
                    <input type="text" class="form-control" id="numero" placeholder="Numero">
                </div>

                <div class="form-group">
                    <label for="situacao">Situação</label>
                    <input type="text" class="form-control" id="situacao" placeholder="Situacao">
                </div>

                <div class="form-group">
                    <label for="disciplina">Nome da Disciplina</label>
                    <select class="form-control">
                      <option v-for="row in dis" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
import DIService from '@/services/admin/DisciplinasService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      dis: [],
      errors: [],
    };
  },
  created() {
    new DIService().getAll(BaseFilter).then(data => (this.dis = data));
  },
};
</script>
