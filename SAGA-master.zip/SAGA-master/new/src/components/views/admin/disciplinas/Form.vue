<template>
  <div id="divDisciplina">
    <form id="formDisciplina">
      <div class="form-group">
        <label for="nome">Nome</label>
        <input v-if="dto" type="text" class="form-control" id="nome" ref="nome" :value="getattr(dto,'nome')">
        <input v-else type="text" class="form-control" id="nome" ref="nome" :value="getattr(dto,'nome')">
      </div>

				<div class="form-group">
        <label for="codigo">Codigo</label>
        <input v-if="dto" type="text" class="form-control" id="codigo" ref="codigo" :value="getattr(dto,'codigo')">
        <input v-else type="text" class="form-control" id="codigo" ref="codigo" :value="getattr(dto,'codigo')">
      </div>

			<div class="form-group">
        <label for="chPratica">CH Pratica</label>
        <input v-if="dto" type="text" class="form-control" id="chPratica" ref="chPratica" :value="getattr(dto,'chPratica')">
        <input v-else type="text" class="form-control" id="chPratica" ref="chPratica" :value="getattr(dto,'chPratica')">
      </div>

			<div class="form-group">
        <label for="chTeorica">CH Teorica</label>
        <input v-if="dto" type="text" class="form-control" id="chTeorica" ref="chTeorica" :value="getattr(dto,'chTeorica')">
        <input v-else type="text" class="form-control" id="chTeorica" ref="chTeorica" :value="getattr(dto,'chTeorica')">
      </div>

			<div class="form-group">
        <label for="credito">Créditos</label>
        <input v-if="dto" type="text" class="form-control" id="credito" ref="credito" :value="getattr(dto,'credito')">
        <input v-else type="text" class="form-control" id="credito" ref="credito" :value="getattr(dto,'credito')">
      </div>

			<div class="form-group">
        <label for="ementa">Ementa</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" ref="ementa" :value="getattr(dto,'ementa')"></textarea>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="emitClick(dto)" data-dismiss="modal">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/admin/DisciplinasService';
import BaseFilter from '@/objects/filters/BaseFilter';
import InstituicoesService from '@/services/admin/InstituicoesService';

export default {
  data() {
    return {
      instituicaoId: null,
      parametro: null,
    };
  },
  mixins: [getattr],
  methods: {
    emitClick(dto) {
      console.log(dto);
      // get content from input control
      const nome = this.$refs.nome.value;
      const codigo = this.$refs.codigo.value;
      const chPratica = this.$refs.chPratica.value;
      const chTeorica = this.$refs.chTeorica.value;
      const credito = this.$refs.credito.value;
      const ementa = this.$refs.ementa.value;
      let service = new Service();
      if (dto != null) {
        /* Update */
        let objPromisse = service
          .getById(dto.id)
          .then(data => {
            // Atualiza dados
            data.nome = nome;
            data.codigo = codigo;
            data.chPratica = chPratica;
            data.chTeorica = chTeorica;
            data.credito = credito;
            data.instituicaoid = this.instituicaoId;
            data.ementa = ementa;

            let promise = service.update(data, data.id).then(
              success => {
                console.log(success);
              },
              err => {},
            );
            this.$emit('emit-click', data);
          })
          .catch(err => {
            console.log(err);
          });
      } else {
        /* Create */
        let newObject = {
          nome: nome,
          codigo: codigo,
          chPratica: chPratica,
          chTeorica: chTeorica,
          credito: credito,
          instituicaoId: this.instituicaoId,
          ementa: ementa,
        };

        // validacao
        // to do ...

        let promise = service.create(newObject).then(success => {}, err => {});
        this.$emit('emit-click', newObject);
      }
    },
  },
  props: ['dto'],
  created() {
    // temporário (até se definir como obter a instituicao corrente)
    new Service().getAll(BaseFilter).then(data => {
      this.instituicaoId = data[0].instituicaoId;
    });
  },
};
</script>
