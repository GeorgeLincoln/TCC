<template>
<div id="divMatrizCurricular">
    <table id="tableMatrizCurricular" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Nome</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.nome }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/matrizescurriculares/Form';
import Service from '@/services/admin/MatrizesCurricularesService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},
  created() {
    let service = new Service();
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
