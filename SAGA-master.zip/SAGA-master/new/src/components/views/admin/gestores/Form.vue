<template>
<div id="divGestor">
    <h1>Gestor</h1>
    <form id="formGestor">
                <div class="form-group">
                    <label for="situacao">Situação</label>
                    <input type="text" class="form-control" id="situacao" placeholder="Situacao">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
</script>
