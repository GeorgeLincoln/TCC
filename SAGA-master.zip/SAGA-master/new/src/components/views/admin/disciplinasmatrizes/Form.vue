<template>

<div id="divDisciplinaMatriz">
    <h1>Matriz de Disciplina</h1>
    <form id="formDisciplinaMatriz">
                <div class="form-group">
                    <label for="disciplina">Período de Oferta</label>
                    <select class="form-control">
                      <option v-for="row in pls" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disciplina">Nome da Disciplina</label>
                    <select class="form-control">
                      <option v-for="row in dis" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disciplinatipoid">Tipo de Disciplina</label>
                    <select class="form-control">
                      <option v-for="row in dts" v-bind:key="row.id" v-bind:value="row.id">{{row.descricao}}</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="matrizcurricularid">Matriz Curricular</label>
                    <select class="form-control">
                      <option v-for="row in mcs" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
import DIService from '@/services/admin/DisciplinasService';
import DTService from '@/services/admin/DisciplinasTiposService';
import MCService from '@/services/admin/MatrizesCurricularesService';
import PLService from '@/services/admin/PeriodosLetivosService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: {},
      pls: [],
      dis: [],
      dts: [],
      mcs: [],
      errors: [],
    };
  },
  created() {
    new PLService().getAll(BaseFilter).then(data => (this.pls = data));
    new DIService().getAll(BaseFilter).then(data => (this.dis = data));
    new DTService().getAll(BaseFilter).then(data => (this.dts = data));
    new MCService().getAll(BaseFilter).then(data => (this.mcs = data));
  },
};
</script>
