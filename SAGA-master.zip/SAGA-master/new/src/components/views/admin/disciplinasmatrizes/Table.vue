<template>
<div id="divDisciplinaMatriz">
    <table id="tableDisciplinaMatriz" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Periodo</td>
                <td>DisciplinaId</td>
                <td>DisciplinaTipoId</td>
                <td>MatrizCurricularId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.periodo }}</td>
                <td>{{ row.disciplinaId }}</td>
                <td>{{ row.disciplinaTipoId }}</td>
                <td>{{ row.matrizCurricularId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/disciplinasmatrizes/Form';
import Service from '@/services/admin/DisciplinasMatrizesService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},
  created() {
    let service = new Service();
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
