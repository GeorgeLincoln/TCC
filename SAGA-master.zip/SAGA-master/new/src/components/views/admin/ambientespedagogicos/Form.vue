<template>
<div id="divAmbientePedagogico">
    <h1>AmbientePedagogico</h1>
    <form id="formAmbientePedagogico">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome">
                </div>

                <div class="form-group">
                    <label for="blocoid">Bloco Id</label>
                    <select class="form-control" id="blocoid">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="enuambientestatusstatusprivate">enuAmbienteStatusStatusprivate</label>
                    <input type="text" class="form-control" id="enuambientestatusstatusprivate" placeholder="enuAmbienteStatusStatusprivate">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
</script>
