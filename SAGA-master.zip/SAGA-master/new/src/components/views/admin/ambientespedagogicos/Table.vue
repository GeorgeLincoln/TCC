<template>
<div id="divAmbientePedagogico">
   <table id="tableAmbientePedagogico" class="table table-hover">
       <thead>
           <tr>
               <th>Id</th>
               <th>Nome</th>
               <th>BlocoId</th>
               <th>Status</th>
               <th></th>
               <th><a class="fa fa-plus-circle"  href="#"></a></th>
           </tr>
       </thead>
       <tbody>
           <tr v-for="row in data" v-bind:key="row.id">
               <td>{{ row.id }}</td>
               <td>{{ row.nome }}</td>
               <td>{{ row.blocoId }}</td>
               <td>{{ row.status }}</td>
               <td><a class="fa fa-edit" href="#"></a></td>
               <td><a class="fa fa-trash"  href="#"></a></td>
           </tr>
       </tbody>
   </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/ambientespedagogicos/Form';
import Service from '@/services/admin/AmbientesPedagogicosService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},

  created() {
    let service = new Service();

    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>


