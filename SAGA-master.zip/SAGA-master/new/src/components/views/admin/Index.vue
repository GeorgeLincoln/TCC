<template>
    <h1> Administrativo</h1>
</template>

<script>

</script>