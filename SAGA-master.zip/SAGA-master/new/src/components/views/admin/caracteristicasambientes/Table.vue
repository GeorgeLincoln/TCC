<template>
<div id="divCaracteristicaAmbiente">
    <table id="tableCaracteristicaAmbiente" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Descricao</td>
                <td>AmbientePedagogicoId</td>
                <td>TipoCaracteristicaId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.descricao }}</td>
                <td>{{ row.ambientePedagogicoId }}</td>
                <td>{{ row.tipoCaracteristicaId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/caracteristicasambientes/Form';
import Service from '@/services/admin/CaracteristicasAmbientesService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},
  created() {
    let service = new Service();
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
