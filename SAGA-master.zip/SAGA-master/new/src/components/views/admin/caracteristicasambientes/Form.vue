<template>
<div id="divCaracteristicaAmbiente">
    <h1>Característica Ambiente</h1>
    <form id="formCaracteristicaAmbiente">
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" id="descricao" placeholder="Descricao">
                </div>

                <div class="form-group">
                    <label for="ambientepedagogicoid">Ambiente Pedagogico Id</label>
                    <select class="form-control">
                      <option v-for="row in aps" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tipocaracteristicaid">Tipo Caracteristica Id</label>
                    <select class="form-control">
                      <option v-for="row in tcs" v-bind:key="row.id" v-bind:value="row.id">{{row.descricao}}</option>
                    </select>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
import APService from '@/services/admin/AmbientesPedagogicosService';
import TCService from '@/services/admin/TiposCaracteristicasService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      aps: [],
      tcs: [],
      errors: [],
    };
  },
  created() {
    new APService().getAll(BaseFilter).then(data => (this.aps = data));
    new TCService().getAll(BaseFilter).then(data => (this.tcs = data));
  },
};
</script>
