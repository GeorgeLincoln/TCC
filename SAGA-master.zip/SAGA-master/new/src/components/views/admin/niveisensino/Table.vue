<template>
<div id="divNivelEnsino">
    <table id="tableNivelEnsino" class="table">
        <thead>
            <tr>
                <td>Id</td>
                <td>Nome</td>
                <td>InstituicaoId</td>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in data" v-bind:key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.nome }}</td>
                <td>{{ row.instituicaoId }}</td>
                <td><a class="fa fa-edit" href="#"></a></td>
                <td><a class="fa fa-trash"  href="#"></a></td>
            </tr>
        </tbody>
    </table>
</div>
</template>

<script>
import Form from '@/components/views/admin/niveisensino/Form';
import Service from '@/services/admin/NiveisEnsinoService';
import BaseFilter from '@/objects/filters/BaseFilter';

export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },
  components: {Form},
  created() {
    let service = new Service();
    
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
