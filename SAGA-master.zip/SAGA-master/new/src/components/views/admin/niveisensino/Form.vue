<template>
<div id="divNivelEnsino">
    <h1>Nível Ensino</h1>
    <form id="formNivelEnsino">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" placeholder="Nome">
                </div>

                <div class="form-group">
                    <label for="instituicaoid">Ambiente Pedagógico</label>
                    <select class="form-control" id="ambiente">
                      <option v-for="row in data" v-bind:key="row.id" v-bind:value="row.id">{{row.nome}}</option>
                    </select>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary"  data-dismiss="modal">Salvar</button>
                </div>
    </form>

</div>
</template>

<script>
import Service from '@/services/admin/InstituicoesService';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data() {
    return {
      data: [],
      errors: [],
    };
  },

  created() {
    let service = new Service();
    
 
    
    let promise = service.getAll(BaseFilter);
    promise.then(data => (this.data = data));
  },
};
</script>
