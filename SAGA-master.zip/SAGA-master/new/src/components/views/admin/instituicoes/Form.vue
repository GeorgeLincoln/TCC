<template>
  <div id="divIntituicao">
    <form id="formInstituicao">
      <div class="form-row">
        <div class="form-group col-md-9">
          <label for="nome">Nome</label>
          <input v-if="dto" type="text" class="form-control" id="nome" ref="nome" :value="getattr(dto,'nome')">
          <input v-else type="text" class="form-control" id="nome" ref="nome" :value="getattr(dto,'nome')">
        </div>
        <div class="form-group col-md-3">
          <label for="sigla">Sigla</label>
          <input v-if="dto" type="text" class="form-control" id="sigla" ref="sigla" :value="getattr(dto,'sigla')">
          <input v-else type="text" class="form-control" id="sigla" ref="sigla" :value="getattr(dto,'sigla')">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-12">
          <label for="imagem">Imagem</label>
          <input type="text" class="form-control" id="imagem" name="imagem" ref="imagem" :value="getattr(dto,'imagem')">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="bairro">Bairro</label>
          <input type="text" class="form-control" id="bairro" name="bairro" ref="bairro" :value="getattr(dto,'bairro')">
        </div>

        <div class="form-group col-md-4">
          <label for="cep">CEP</label>
          <input type="text" class="form-control" id="cep" name="cep" ref="cep" :value="getattr(dto,'cep')">
        </div>

        <div class="form-group col-md-4">
          <label for="numero">Número</label>
          <input type="text" class="form-control" id="numero" name="numero" ref="numero" :value="getattr(dto,'numero')">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group  col-md-12">
          <label for="rua">Rua</label>
          <input type="text" class="form-control" id="rua" name="rua" ref="rua" :value="getattr(dto,'rua')">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="uf">Estado</label>
          <select class="form-control" id="uf" name="uf" ref="uf" v-model="uf">
            <option v-for="row  in estadosBrasil" v-bind:key="row.sigla" :value="row.sigla">{{row.nome}}</option>
          </select>
          <small id="emailHelp" class="form-text text-muted text-center">{{uf}}</small>
        </div>

        <div class="form-group col-md-6">
          <label for="uf">Cidade</label>
          <select class="form-control" id="cidade" name="cidade" ref="cidade" v-model="cidade">
            <option v-for="row  in cidades" v-bind:key="row" :value="row">{{row}}</option>
          </select>
          <small id=" emailHelp" class="form-text text-muted text-center">{{cidade}}</small>

        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-12">
          <label for="email">Email</label>
          <input type="text" class="form-control" id="email" name="email" ref="email" :value="getattr(dto, 'email')">
        </div>
      </div>


      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="telefone1">Telefone 1</label>
          <input type="text" class="form-control" id="telefone1" name="telefone1" ref="telefone1" :value="getattr(dto,
              'telefone1')">
        </div>

        <div class="form-group col-md-6">
          <label for="telefone2">Telefone 2</label>
          <input type="text" class="form-control" id="telefone2" name="telefone2" ref="telefone2" :value="getattr(dto,
              'telefone2')">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="clearFields()">Cancelar</button>
        <button type="button" class="btn btn-primary" @click="emitClick(dto)" data-dismiss="modal">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattrMixin from '@/components/mixins/getattr';
import estadosMixin from '@/components/mixins/estados';
import Service from '@/services/admin/InstituicoesService';
import BaseFilter from '@/objects/filters/BaseFilter';

export default {
  props: ['dto'] /* dto is passed in table component to this form */,
  mixins: [getattrMixin, estadosMixin],
  data() {
    return {
      estados: [],
      uf: '',
      cidades: [],
      cidade: '',
      first_form_loading: true,
    };
  },
  watch: {
    uf: function() {
      console.log(this.$refs);
      console.log('uf:' + uf + '.');
      console.log(uf);
      this.atualizarCidades();

      console.log('[watch] dto:');
      console.log(this.dto);
      console.log('[watch] uf dto: ' + this.getattr(this.dto, 'uf'));
    },
  },
  methods: {
    atualizarEstado() {
      let uf_dto = this.getattr(this.dto, 'uf');
      console.log(new Date());
    },
    atualizarCidades() {
      for (var i = 0; i < this.estadosBrasil.length; i++) {
        if (this.estadosBrasil[i].sigla == this.uf) {
          this.cidades = this.estadosBrasil[i].cidades;
          break;
        }
      }
    },
    emitClick(dto) {
      // get content from form

      console.log('[emitClick] $refs');
      console.log(this.$refs);

      console.log('[emitClick] formData');
      let formData = {
        nome: this.$refs.nome.value,
        sigla: this.$refs.sigla.value,
        imagem: this.$refs.imagem.value,
        bairro: this.$refs.bairro.value,
        cep: this.$refs.cep.value,
        numero: this.$refs.numero.value,
        rua: this.$refs.rua.value,
        uf: this.uf,
        cidade: this.cidade,
        email: this.$refs.email.value,
        telefone1: this.$refs.telefone1.value,
        telefone2: this.$refs.telefone2.value,
      };

      console.log('[emitClick] formData');
      console.log(formData);

      let service = new Service();
      if (dto != null) {
        /* Form Update */
        let objPromisse = service
          .getById(dto.id)
          .then(
            success => {
              let data = success;

              // performs any form validation
              // to do ...

              data.nome = formData.nome;
              data.sigla = formData.sigla;
              data.imagem = formData.imagem;
              data.bairro = formData.bairro;
              data.cep = formData.cep;
              data.numero = formData.numero;
              data.rua = formData.rua;
              data.uf = formData.uf;
              data.cidade = formData.cidade;
              data.email = formData.email;
              data.telefone1 = formData.telefone1;
              data.telefone2 = formData.telefone2;

              console.log('data to be updated:');
              console.log(data);

              let promise = service.update(data, data.id).then(
                success => {
                  this.$emit('emit-click', data);
                },
                err => {
                  console.log(err);
                },
              );
            },
            err => {
              console.log(err);
            },
          )
          .catch(err => {
            // ...
          });
      } else {
        /* Create */
        let promise = service.create(formData).then(
          success => {
            console.log(success);
            this.$emit('emit-click', success);
          },
          err => {
            console.log(err);
          },
        );
      }

      this.clearFields();
    },
    clearFields() {
      console.log('[Clear Fields]');
      this.estado = '';
      this.cidade = '';
      this.first_form_loading = true;
    },
  },
  beforeCreate() {
    //console.log('[beforeCreate]');
  },
  created() {
    //console.log('[created]');
    this.atualizarEstado();
  },
  mounted() {
    //console.log('[mounted]');
  },
  updated() {
    console.log(new Date());
    console.log('[updated]');

    // Se o form esta sendo carregado pela primeira vez
    if (this.first_form_loading) {
      // dto undefined significa um form de criacao
      if (this.dto != undefined) {
        this.uf = this.getattr(this.dto, 'uf');
        this.cidade = this.getattr(this.dto, 'cidade');
        this.first_form_loading = false;
      }

      console.log('[updated] uf:' + this.uf);
      console.log('[updated] cidade:' + this.cidade);
    }
  },
};
</script>
