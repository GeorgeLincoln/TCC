<template>
  <div id="divInstituicao">
    <h3>Instituições Cadastradas</h3>
    <table id="tableInstituicao" class="table table-hover">
      <thead class="table-dark">
        <tr>
          <th>#</th>
          <th>Nome</th>
          <th>Sigla</th>
          <th>Bairro</th>
          <th>Cep</th>
          <th>Numero</th>
          <th>Rua</th>
          <th>UF</th>
          <th>Cidade</th>
          <th>Email</th>
          <th>Tel 1</th>
          <th>Tel 2</th>
          <th class="text-right">
            <a class="fa fa-plus-circle" href="#" data-toggle="modal" data-target="#modal" @click="selectRow(index=null)" style="color:white"></a>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(row, index)  in data" v-bind:key="row.id">
          <td>{{ row.id }}</td>
          <td>{{ row.nome }}</td>
          <td>{{ row.sigla }}</td>
          <td>{{ row.bairro }}</td>
          <td>{{ row.cep }}</td>
          <td>{{ row.numero }}</td>
          <td>{{ row.rua }}</td>
          <td>{{ row.uf }}</td>
          <td>{{ row.cidade }}</td>
          <td>{{ row.email }}</td>
          <td>{{ row.telefone1 }}</td>
          <td>{{ row.telefone2 }}</td>
          <td class="text-right">
            <a class="fa fa-edit" href="#" data-toggle="modal" data-target="#modal" @click="selectRow(index)"></a>
            <a class="fa fa-trash" href="#" data-toggle="modal" data-target="#modalDelete" @click="selectRow(index)"></a>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span slot="title" v-if="dto!=null">Editar  Instituição</span>
      <span slot="title" v-else>Cadastrar Instituição</span>
      <div slot="body">
        <Form v-bind="{ dto: dto}" @emit-click="getChanges" />
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"></ModalDelete>

  </div>
</template>

<script>
import Form from '@/components/views/admin/instituicoes/Form';
import Service from '@/services/admin/InstituicoesService';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChange';
import ModalDelete from '@/components/controls/ModalDelete';
import VueAuthImage from 'vue-auth-image';
import Mgr from '@/services/SecurityService';
const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data() {
    return {
      data: [],
      dto: {},
      index: null,
      currentStatus: null,
      errors: [],
    };
  },
  components: {
    Form,
    ModalChange,
    ModalDelete,
  },
  methods: {
    /**
     * @description Atualiza a linha selecionada na tabela
     * @param {index} indice selecionado na tabela
     * @param {row} linha selecionada na tabela
     */
    selectRow(index) {
      // Atualiza a linha selecionada
      this.index = index;

      // Atualiza o objeto selecionado
      this.dto = this.data[this.index];
    },

    /**
     * @description Obtem o registro modificado de form
     * @param {dto} parametro
     */
    getChanges(dto) {
      console.log('[getChanges]');
      console.log(dto);
      if (this.index != null) {
        this.data[this.index].nome = dto.nome;
        this.data[this.index].sigla = dto.sigla;
        this.data[this.index].imagem = dto.imagem;
        this.data[this.index].bairro = dto.bairro;
        this.data[this.index].cep = dto.cep;
        this.data[this.index].numero = dto.numero;
        this.data[this.index].rua = dto.rua;
        this.data[this.index].uf = dto.uf;
        this.data[this.index].cidade = dto.cidade;
        this.data[this.index].email = dto.email;
        this.data[this.index].telefone1 = dto.telefone1;
        this.data[this.index].telefone2 = dto.telefone2;
      } else {
        // Atualiza pagina
        //window.location.reload();
        this.data.push(dto);
      }
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected() {
      // remove pelo id
      let id = this.data[this.index].id;
      new Service().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.data.splice(this.index, 1);
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        },
      );
    },
  },

  created() {
    Vue.use(VueAuthImage);
    var user = new Mgr()
    user.getUser().then(
       sucess => {        
        axios.defaults.headers.common['Authorization'] = "Bearer " + sucess.access_token       
      },err=>{
      console.log(err)          
    })
    // carrega dados em tabela
    let promise = new Service().getAll(BaseFilter);
    promise.then(
      //data => {
      //this.data = data;
      //}
      success => {
        this.data = success;
        this.currentStatus = STATUS_SUCCESS;
      },
      err => {
        this.currentStatus = STATUS_FAILED;
      },
    );
  },
};
</script>

<style scoped>
table thead {
  background-color: #37394e;
}
table tbody td a {
  color: #37394e;
}
</style>
