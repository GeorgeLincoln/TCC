<template>
<div id="divCurso">
    <h3>Cursos</h3>
    <table id="tableCurso" class="table table-hover">
        <thead class="text-light">
            <tr>
                <th>Codigo</th>
                <th>Nome</th>
                <th>Data de Início</th>
                <th>Data de Término</th>
                <th>Coordenador</th>
                <th>Nível de Ensino</th>
                <th></th>
                <th><a class="fa fa-plus-circle" href="#" data-toggle="modal" data-target="#modal" data-backdrop="static" data-keyboard="false" @click="selectRow(index=null, 'create')" style="color:white"></a></th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="(row, index)  in data" v-bind:key="row.id">
                <td>{{ row.codigo }}</td>
                <td>{{ row.nome }}</td>
                <td>{{ formatedDate(row.dataInicio) }}</td>
                <td>{{ formatedDate(row.dataTermino) }}</td>
                <td><i class="fa fa-user"></i> {{ row.gestor }}</td>
                <td>{{ row.nivelEnsino }}</td>
                <td><a class="fa fa-edit" href="#" data-toggle="modal" data-target="#modal" data-backdrop="static" data-keyboard="false" @click="selectRow(index, 'update')"></a></td>
                <td> <a class="fa fa-trash" href="#" data-toggle="modal" data-target="#modalDelete" data-backdrop="static" data-keyboard="false" @click="selectRow(index)"></a></td>
            </tr>
        </tbody>
    </table>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span slot="title" v-if="dto!=null">Editar  Curso</span>
      <span slot="title" v-else>Cadastrar Curso</span>
      <div slot="body">
        <Form v-if="dto!=null" v-bind="{ dto: dto, action:action}" @emit-click="getChanges"  @close-click="closeClick" />
        <Form v-else v-bind="{ dto: dto, action:action}" @emit-click="getChanges" @close-click="closeClick" />
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"></ModalDelete>

</div>
</template>


<script>
import Form from '@/components/views/admin/cursos/Form';
import CursosService from '@/services/admin/CursosService';
import NEService from '@/services/admin/NiveisEnsinoService';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChange';
import ModalDelete from '@/components/controls/ModalDelete';

const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data() {
    return {
      dto: null,
      action: null,
      index: null,
      niveis: {},
      gestores: {},
      aux: [],
      data: [],
      errors: [],
      tempGestor: null,
    };
  },
  components: {
    Form,
    ModalChange,
    ModalDelete,
  },
  methods: {
    formatedDate(strData) {
      var data = new Date(strData);
      var dia = data.getDate();
      if (dia.toString().length == 1) dia = '0' + dia;
      var mes = data.getMonth() + 1;
      if (mes.toString().length == 1) mes = '0' + mes;
      var ano = data.getFullYear();
      return dia + '/' + mes + '/' + ano;
    },
    selectRow(index, action) {
      console.log('[table][selectRow]' + index);
      // Atualiza a linha selecionada
      this.index = index;
      this.action = action;
      // Atualiza o objeto selecionado
      this.dto = this.data[this.index];
    },

    /**
     * @description Obtem o registro modificado do form
     * @param {dto} parametro
     */
    getChanges(dto) {
      console.log('[table][getChanges]');
      console.log(dto);
      if (this.index != null) {
        this.data[this.index].codigo = dto.codigo;
        this.data[this.index].nome = dto.nome;
        this.data[this.index].nome = dto.nome;
        this.data[this.index].dataInicio = dto.dataInicio;
        this.data[this.index].dataTermino = dto.dataTermino;
        this.data[this.index].gestor = dto.gestor;
        this.data[this.index].nivelEnsino = dto.nivelEnsino;
      } else {
        // Atualiza pagina
        this.data.push(dto);
      }
    },
    closeClick() {
      console.log('[table][closeClick]' + this.index);
      this.dto = null;
      this.action = null;
      this.index = null;
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected() {
      // remove pelo id
      let id = this.data[this.index].id;
      new CursosService().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.data.splice(this.index, 1);
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        },
      );
    },
  },
  watch: {
    index: function() {
      console.log('[table][watch][index]' + this.index);
    },
  },
  created() {
    // cursos
    new CursosService().getAll(BaseFilter, 'view').then(
      success => {
        this.data = success;
        this.currentStatus = STATUS_SUCCESS;
      },
      err => {
        this.currentStatus = STATUS_FAILED;
      },
    );
  },
  mounted() {
    console.log('[table][mounted]' + this.index);
  },
  updated() {
    console.log('[table][updated]' + this.index);
  },
};
</script>

<style scoped>
table thead {
  background-color: #37394e;
}
table tbody td a {
  color: #37394e;
}
</style>

