<template>
  <div id="divCurso">
    <form id="formCurso">
      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" ref="nome" placeholder="Nome" :value="getattr(dto,'nome')">
      </div>

      <div class="form-row">
        <div class="col-4">
          <div class="form-group">
            <label for="codigo">Codigo</label>
            <input type="text" class="form-control" id="codigo" name="codigo" ref="codigo" placeholder="Codigo" :value="getattr(dto,'codigo')">
          </div>
        </div>
        <div class="col-8">
          <div class="form-group">
            <label for="nivelEnsino">Nível de Ensino</label>
            <select class="form-control" id="nivelEnsino" name="nivelEnsino" ref="nivelEnsino" v-model="nivelEnsino">
              <option v-for="row in ne" v-bind:key="row.id" v-bind:value="row">{{row.nome}}</option>
            </select>
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="col-12">
          <DatePicker id="dataInicio" name="dataInicio" ref="dataInicio" v-bind:defaultDate="dataInicio" @emit-click="getDataInicio">
            <span slot="label">Data de Início {{getattr(dto,'dataInicio')}}</span>
          </DatePicker>
        </div>
        <div class="col-12">
          <DatePicker id="dataTermino" name="dataTermino" ref="dataTermino" v-bind:defaultDate="dataTermino" @emit-click="getDataTermino">
            <span slot="label">Data de Término {{getattr(dto,'dataTermino')}}</span>
          </DatePicker>
        </div>
      </div>

      <div class="form-group">
        <label for="gestor">Coordenador</label>
        <select class="form-control" id="gestor" name="gestor" ref="gestor" v-model="gestor">
          <option v-for="row in ge" v-bind:key="row.id" v-bind:value="row">{{row.nome}}</option>
        </select>
      </div>


      <div class="modal-footer">
        <button type="button" id="btnCancelar" class="btn btn-secondary" @click="closeClick()">Cancelar</button>
        <button type="button" id="btnSalvar" class="btn btn-primary" @click="emitClick(dto)">Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattrMixin from '@/components/mixins/getattr';
import Service from '@/services/admin/CursosService';
import GEService from '@/services/admin/GestoresService';
import NEService from '@/services/admin/NiveisEnsinoService';
import BaseFilter from '@/objects/filters/BaseFilter';
import DatePicker from '@/components/controls/DatePicker';

const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  props: ['dto', 'action'] /* dto is passed in table component to this form */,
  mixins: [getattrMixin],

  data() {
    return {
      dataInicio: null, // data de inicio selecionada
      dataTermino: null, // data de termino selecionada
      gestor: null, // gestor selecionado no form
      nivelEnsino: null, // nivel selecionado no form
      ge: [], // array gestores
      ne: [], // array niveis de ensino
      cursos: [], // array cursos
      errors: [],
      first_form_loading: true,
      dismiss: '',
    };
  },
  components: {
    DatePicker,
  },
  methods: {
    getDataInicio(dataInicio) {
      //console.log('[form][getDataInicio]');
      //console.log(dataInicio);
      this.dataInicio = dataInicio;
    },
    getDataTermino(dataTermino) {
      //console.log('[form][getDataTermino]');
      //console.log(dataTermino);
      this.dataTermino = dataTermino;
    },
    closeClick() {
      //console.log('[form][closeClick]');
      this.clearFields();
      var btn = document.getElementById('btnCancelar');
      btn.setAttribute('data-dismiss', 'modal');
      this.$emit('close-click');
    },
    emitClick(dto) {
      try {
        //console.log('[form][emitClick]');
        // get form data
        let formData = {
          nome: this.$refs.nome.value,
          codigo: this.$refs.codigo.value,
          dataInicio: this.dataInicio,
          dataTermino: this.dataTermino,
          nivelEnsinoId: this.nivelEnsino.id,
          nivelEnsino: this.nivelEnsino.nome,
          gestorId: this.gestor.id,
          gestor: this.gestor.nome,
        };

        //console.log('[form][emitClick] formData');
        //console.log(formData);

        let service = new Service();
        if (dto != null) {
          /* Form Update */
          let objPromisse = service
            .getById(dto.id)
            .then(
              success => {
                let data = success;
                data.codigo = formData.codigo;
                data.nome = formData.nome;
                data.dataInicio = formData.dataInicio;
                data.dataTermino = formData.dataTermino;
                data.gestorId = formData.gestorId;
                data.nivelEnsinoId = formData.nivelEnsinoId;

                //console.log('[form][emitClick] data:');
                //console.log(data);

                let promise = service.update(data, data.id).then(
                  success => {
                    this.$emit('emit-click', formData);
                    this.clearFields();
                    var btn = document.getElementById('btnSalvar');
                    btn.setAttribute('data-dismiss', 'modal');
                  },
                  err => {
                    throw err;
                  },
                );
              },
              err => {
                throw err;
              },
            )
            .catch(err => {
              this.errors.push(
                '[form][emitClick] Erro ao atualizar formulário',
              );
              //console.log('[form][emitClick] Erro ao atualizar formulário');
            });
        } else {
          /* Create */
          let data = {};
          data.codigo = formData.codigo;
          data.nome = formData.nome;
          data.dataInicio = formData.dataInicio;
          data.dataTermino = formData.dataTermino;
          data.gestorId = formData.gestorId;
          data.nivelEnsinoId = formData.nivelEnsinoId;

          let promise = service.create(data).then(
            success => {
              formData.id = success.id;
              // envia registro para a tabela
              this.$emit('emit-click', formData);
              this.clearFields();
              var btn = document.getElementById('btnSalvar');
              btn.setAttribute('data-dismiss', 'modal');
            },
            err => {
              throw err;
            },
          );
        }
      } catch (err) {
        console.log(err);
      }
    },
    clearFields() {
      //console.log('[form][Clear Fields]');
      this.nivelEnsino = null;
      this.gestor = null;
      this.dataInicio = '';
      this.dataTermino = '';
      this.first_form_loading = true;
    },
  },
  watch: {
    dto: function() {
      //console.log('[form][watch][dto]');
    },
  },
  created() {
    new GEService()
      .getAll(BaseFilter, 'dropdown')
      .then(data => (this.ge = data));
    new NEService().getAll(BaseFilter).then(data => (this.ne = data));
  },
  updated() {
    if (this.action == 'update') {
      if (this.dto != undefined) {
        //console.log('[form][updated hook] put form');
        if (this.gestor == null || this.gestor == undefined)
          this.gestor = this.ge.find(
            g => g.id === this.getattr(this.dto, 'gestorId'),
          );
        if (this.nivelEnsino == null || this.nivelEnsino == undefined)
          this.nivelEnsino = this.ne.find(
            ne => ne.id === this.getattr(this.dto, 'nivelEnsinoId'),
          );
        if (this.first_form_loading) {
          //console.log('[form][updated hook] put form');
          this.dataInicio = this.dto.dataInicio;
          this.dataTermino = this.dto.dataTermino;
          this.first_form_loading = false;
        }
        //console.log(this.dto.dataTermino);
        //this.dataInicio = this.dto.dataInicio;
        //this.dataTermino = this.dto.dataTermino;
      }
    } else if (this.action == 'create') {
      //console.log('[form][updated hook] post form');
    } else {
      //console.log('[form][updated hook] unknown form');
      this.clearFields();
    }
  },
};
</script>
