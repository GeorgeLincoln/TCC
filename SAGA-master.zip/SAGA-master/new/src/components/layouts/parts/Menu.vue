<template>
  <div id="menu">
    <div class="menu-content">
      <div class="menu-content-title">Navegação</div>
      <ul class="navigation">
        <li :class="['navigation-item', { active : item.isActive }]" v-for="(item, index) in navegacao" :key="index">
          <router-link :to="item.href" @click.native="menuActive(item)">
            <i :class="item.icone"></i>
            <span>{{ item.titulo }}</span>
          </router-link>
          <ul class="navigation-submenu">
            <li v-for="(sub, index) in item.submenu" :key="index">
              <router-link :to="sub.href" @click.native="menuActive(sub)">
                <i :class="sub.icone"></i>
                <span>{{ sub.titulo }}</span>
              </router-link>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      navegacao: [
        {
          titulo: 'Dashboard de salas',
          href: '/dashboard',
          icone: 'fab fa-buromobelexperte fa-fw',
          isActive: false,
        },
        {
          titulo: 'Instituição (Admin)',
          href: 'teste',
          icone: 'fas fa-university fa-fw',
          isActive: false,
          submenu: [
            {
              titulo: 'Ambientes Pedagógicos',
              href: '/admin/ambientes/table',
            },
            { titulo: 'Blocos', href: '/admin/blocos/table' },
            {
              titulo: 'Caracteristicas de Ambientes',
              href: '/admin/caracteristicasambientes/table',
            },
            {
              titulo: 'Cronogramas de Disciplina',
              href: '/admin/cronogramasdisciplina/table',
            },
            { titulo: 'Cursos', href: '/admin/cursos/table' },
            { titulo: 'disciplinas', href: '/admin/disciplinas/table' },
            {
              titulo: 'Matrizes de Disciplinas',
              href: '/admin/disciplinasmatrizes/table',
            },
            {
              titulo: 'Tipos de Disciplinas',
              href: '/admin/disciplinastipos/table',
            },
            { titulo: 'Gestores', href: '/admin/gestores/table' },
            { titulo: 'Instituicoes', href: '/admin/instituicoes/table' },
            {
              titulo: 'Matrizescurriculares',
              href: '/admin/matrizescurriculares/table',
            },
            { titulo: 'Niveis de Ensino', href: '/admin/niveisensino/table' },
            { titulo: 'Parâmetros', href: '/admin/parametros/table' },
            {
              titulo: 'Periodos Letivos',
              href: '/admin/periodosletivos/table',
            },
            {
              titulo: 'Tipos de Caracteristicas',
              href: '/admin/tiposcaracteristicas/table',
            },
          ],
        },
        {
          titulo: 'Instituição (Acad)',
          href: 'teste',
          icone: 'fas fa-university fa-fw',
          isActive: false,
          submenu: [
            { titulo: 'Alunos', href: '/acad/alunos/table' },
            { titulo: 'Aulas', href: '/acad/aulas/table' },
            { titulo: 'Cartoesrfid', href: '/acad/cartoesrfid/table' },
            {
              titulo: 'Disciplinas Ofertadas',
              href: '/acad/disciplinasofertadas/table',
            },
            {
              titulo: 'dispositivos de coleta Rfid',
              href: '/acad/dispositivoscoletarfid/table',
            },
            { titulo: 'Etapas', href: '/acad/etapas/table' },
            { titulo: 'Horarios', href: '/acad/horarios/table' },
            { titulo: 'Log presenca', href: '/acad/logpresenca/table' },
            { titulo: 'Logs aulas', href: '/acad/logsaulas/table' },
            { titulo: 'Mapas salas', href: '/acad/mapassalas/table' },
            {
              titulo: 'Materiais Didaticos',
              href: '/acad/materiaisdidaticos/table',
            },
            {
              titulo: 'MateriaisDisciplinas',
              href: '/acad/materiaisdisciplinas/table',
            },
            {
              titulo: 'Matriculas alunos',
              href: '/acad/matriculasalunos/table',
            },
            {
              titulo: 'Metodologias Ativas',
              href: '/acad/metodologiasativas/table',
            },
            { titulo: 'Notas', href: '/acad/notas/table' },
            { titulo: 'Presencas', href: '/acad/presencas/table' },
            { titulo: 'Professores', href: '/acad/professores/table' },
            { titulo: 'Turnos', href: '/acad/turnos/table' },
          ],
        },
        {
          titulo: 'Instituição (Comum)',
          href: 'teste',
          icone: 'fas fa-university fa-fw',
          isActive: false,
          submenu: [
            {
              titulo: 'Grupos',
              href: '/comum/grupos/table',
            },
            {
              titulo: 'Grupos de Pessoas',
              href: '/comum/grupospessoas/table',
            },
            {
              titulo: 'Notificacaopessoa',
              href: '/comum/notificacaopessoa/table',
            },
            {
              titulo: 'Notificações',
              href: '/comum/notificacoes/table',
            },
            {
              titulo: 'Ocorrencias',
              href: '/comum/ocorrencias/table',
            },
            {
              titulo: 'Pessoas',
              href: '/comum/pessoas/table',
            },
            {
              titulo: 'Tipos de Notificações',
              href: '/comum/tiposnotificacoes/table',
            },
            {
              titulo: 'Tipos de Ocorrência',
              href: '/comum/tiposocorrencia/table',
            },
            {
              titulo: 'Usuários',
              href: '/comum/usuarios/table',
            },
          ],
        },
      ],
    };
  },
  methods: {
    menuActive(item) {
      item.isActive = !item.isActive;
    },
  },
};
</script>
