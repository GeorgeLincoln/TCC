<template>
  <nav id="topo" class="navbar navbar-expand-lg">
    <a href="#" class="navbar-brand">Logo</a>
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">A Instituição</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Cursos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Fale Conosco</a>
      </li>
      <li class="nav-item usuario dropdown">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="https://cdn9.littlethings.com/app/uploads/2015/08/11223845_10153614807853933_1709727921969620668_n-1-600x600.jpg" class="rounded-circle" width="34" alt="">
          <span>NOME</span>
        </a>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Configurações da conta</a>
          <a class="dropdown-item" href="#">Sair</a>
        </div>
      </li>

      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="fab fa-buromobelexperte"></i>
        </a>
      </li>

      <li class="nav-item notificacoes">
        <a href="#" class="nav-link">
          <i class="fas fa-bell"></i>
        </a>
      </li>
    </ul>
  </nav>
</template>

<script>
export default {};
</script>
