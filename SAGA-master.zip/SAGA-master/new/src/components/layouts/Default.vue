<template>
  <div id="default" v-bind:class="{ 'menu-collapsed': menuCollapsed }">
    <layout-topo v-if="['login', 'dashboard'].indexOf($route.name) == -1"></layout-topo>
    <layout-menu v-if="['login', 'dashboard'].indexOf($route.name) == -1"></layout-menu>
    <div class="content">
      <div class="container-fluid">
        <router-view/>
      </div>
    </div>
  </div>
</template>

<script>
import LayoutTopo from './parts/Topo.vue';
import LayoutMenu from './parts/Menu.vue';

export default {
  data() {
    return {
      connection: null,
      AmbientePedagogico: {},
    };
  },
  components: {
    LayoutTopo,
    LayoutMenu,
  },
  computed: {
    menuCollapsed() {
      return this.$store.state.layout.menuCollapsed;
    },
  },
  beforeCreate() {
    let signalR = require('../../signalr-client.js');
  },
  created() {
    this.connection = new signalR.HubConnection(
      'http://localhost:63637/dashboard',
    );
  },
  mounted() {
    this.connection
      .start()
      .then(() => {
        console.log('Started');
      })
      .catch(err => {
        console.log('Err');
      });
    this.connection.on('Send', data => {
      // var li = document.createElement('li');
      this.AmbientePedagogico = data;
    });
  },
};
</script>

<style lang="scss">
#app {
  .content {
    margin-left: 250px;
  }
  &.menu-collapsed {
    .content {
      margin-left: 60px;
    }
  }
}
</style>
