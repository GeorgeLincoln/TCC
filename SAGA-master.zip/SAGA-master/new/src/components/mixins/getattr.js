export default {
  methods: {
    getattr (object, attr) {
      if (object) return object[attr]
      else return ''
    }
  }
}
