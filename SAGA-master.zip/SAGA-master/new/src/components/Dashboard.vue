<template>
  <div>
    <h1>Dashboard</h1>

    <div class="row">
      <div class="col-lg-9">
        <div class="row">
          <div class="col-lg-3 mb-4" v-for="(item, index) in AmbientesPedagogicos" :key="index">
            <div :class="[classObject(item), 'card', 'h-100']">
              <div class="card-body">
                <div class="sala">{{ item.nome }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="card">
          <div class="card-body">
            <h4 class="mb-3 font-weight-bold">Informações</h4>

            <div class="font-weight-bold mb-2">Não iniciada</div>
            <div class="bg-warning p-1 mb-3 text-center text-white">4</div>

            <div class="font-weight-bold mb-2">Em atraso</div>
            <div class="bg-danger p-1 mb-3 text-center text-white">4</div>

            <div class="font-weight-bold mb-2">Iniciadas</div>
            <div class="bg-success p-1 mb-3 text-center text-white">4</div>

            <div class="font-weight-bold mb-2">Finalizadas</div>
            <div class="bg-primary p-1 text-center text-white">4</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Service from '@/services/admin/AmbientesPedagogicosService';
export default {
	data() {
		return {
			connection: null,

			AmbientesPedagogicos: [{}],
		};
	},
  methods: {
    classObject: function(data) {
      if(data.status === 'SemAula')
        return 'text-muted bg-light'
    }
  },
	beforeCreate() {
		let signalR = require('../signalr-client.js');
	},
	created() {
		this.connection = new signalR.HubConnection('http://localhost:63636/dashboard');
		let service = new Service();
		let promisse = service.getAll(
			{
				DataInicio: '2018-01-18 13:00',
				DataFim: '2018-01-18 15:00',
			},
			'status',
		);
		promisse.then(data => {
			this.AmbientesPedagogicos = data;
		});
	},
	mounted() {
		this.connection
			.start()
			.then(() => {
				console.log('Started');
			})
			.catch(err => {
				console.log('Err');
			});
		this.connection.on('Send', data => {
			let count = 0;
			this.AmbientesPedagogicos.forEach(a => {
				if (a.id === data[0].id) {
					this.AmbientesPedagogicos.splice(count, 1, data[0]);
				}
				count += 1;
			});
		});
	},
};
</script>

<style lang="scss">
#app {
	.content {
		margin-left: 250px;
	}
	&.menu-collapsed {
		.content {
			margin-left: 60px;
		}
	}
}
</style>
