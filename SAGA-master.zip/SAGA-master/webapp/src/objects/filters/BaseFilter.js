export default {
  Page: 1,
  PageSize: 10,
  SortBy: 'id',
  IsAscending: true
};
