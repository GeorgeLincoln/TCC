<template>
  <footer class="app-footer">
    <span><a href="#">IFCE</a> &copy; 2019 Aquicultura</span>
    <span class="ml-auto">
      <div class="redes-sociais list-inline text-center">
        <a href="https://www.facebook.com/fvjaracati" class="list-inline-item" target="_blank"><i class="fa fa-facebook"></i></a>
        <a href="http://instagram.com/fvj_aracati" class="list-inline-item" target="_blank"><i class="fa fa-instagram"></i></a>
        <a href="https://www.youtube.com/user/FVJUniverso" class="list-inline-item" target="_blank"><i class="fa fa-youtube"></i></a>
        <a href="https://twitter.com/fvjaracati" class="list-inline-item" target="_blank"><i class="fa fa-twitter"></i></a>
        <a href="https://www.linkedin.com/company/faculdade-do-vale-do-jaguaribe" class="list-inline-item" target="_blank"><i class="fa fa-linkedin"></i></a>
      </div>
    </span>
  </footer>
</template>
<script>
export default {
  name: 'c-footer'
}
</script>
