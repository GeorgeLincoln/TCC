<template>
  <header class="app-header navbar">
    <button
      class="navbar-toggler mobile-sidebar-toggler d-lg-none"
      type="button"
      @click="mobileSidebarToggle">
      <span class="navbar-toggler-icon"/>
    </button>
    <router-link
      :to="rota"
      class="navbar-brand"/>
    <button
      class="navbar-toggler sidebar-toggler d-md-down-none"
      type="button"
      @click="sidebarToggle">
      <span class="navbar-toggler-icon"/>
    </button>
    <!--
    <b-navbar-nav class="d-md-down-none">
      <b-nav-item class="px-3">Institucional</b-nav-item>
      <b-nav-item class="px-3">Graduação</b-nav-item>
      <b-nav-item class="px-3">Pós-Graduação</b-nav-item>
      <b-nav-item class="px-3">Pesquisa</b-nav-item>
      <b-nav-item class="px-3">Extensão</b-nav-item>
      <b-nav-item class="px-3">Biblioteca</b-nav-item>
      <b-nav-item class="px-3">Serviços</b-nav-item>
    </b-navbar-nav>
    -->
    <b-navbar-nav class="ml-auto">
      <!-- <b-nav-item class="d-md-down-none">
        <i class="icon-bell"/>
        <b-badge
          pill
          variant="danger">5</b-badge>
      </b-nav-item> -->
      <!-- <b-nav-item class="d-md-down-none">
        <i class="icon-envelope"/>
        <b-badge
          pill
          variant="danger">5</b-badge>
      </b-nav-item> -->
      {{ perfil }}
      <HeaderDropdown/>
    </b-navbar-nav>
    <!-- <button
      class="navbar-toggler aside-menu-toggler d-md-down-none"
      type="button"
      @click="asideToggle">
      <span class="navbar-toggler-icon"/>
    </button> -->
  </header>
</template>
<script>
import HeaderDropdown from './HeaderDropdown.vue'
import nav from '@/_nav'
export default {
  name: 'CHeader',
  components: {
    HeaderDropdown
  },
  data () {
    return {
      rota: '/home'
    };
  },
  watch: {
    perfil (ENUM_MENU) {
      if (ENUM_MENU === 'Gestor') {
        this.rota = '/home/gestor';
        return nav.Gestor
      } else if (ENUM_MENU === 'Professor') {
        this.rota = '/home/professor';
        return nav.Professor
      } else if (ENUM_MENU === 'Aluno') {
        this.rota = '/home/aluno'
        return nav.Aluno
      } else if (ENUM_MENU === 'Integração') {
        this.rota = '/home/integracao';
        return nav.Integracao
      }
    }
  },
  methods: {
    sidebarToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-hidden')
    },
    sidebarMinimize (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-minimized')
    },
    mobileSidebarToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-mobile-show')
    },
    asideToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('aside-menu-hidden')
    }
  },
  computed: {
    perfil () {
      return this.$store.getters.getMenu;
    }
  },
  created () {
    document.body.classList.toggle('sidebar-minimized');
  }

}
</script>

<style scoped>
.app-header.navbar .navbar-brand {
  background-size: 80px auto;
}
</style>
