<template>
  <b-nav-item-dropdown
    right
    no-caret>
    <template slot="button-content">
      <img
        src=""
        class="img-avatar"
        alt="">
    </template>
    <!--b-dropdown-header
      tag="div"
      class="text-center"><strong>Account</strong></b-dropdown-header>
    <b-dropdown-item><i class="fa fa-bell-o"/> Updates<b-badge variant="info">{{ itemsCount }}</b-badge></b-dropdown-item>
    <b-dropdown-item><i class="fa fa-envelope-o"/> Messages<b-badge variant="success">{{ itemsCount }}</b-badge></b-dropdown-item>
    <b-dropdown-item><i class="fa fa-tasks"/> Tasks<b-badge variant="danger">{{ itemsCount }}</b-badge></b-dropdown-item>
    <b-dropdown-item><i class="fa fa-comments"/> Comments<b-badge variant="warning">{{ itemsCount }}</b-badge></b-dropdown-item-->
    <b-dropdown-header
      tag="div"
      class="text-center"><strong>Módulos</strong></b-dropdown-header>
    <b-dropdown-item
      @click="setMenu('Gestor')"
      :to="{ path: '/home/gestor'}">Gestor</b-dropdown-item>

    <b-dropdown-header
      tag="div"
      class="text-center"><strong>Configurações</strong></b-dropdown-header>
    <b-dropdown-item><i class="fa fa-user"/> Perfil</b-dropdown-item>
    <!--b-dropdown-item><i class="fa fa-wrench"/> Configurações</b-dropdown-item-->
    <b-dropdown-item><i class="fa fa-wrench"/> Configurações</b-dropdown-item>
    <!--b-dropdown-item><i class="fa fa-usd"/> Payments<b-badge variant="secondary">{{ itemsCount }}</b-badge></b-dropdown-item>
    <b-dropdown-item><i class="fa fa-file"/> Projects<b-badge variant="primary">{{ itemsCount }}</b-badge></b-dropdown-item-->
    <b-dropdown-divider/>
    <!--b-dropdown-item><i class="fa fa-shield"/> Lock Account</b-dropdown-item-->
    <b-dropdown-item @click="mgr.signOut()"><i class="fa fa-lock"/> Logout</b-dropdown-item>
  </b-nav-item-dropdown>
</template>
<script>
import Mgr from '@/services/SecurityService';
import * as settings from '@/settings';
const baseUrl = settings.baseUrl;
export default {
  name: 'HeaderDropdown',
  data: () => {
    return {
      mgr: new Mgr(),
      itemsCount: 42

    }
  },
  methods: {
    setMenu (label) {
      this.$store.dispatch('setMenu', label)
    }
  }
}
</script>
