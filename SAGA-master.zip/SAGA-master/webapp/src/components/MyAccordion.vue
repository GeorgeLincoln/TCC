<template>

  <div
    class="box-group"
    id="accordion">
    <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
    <div
      class="bg-light mb-3 bloco">
      <div class="card-header">
        <h4>
          <a
            data-toggle="collapse"
            data-parent="#accordion"
            :href="`#${id}`">
            {{ title }}
          </a>
        </h4>
      </div>
      <div
        :id="id"
        class="row card-body panel-collapse collapse"
        :class="show ? 'show' : ''">
        <slot name="content"/>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  name: 'VaArccordion',
  props: {
    title: {
      type: String,
      default: ''
    },
    show: {
      type: Boolean,
      default: false
    },
    id: {
      type: String,
      default: ''
    }
  },
  created () {

  }
}
</script>

<style scoped>
.collapse.show {
  display: flex;
}

.bloco {
  margin-top: 1px;
  border-radius: 4px;
  background: #fff !important;
  border: 1px solid #ccc;
  animation: ani-entrada-opacity 1s ease-in-out;
}
</style>
