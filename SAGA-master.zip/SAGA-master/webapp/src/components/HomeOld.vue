<template>
<div class="home">
    <h1>{{title}} (to do)</h1>
    <a></a>
</div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      title: 'Teach in Touch'
    }
  }
}
</script>

<style>

</style>
