<template>
  <!-- Modal -->
  <!-- tabindex="-1" -->
  <div
    class="modal hide fade in"
    id="modal"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true"
    data-keyboard="false"
    data-backdrop="static">
    <div
      class="modal-dialog modal-lg"
      role="document">
      <div class="modal-content">
        <div class="modal-header bg-info">
          <h5
            class="modal-title"
            id="exampleModalLabel"><slot name="title"/></h5>
        </div>
        <div class="modal-body">
          <slot name="body"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      data: [],
      dto: {},
      index: null
    };
  }
};
</script>

<style scoped>

</style>
