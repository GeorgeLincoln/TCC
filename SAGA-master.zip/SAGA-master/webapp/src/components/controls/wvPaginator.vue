<template>
  <form class="form-inline display">
    <div class="form-group space">
      <label for="select">Itens por página:</label>
    </div>
    <div class="form-group space">
      <select
        class="form-control"
        id="select"
        v-model="filter.PageSize"
      >
        <option
          v-for="(item, index) in options"
          :key="index"
          :selected="item == filter.PageSize"
          :value="item"
        >
          {{ item }}
        </option>
      </select>
    </div>
    <div class="form-group">
      <b-pagination
        align="right"
        style="margin-bottom:0"
        :total-rows="totalRows"
        v-model="filter.Page"
        :per-page="filter.PageSize"/>
    </div>
  </form>
</template>
<script>
export default {
  props: {
    options: {
      type: Array,
      default: () => [2, 10, 20, 30, 40, 50]
    },
    totalRows: {
      type: Number,
      default: () => { return 2; }
    },
    filter: {
      type: Object,
      default: () => {
        return {
          Page: 1,
          PageSize: 10,
          SortBy: 'id',
          IsAscending: false
        };
      }
    }
  },
  watch: {
    'filter.Page' () {
      this.$emit('input', this.filter);
    },
    'filter.PageSize' () {
      this.$emit('input', this.filter);
    }
  }
}
</script>

<style lang="scss" scoped>
.space {
  margin-right: 1vw;
}
select.form-control {
  border-radius: 0.25rem;
}
.display {
  justify-content: flex-end;
}
</style>
