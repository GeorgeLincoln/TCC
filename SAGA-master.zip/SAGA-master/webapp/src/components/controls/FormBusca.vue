<template>
  <div class="row py-1 text-left">   
    <div class="col-12">
      <div id="sidebar-form-search" class="input-group">
         <span class="input-group-prepend">
            <button type="button" class="btn btn-primary"  @click.prevent="emitSearch()">
            <i class="fa fa-search"></i>
            </button>
          </span>
         <input id="search" type="text" class="form-control" v-model="search" @input="debounceSearch" placeholder="Busca">
      </div>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';

  export default {
    data() {
      return {
        search:'',
      }
    },
    methods:{
      debounceSearch: _.debounce(function (e) {
        this.search = e.target.value.trim();
        this.emitSearch();
      }, 500),
      emitSearch(){
        let search = this.search.trim();
        this.$emit('emit-click', search ? search : undefined);
      }
    }
  }
</script>

<style scoped>

</style>
