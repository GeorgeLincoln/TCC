<template>
  <!-- Modal -->
  <div
    class="modal fade"
    id="modal"
    tabindex="-1"
    role="dialog"
    largeModal = true
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div
      class="modal-dialog"
      role="document">
      <div class="modal-content">
        <div class="modal-header bg-info">
          <h5
            class="modal-title"
            id="exampleModalLabel"><slot name="title"/></h5>
        </div>
        <div class="modal-body">
          <slot name="body"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      data: [],
      dto: {},
      index: null
    };
  }
};
</script>

<style scoped>

</style>
