
<template>
  <!-- pagination -->
  <nav aria-label="...">
    <ul class="pagination justify-content-end">
      <!-- previous button -->
      <li
        class="page-item"
        v-if="page > 1">
        <a
          class="page-link"
          href="#"
          tabindex="-1"
          @click="nextPage('previous')">Anterior</a>
      </li>
      <li
        class="page-item disabled"
        v-else>
        <a
          class="page-link"
          href="#"
          tabindex="-1">Anterior</a>
      </li>
      <!-- 1 button -->
      <li class="page-item active">
        <a
          class="page-link"
          href="#"
          @click="nextPage(page)">{{ page }}</a>
      </li>
      <!-- 2 button -->
      <li
        class="page-item"
        v-if="page+1 <= numPages">
        <a
          class="page-link"
          href="#"
          @click="nextPage(page+1)">{{ page+1 }}</a>
      </li>
      <li
        class="page-item disabled"
        v-else>
        <a
          class="page-link"
          href="#">{{ page+1 }}</a>
      </li>

      <!-- 3 button -->
      <li
        class="page-item"
        v-if="page+2 <= numPages">
        <a
          class="page-link"
          href="#"
          @click="nextPage(page+2)">{{ page+2 }}</a>
      </li>
      <li
        class="page-item disabled"
        v-else>
        <a
          class="page-link"
          href="#">{{ page+2 }}</a>
      </li>

      <!-- next-->
      <li
        class="page-item"
        v-if="page+3 <= numPages">
        <a
          class="page-link"
          href="#"
          @click="nextPage('next')">Próximo</a>
      </li>
      <li
        class="page-item disabled"
        v-else>
        <a
          class="page-link"
          href="#">Próximo</a>
      </li>
    </ul>
  </nav>
</template>

<script>
export default {
  data () {
    return {
      page: 1
    };
  },
  props: ['numPages'],
  methods: {
    /**
		 * @description Obtem a próxima página
		 * @param {page}
		 */
    nextPage (page) {
      console.log(this.numPages);
      if (page == 'next') {
        this.page += 3;
      } else if (page == 'previous') {
        this.page -= 3;
      } else {
        this.page = page;
      }

      // Ajusta o componente
      if (this.page < 1) this.page = 1;
      if (this.page > this.numPages) this.page = this.numPages;

      this.$emit('emit-click', this.page);
    }
  }
};
</script>
