<template>
  <div class="row space-bottom">
    <div class="col-md-1">
      <button class="btn btn-primary" @click.prevent="emitSearch()">
        <i class="fa fa-search"></i>
      </button>
    </div>
    <div class="col-md-3">
      <select class="form-control" v-model="tipo" @change="emitSearch()">
        <option>Todos</option>
        <option value="Aluno">Alunos</option>
        <option value="Professor">Professores</option>
        <option value="Gestor">Gestores</option>
      </select>
    </div>
    <div class="col-md-8">
      <input id="search" type="text" class="form-control" v-model.trim="search" @input="debounceSearch" placeholder="Busca">
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';

  export default {
    data() {
      return {
        search:'',
        tipo:'Todos'
      }
    },
    methods:{
      debounceSearch: _.debounce(function (e) {
        this.emitSearch()
      }, 500),
      emitSearch(){
        this.$emit('emit-click', this.search, this.sendTipo);
      }
    },
    computed:{
      sendTipo() {
        if (this.tipo === 'Todos') {
          return null
        } else {
          return this.tipo
        }
      }
    }
  }
</script>

<style scoped>
.space-bottom {
  margin-bottom: .25rem;
}
</style>
