<template>
  <div class="form-group">
    <label><slot name="label"></slot>{{defaultDate}}</label>
    <div class="input-group">
      <flat-pickr v-model="date" :config="config" class="form-control" placeholder="Selecione uma data" name="date">
      </flat-pickr>
      <div class="input-group-btn">
        <button class="btn btn-default" type="button" title="Toggle" data-toggle>
          <i class="fa fa-calendar">
            <span aria-hidden="true" class="sr-only">Toggle</span>
          </i>
        </button>
        <button class="btn btn-default" type="button" title="Clear" data-clear>
          <i class="fa fa-times">
            <span aria-hidden="true" class="sr-only">Clear</span>
          </i>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import flatPickr from 'vue-flatpickr-component';
import 'flatpickr/dist/flatpickr.css';
// try more themes at - https://chmln.github.io/flatpickr/themes/
import 'flatpickr/dist/themes/light.css';
import {Portuguese} from 'flatpickr/dist/l10n/pt';

export default {
  props: ['defaultDate'],
  data() {
    return {
      date: null,
      config: {
        wrap: true, // set wrap to true only when using 'input-group'
        altFormat: 'd/m/Y',
        altInput: true,
        enableTime: true,
        dateFormat: 'Y-m-dTH:i:00',
        time_24hr: true,

        locale: Portuguese, // locale for this instance only
      },
      data: [],
    };
  },
  watch: {
    date: function() {
      this.$emit('emit-click', this.date);
    },
  },
  components: {
    flatPickr,
  },
  created() {
    //console.log('[DatePicker][created]');
  },
  updated() {
    //console.log('[DatePicker][updated]');
    //console.log('[DatePicker][updated]DefaultDate:' + this.defaultDate);
    this.date = this.defaultDate;
  },
};
</script>

<style scoped>

</style>
