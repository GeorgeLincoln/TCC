import { Bar } from '@/BaseCharts';

export default {
  extends: Bar,
  mounted () {
    this.renderChart(
      {
        labels: [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December'
        ],
        datasets: [
          {
            label: 'Data One',
            backgroundColor: '#f87979',
            borderColor: 'rgb(0,0,0)',
            data: [40, 20, 12, 39, 10, 40, 39, 80, 40, 20, 12, 11]
          },
          {
            label: 'Data Two',
            backgroundColor: '#f80000',
            borderColor: 'rgb(0, 0, 132)',
            data: [4, 2, 2, 3, 20, 34, 19, 38, 54, 12, 13, 21]
          }
        ]
      },
      { responsive: true, maintainAspectRatio: false }
    );
  }
};
