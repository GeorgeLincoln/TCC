<template>
  <button
    class="sidebar-minimizer"
    type="button"
    @click="sidebarMinimize();brandMinimize()"/>
</template>
<script>

export default {
  name: 'SidebarMinimizer',
  methods: {
    sidebarMinimize () {
      document.body.classList.toggle('sidebar-minimized')
      this.formMinimize();
    },
    brandMinimize () {
      document.body.classList.toggle('brand-minimized')
      this.formMinimize();
    },
    formMinimize () {
      // var sidebarUserLogo = document.getElementById('sidebar-user-logo');
      // console.log('display:::', sidebarUserLogo.style.display)

      // if(sidebarUserLogo.style.display  === "none")
      //  sidebarUserLogo.style.display  = 'block';
      // else
      //  sidebarUserLogo.style.display  = 'none';

      /* var sidebarFormSearch = document.getElementById('sidebar-form-search');
      ;

      if(sidebarFormSearch.style.display  === 'none')
        sidebarFormSearch.style.display  = '';
      else
        sidebarFormSearch.style.display  = 'none';
      if(sidebarUserLogo.style.display  === 'none')
        sidebarUserLogo.style.display  = '';
      else
        sidebarUserLogo.style.display  = 'none'; */
    }
  }
}
</script>
