<template>
  <!-- <div class="sidebar-header"></div> -->
</template>
<script>

export default {
  name: 'SidebarHeader'
}
</script>
