<template>
  <router-link
    tag="li"
    class="nav-item nav-dropdown"
    :to="url"
    disabled>
    <div
      class="nav-link nav-dropdown-toggle"
      @click="handleClick">
      <i :class="icon"/>
      {{ name }}
    </div>
    <ul class="nav-dropdown-items">
      <slot/>
    </ul>
  </router-link>
</template>

<script>
export default {
  props: {
    name: {
      type: String,
      default: ''
    },
    url: {
      type: String,
      default: ''
    },
    icon: {
      type: String,
      default: ''
    }
  },
  methods: {
    handleClick (e) {
      e.preventDefault()
      e.target.parentElement.classList.toggle('open')
    }
  }
}

</script>

<style scoped>
.nav-link i {
  color: #e4e4e4
}
.nav-link i:hover {
  color: #ffffff
}
</style>
