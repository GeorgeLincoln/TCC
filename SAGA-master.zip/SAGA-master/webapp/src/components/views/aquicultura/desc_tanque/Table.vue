<template>
  <div id="divDescTanque">
    <div class="card">
      <h5 class="card-header">Descrição do Tanque
      <a v-if="data.length === 0"
          class="fa fa-print float-right not-print"/>
        <a v-else
        class="fa fa-print float-right"
        href="#"
        @click="printPdf"/>
      </h5>
      <div class="card-body">
        <div
          class="row col-12"
          style="padding:0; margin:0">
          <div
            id="input-search"
            class="col-md-6"
            style="padding:0">
            <FormBusca
              align="left"
              :total-rows-in-page="10"
              :total-rows="totalRows"
              @emit-click="searchClick"/>
          </div>
          <div
            class="col-md-6 navigation-top"
          >
            <wv-paginator
              :total-rows="totalRows"
              :filter="filter"
              class="paginator"
              v-model="filter"
              @input="populate()"
            />
          </div>
        </div>
          <table id="tableDescTanque" class="table">
            <thead>
              <tr>
                <th class="min-width-table">Data de Início</th>
                <th class="min-width-table">Data de Término</th>
                <th>Código</th>
                <th>Tipo de Fase</th>
                <th>Tanque</th>
                <th class="text-right">
                  <a
                    class="fa fa-plus-circle"
                    href="#"
                    data-toggle="modal"
                    data-target="#modal"
                    @click="selectRow(null, 'create')"/>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="data.length === 0">
                <td
                  class="text-center font-italic"
                  colspan="7">
                  <label>Não existem registros cadastrados</label>
                </td>
              </tr>
              <tr
                v-for="(row, index) in data"
                :key="row.id">
                <td>{{ row.codigo }}</td>
                <td>{{ formatedDate(row.dataInicio) }}</td>
                <td>{{ formatedDate(row.dataTermino) }}</td>
                <td>{{ row.tipo_fase_id }}</td>
                <td>{{ row.tanque_id }}</td>
                <td class="text-right">
                  <a
                    class="fa fa-edit"
                    href="#"
                    data-toggle="modal"
                    data-target="#modal"
                    @click="selectRow(index, 'update')"/>
                  <a
                    class="fa fa-trash"
                    href="#"
                    data-toggle="modal"
                    data-target="#modalDelete"
                    @click="selectRow(index)"/>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="row">
          <div class="col-12 col-sm-12 col-md-12 col-lg-12">
            <wv-paginator
              :total-rows="totalRows"
              :filter="filter"
              class="paginator"
              v-model="filter"
              @input="populate()"
            />
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span
        slot="title"
        v-if="dto!=null">Editar Descrição do Tanque</span>
      <span
        slot="title"
        v-else>Cadastrar Descrição do Tanque</span>
      <div slot="body">
        <Form
          v-bind="{ dto: dto }"
          @emit-click="getChanges"
          @close-click="clearFields"/>
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"/>

  </div>
</template>

<script>
import reportMixin from '@/components/mixins/report';
import utilsMixin from '@/components/mixins/utils';
import Form from '@/components/views/aquicultura/desc_tanque/Form';
import Service from '@/services/aquicultura/DescTanque';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChangeLarge';
import ModalDelete from '@/components/controls/ModalDelete';
import wvPaginator from '@/components/controls/wvPaginator';
import FormBusca from '@/components/controls/FormBusca';
import sortFilters from '@/components/mixins/sortFilters';


const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data() {
    return {
      data: [],
      action: null,
      niveis: {},
      gestores: {},
      aux: [],
      dto: {},
      index: null,
      currentStatus: null,
      tempGestor: null,
      filter: {
        ...BaseFilter
      },
      currentPage: 1,
      totalRows: 0
    };
  },
  watch: {
    currentPage: function() {
      this.filter.Page = this.currentPage;
      this.populate();
    }
  },
  mixins: [utilsMixin, reportMixin, sortFilters],
  components: {
    Form,
    ModalChange,
    ModalDelete,
    FormBusca,
    wvPaginator
  },
  methods: {
    clearFields() {
      this.dto = null;
      this.action = '';
    },
    searchClick(search) {
      search != '' ? this.populateSearch(search) : this.populate();
    },
    nextPage(page) {
      this.filter.Page = page;
      search != '' ? this.populateSearch(search) : this.populate();
    },
    selectRow(index, action) {
      // Atualiza a linha selecionada
      this.index = index;
      this.dto = this.data[this.index];
      this.action = action;
    },
    /**
     * @description Obtem o registro modificado de form
     * @param {dto} parametro
     */
    getChanges(dto) {
      if (this.index != null) {
        this.data[this.index].codigo = dto.codigo;
        this.data[this.index].dataInicio = dto.dataInicio;
        this.data[this.index].dataTermino = dto.dataTermino;
        this.data[this.index].tipo_fase_id = dto.tipo_fase_id;
        this.data[this.index].tanque_id = dto.tanque_id;
      } else {
        this.populate();
      }
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected() {
      // remove pelo id
      let id = this.data[this.index].id;
      new Service().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.populate();
        },
        err => {
          this.currentStatus = STATUS_FAILED;
          console.log('Erro!');
        }
      );
      this.deleteModal = false;
    },
    populateSearch(busca) {
      this.filter.Nome = busca;
      this.filter.IncludeGestor = true;
      this.filter.IncludeNivelEnsino = true;
      let promise = new Service().getAll(this.filter, 'filter');
      promise.then(
        success => {
          this.data = success;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );

      new Service().getAll(this.filter, 'filter/count').then(
        count => {
          this.totalRows = count;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
    },
    populate() {
      // this.filter.Nome = null;
      this.filter.IncludeGestor = true;
      this.filter.IncludeNivelEnsino = true;
      new Service().getAll(this.filter, 'count').then(
        count => {
          this.totalRows = count;
        },
        err => {}
      );

      let promise = new Service().getAll(this.filter, 'filter');
      promise.then(
        success => {
          this.data = success;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
    },

    printPdf(){
      // Configurações do Relatórios
      var title = 'Cursos da Instituição';
      var labels = ['Código', 'Nome', 'Coordenador', 'Nível'];
      var columns = ['codigo', 'nome', 'gestor', 'nivelEnsino'];
      var widths = ['auto', '*', '*', '*' ]

      var filter = {...this.filter};
      filter.GetAll = true;
      let promise = new Service().getAll(filter, 'filter');
      promise.then(
        success => {this.buildPdfReport(success, labels, columns, widths, title);},
        err => {}
      );
    }, // fim do método printPdf

  },

  created() {
    this.filter.SortBy = 'Nome';
  },
  mounted(){
    this.populate();
  }
};
</script>

<style scoped>
table {
  font-size: 20px;
}
.navigation-top {
    padding: 0px;
  }
  .not-print{
	color: #9e9e9e !important;
  }
@media screen and (max-width: 790px) {
  #input-search {
    flex: 0 0 100%;
    max-width: 100%;
  }
  div.navigation-top {
    display: none;
  }
  div.navigation-bottom {
    display: flex;
    justify-content: center;
  }
  .paginator:nth-child(1).display {
      justify-content: center;
    }
}

.min-width-table {
  min-width: 13rem;
}
</style>
