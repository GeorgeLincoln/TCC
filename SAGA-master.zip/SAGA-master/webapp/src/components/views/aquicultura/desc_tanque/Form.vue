<template>
    <div id="divDescTanque">
        <form id="formDescTanque">
            <div class="form-row">
                <div class="col-6">
                <DatePicker
                    id="dataInicio"
                    name="dataInicio"
                    ref="dataInicio"
                    v-model="$data.inputForm.dataInicio"
                    :default-date="$data.inputForm.dataInicio"
                    @emit-click="getDataInicio">
                    <span slot="label">Data de Início<small>*</small></span>
                </DatePicker>
                <small
                    class="form-text text-danger"
                    v-if="!validateDate"
                >Data é obrigatória</small>
                </div>
                <div class="col-6">
                <DatePicker
                    id="dataTermino"
                    name="dataTermino"
                    ref="dataTermino"
                    v-model="$data.inputForm.dataTermino"
                    :default-date="$data.inputForm.dataTermino"
                    @emit-click="getDataTermino">
                    <span slot="label">Data de Término<small>*</small></span>
                </DatePicker>
                <small
                    class="form-text text-danger"
                    v-if="!validateDate"
                >Data é obrigatória</small>
                </div>
            </div>

            <div class="form-row">
                <div class="col-4">
                <div class="form-group">
                    <label for="codigo">Código<small>*</small></label>
                    <input
                    type="text"
                    :class="{'form-control': true, 'is-danger': errors.has('codigo') }"
                    class="form-control"
                    name="codigo"
                    v-validate="{required: true}"
                    ref="codigo"
                    v-model="$data.inputForm.codigo">
                    <small
                    class="form-text text-danger"
                    v-if="errors.has('codigo')">Código é obrigatório</small>
                </div>
                </div>

            <div class="form-group">
                <label for="tipo_fase_id">Tipo de Fase<small>*</small></label>
                <select
                class="form-control"
                id="tipo_fase_id"
                name="tipo_fase_id"
                :class="{'form-control': true, 'is-danger': errors.has('tipo_fase_id') }"
                v-validate="{required: true}"
                ref="tipo_fase_id"
                v-model="$data.inputForm.tipo_fase_id">
                </select>
                <small
                class="form-text text-danger"
                v-if="errors.has('tipo_fase_id')">Tipo de Fase é obrigatório</small>
            </div>
            <div class="modal-footer">
                <button
                type="button"
                class="btn btn-secondary"
                data-dismiss="modal"
                @click.prevent="closeClick()"
                >Cancelar</button>
                <button
                type="button"
                class="btn btn-primary"
                data-dismiss="modal"
                @click.prevent="emitClick(dto)"
                :disabled="errors.any() || !validateDate"
                >Salvar</button>
            </div>
           </div> 
         </form>
    </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/aquicultura/DescTanque';
import GEService from '@/services/admin/GestoresService';
import NEService from '@/services/admin/NiveisEnsinoService';
import BaseFilter from '@/objects/filters/BaseFilter';
import DatePicker from '@/components/controls/DatePicker';
import * as settings from '@/settings';

const baseUrl = settings.baseUrl;

export default {
	props: ['dto'] /* dto is passed in table component to this form */,
	mixins: [getattr],
	data() {
		return {
			inputForm: {
				dataInicio: '',
                dataTermino: '',
                codigo: '',
                tipo_fase_id: '',
                tanque_id: ''
			},

			first_form_loading: true
		};
	},
	components: {
		DatePicker
	},
	watch: {
		dto: function() {
			this.errors.clear();
			if (this.dto) {
				this.inputForm = { ...this.dto };
			} else {
				this.clearFields();
			}
		}
	},
	computed: {
		validateDate() {
			return !!this.inputForm.dataInicio && !!this.inputForm.dataTermino;
		}
	},
	methods: {
		clearFields() {
			this.inputForm.dataInicio = '';
            this.inputForm.dataTermino = '';
            this.inputForm.codigo = '';
			this.inputForm.tipo_fase_id = '';
			this.inputForm.tanque_id = '';
		},
		/**
		 * @description Obtem a data de Inicio
		 */
		getDataInicio(dataInicio) {
			this.inputForm.dataInicio = dataInicio;
		},

		/**
		 * @description Obtem a data de Termino
		 */
		getDataTermino(dataTermino) {
			this.inputForm.dataTermino = dataTermino;
		},

		/**
		 * @description Evento emitido com o Botão Cancelar no Modal
		 */
		closeClick() {
			this.$emit('close-click');
		},

		/**
		 * @description Evento emitido com o Botão Salvar no Modal
		 */

		emitClick(dto) {
			let formData = {
				dataInicio: this.inputForm.dataInicio,
                dataTermino: this.inputForm.dataTermino,
                codigo: this.inputForm.codigo,
				tipo_fase_id: this.inputForm.tipo_fase_id,
				tanque_id: this.inputForm.tanque_id
			};
			let service = new Service();
			this.$validator.validateAll().then(formValido => {
				if (!formValido) return;

				if (dto != null) {
					formData.id = dto.id;
					service.getById(dto.id).then(data => {
						data.dataInicio = formData.dataInicio;
						data.dataTermino = formData.dataTermino;
                        data.codigo = formData.codigo;
                        data.tipo_fase_id = formData.tipo_fase_id;
                        data.tanque_id = formData.tanque_id;
						
						service.update(data, data.id).then(success => {
							this.$emit('emit-click', data);
						});
					});
				} else {
					service.create(formData).then(
						success => {
							this.$emit('emit-click', success);
						},
						err => {}
					);
				}
			});
		},

		/**
		 * @description Indica que o formulario ja foi carregado
		 */
		setFirstFormLoading() {
			this.first_form_loading = true;
		}
	},
	created() {
		new GEService().getAll(BaseFilter, 'dropdown').then(data => (this.getGestores = data));
		new NEService().getAll().then(data => (this.getNiveisDeEnsino = data));
	}
};
</script>

<style scoped>
div.modal-footer {
	padding-right: 0 !important;
	border-top: 0 !important;
}
.custom-file-input:lang(en) ~ .custom-file-label::after {
	content: 'Navegar';
}
</style>
