<template>
  <div id="divUsuario">
    <div class="card">
      <h5 class="card-header">Usuários </h5>
      <div class="card-body">
        <b-pagination
          align="right"
          :total-rows="totalRows"
          v-model="currentPage"
          :per-page="filter.PageSize"/>
        <div
          class="row col-12"
          style="padding:0; margin:0">
          <div
            id="input-search"
            class="col-md-6"
            style="padding:0">
            <FormBusca
              align="left"
              :total-rows-in-page="10"
              :total-rows="totalRows"
              @emit-click="searchClick"/>
          </div>
          <div
            class="col-md-6 navigation-top"
          >
            
          </div>
        </div>
        <table
          id="tableUsuario"
          class="table">
          <thead>
            <tr>
              <th @click="reverse('Login')">Login</th>
              <th>Email</th>
              <th>Nível de Acesso</th>
              <th>Ativo</th>
              <th>Nome</th>
              <th>Código</th>
              <th/>
              <th>
                <a
                  class="fa fa-plus-circle"
                  href="#"
                  data-toggle="modal"
                  data-target="#modal"
                  @click="selectRow(index=null, 'create')"/>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="dados.length === 0" > <td
              colspan="6"
              class="text-center font-italic"><label> Não existem registros cadastrados </label></td></tr>
            <tr
              v-for="(row, index) in dados"
              :key="row.id">
              <td>{{ row.usuarioLogin }}</td>
              <td>{{ row.email }}</td>
              <td>{{ row.nivel_acesso }}</td>
              <td>{{ row.ativo }}</td>
              <td>{{ row.nome }}</td>
              <td>{{ row.codigo }}</td>
              <td class="text-right">
                <a
                  class="fa fa-edit"
                  href="#"
                  data-toggle="modal"
                  data-target="#modal"
                  @click="selectRow(index, 'update')"/>
              </td>
              <td>
                <a
                  class="fa fa-trash"
                  href="#"
                  data-toggle="modal"
                  data-target="#modalDelete"
                  @click="selectRow(index)"/>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="row">
          <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          </div>
        </div>
        <b-pagination
          align="right"
          :total-rows="totalRows"
          v-model="currentPage"
          :per-page="filter.PageSize"/>
      </div>
    </div>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span slot="title">Cadastrar Usuário</span>
      <div slot="body">
        <Form
          @emit-click="getChanges"
          @close-click="clearFields"/>
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"/>

  </div>
</template>

<script>
import Form from '@/components/views/aquicultura/usuario/Form';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChange';
import ModalDelete from '@/components/controls/ModalDelete';
import FormBusca from '@/components/controls/FormBusca';
import sortFilters from '@/components/mixins/sortFilters';
import axios from 'axios';

export default {
  data() {
    return {
      dados: [],
      descTanque: [],
      filter: {
        ...BaseFilter
      },
      currentPage: 1,
      totalRows: 0,
      url: `http://localhost:8080/`,
      errors: []
    };
  },
 watch: {
    currentPage: function() {
      this.filter.Page = this.currentPage;
      this.populate();
    }
  },
  components: {
    Form,
    ModalChange,
    ModalDelete,
    FormBusca
  },
  methods: {
    api() {
      axios
        .get(this.url + `usuario`)
        .then(respose => {
          this.dados = respose.data;
          console.log(respose.data);
        })
        .catch(e => {
          this.errors.push(e);
        });
    }
  },
  created() {
    this.api();
  },
  mounted() {
    setInterval(() => {
      this.api();
    }, 30000);
  }
};
</script>

<style scoped>
table {
  font-size: 20px;
}
.navigation-top {
  padding: 0px;
}
.not-print {
  color: #9e9e9e !important;
}
@media screen and (max-width: 1106px) {
  #input-search {
    flex: 0 0 100%;
    max-width: 100%;
  }
  div.navigation-top {
    display: none;
  }
  div.navigation-bottom {
    display: flex;
    justify-content: center;
  }
  .paginator:nth-child(1).display {
    justify-content: center;
  }
}

.min-width-table {
  min-width: 13rem;
}
</style>
