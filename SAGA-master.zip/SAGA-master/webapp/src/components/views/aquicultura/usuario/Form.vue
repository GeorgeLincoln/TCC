<template>
  <div id="divUsuario">
    <form id="formUsuario">
      <b-form-group>
        <label for="login">Login<small>*</small></label>
        <input
          type="text"
          class="form-control"
          v-validate="{required:true}"
          :class="{'form-control': true, 'is-danger': errors.has('login') }"
          id="login"
          name="login"
          ref="login"
          v-model="model.login">
        <small
          class="form-text text-danger"
          v-if="errors.has('login')">Login é obrigatório
        </small>
      </b-form-group>

      <b-form-group>
        <label for="senha">Senha<small>*</small></label>
        <input
          type="password"
          class="form-control"
          v-validate="{required:true}"
          :class="{'form-control': true, 'is-danger': errors.has('senha') }"
          id="senha"
          name="senha"
          ref="senha"
          v-model="model.senha">
        <small
          class="form-text text-danger"
          v-if="errors.has('senha')">Senha é obrigatória
        </small>
      </b-form-group>
      <b-form-group>
        <label for="email">Email<small>*</small></label>
        <input
          type="text"
          class="form-control"
          id="email"
          :class="{'form-control': true, 'is-danger': errors.has('email') }"
          v-validate="{required:true}"
          name="email"
          ref="email"
          v-model="model.email">
        <small
          class="form-text text-danger"
          v-if="errors.has('email')">Email é obrigatório</small>
      </b-form-group>

        <b-form-group>
        <label for="nivel_acesso">Nível de Accesso<small>*</small></label>
        <input
          type="text"
          class="form-control"
          id="nivel_acesso"
          :class="{'form-control': true, 'is-danger': errors.has('nivel_acesso') }"
          v-validate="{required:true}"
          name="nivel_acesso"
          ref="nivel_acesso"
          v-model="model.nivel_acesso">
        <small
          class="form-text text-danger"
          v-if="errors.has('nivel_acesso')">Nível de Accesso é obrigatório</small>
      </b-form-group>

        <b-form-group>
        <label for="ativo">Ativo<small>*</small></label>
                <input
                type="checkbox"
                v-model="toggle"
                true-value="yes"
                false-value="no"
                >

      </b-form-group>

        <b-form-group>
        <label for="nome">Nome<small>*</small></label>
        <input
          type="text"
          class="form-control"
          id="nome"
          :class="{'form-control': true, 'is-danger': errors.has('nome') }"
          v-validate="{required:true}"
          name="nome"
          ref="nome"
          v-model="model.email">
        <small
          class="form-text text-danger"
          v-if="errors.has('nome')">Nome é obrigatório</small>
      </b-form-group>

        <b-form-group>
        <label for="codigo">Código<small>*</small></label>
        <input
          type="text"
          class="form-control"
          id="codigo"
          :class="{'form-control': true, 'is-danger': errors.has('codigo') }"
          v-validate="{required:true}"
          name="codigo"
          ref="codigo"
          v-model="model.codigo">
        <small
          class="form-text text-danger"
          v-if="errors.has('codigo')">Código é obrigatório</small>
      </b-form-group>
      
      <div class="form-group">
        <div class="modal-footer">
          <button
            id="btnCancelar"
            type="button"
            class="btn btn-secondary"
            @click.prevent="closeClick()">Cancelar</button>
          <button
            id="btnSalvar"
            type="button"
            data-dismiss="modal"
            class="btn btn-primary"
            @click.prevent="emitClick(dto)"
            :disabled="errors.any()">Salvar</button>
        </div>
    </div></form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/aquicultura/Usuario';
import BaseFilter from '@/objects/filters/BaseFilter';
export default {
  data () {
    return {
      model: {
        login: '',
        senha: '',
        email: '',
        nivel: '',
        ativo: '',
        nome: '',
        codigo: ''
      },
    };
  },
  mixins: [getattr],
  watch: {
    dto: function () {
      this.$validator.reset();

      this.errors.clear();

      if (this.dto != null) {
        this.model.login = this.dto.login;
        this.model.senha = this.dto.senha;
        this.model.email = this.dto.email;
        this.model.nivel = this.dto.nivel;
        this.model.ativo = this.dto.ativo;
        this.model.nome = this.dto.nome;
        this.model.codigo = this.dto.codigo;
      
      } else {
        this.clearFields();
      }
    }
  },
  methods: {
    clearFields () {
      this.model.login = '';
      this.model.senha = '';
      this.model.email = '';
      this.model.nivel = '';
      this.model.ativo = '';
      this.model.nome = '';
      this.model.codigo = '';
    },
    closeClick () {
      this.$emit('close-click');
      var btn = document.getElementById('btnCancelar');
      btn.setAttribute('data-dismiss', 'modal');
      btn = document.getElementById('btnSalvar');
      btn.setAttribute('data-dismiss', 'modal');
    },
    emitClick (dto) {
      // Obtem dados do formulario
      this.$validator.validateAll().then(formValido => {
        console.log(formValido);
        if (formValido) {
          try {
            let formData = {
              login: this.model.login,
              senha: this.model.senha,
              email: this.model.email,
              nivel: this.model.nivel,
              ativo: this.model.ativo,
              nome: this.nome,
              codigo: this.codigo
            };
            if (dto != null) {
              /* Update */
              formData.id = dto.id;

              console.log('Update');
              let objPromisse = new Service()
                .getById(dto.id)
                .then(data => {
                  // Atualiza dados
                  data.login = formData.login;
                  data.senha = formData.senha;
                  data.email = formData.email;
                  data.nivel = formData.nivel;
                  data.ativo = formData.ativo;
                  data.nome = formData.nome;
                  data.codigo = formData.codigo;
                  let promise = new Service().update(data, data.id).then(success => {}, err => {});
                  this.$emit('emit-click', data);
                })
                .catch(err => {
                  console.log(err);
                });
            } else {
              // Create
              formData.login = this.$refs.login.value;
              formData.senha = this.$refs.senha.value;
              formData.email = this.$refs.email.value;
              formData.nivel = this.$refs.nivel.value;
              formData.ativo = this.$refs.ativo.value;
              formData.nome = this.$refs.nome.value;
              formData.codigo = this.$refs.codigo.value;
              
              let promise = new Service().create(formData).then(
                success => {
                  this.$emit('emit-click', success);
                },
                err => {
                  console.log(err);
                }
              );
            }
          } catch (e) {
            console.log(e);
          }
        }
      });
    }
  },
  props: ['dto', 'action'],
  created () {
    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService().getAll(BaseFilter).then(data => {
      this.instituicaoId = data[0].id;
    });
  }
};
</script>
