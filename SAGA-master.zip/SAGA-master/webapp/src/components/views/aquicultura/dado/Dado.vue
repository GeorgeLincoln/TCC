<template>
  <div>
    <div class="float-legend">
      <div class="card">
        <div class="card-body">
          <h4 class="mb-3 font-weight-bold">Filtros</h4>
          <div class="font-weight-bold mb-2">Tanque</div>
          <input
            class="input-filtro"
            type=""
            name=""
            v-model="filtro[0]"
            placeholder="text..." >
          <div class="font-weight-bold mb-2">Tipo do dado</div>
          <input
            class="input-filtro"
            type=""
            name=""
            v-model="filtro[1]"
            placeholder="text..." >
          <div class="font-weight-bold mb-2">Escala de tempo</div>
          <input
            class="input-filtro"
            type=""
            name=""
            v-model="filtro[3]"
            placeholder="text..." >
          <div class="font-weight-bold mb-2">Apartir de</div>
          <input
            type="date"
            name=""
            v-model="filtro[2]"
            placeholder="text..." >
          <button
            class="waves-effect waves-light btn-small"
            @click="listar()">Buscar</button>
        </div>
      </div>
    </div>
    <div
      id="app "
      class="">
      <!-- <button class="waves-effect waves-light btn-small" @click="listar()">
      get<i class="material-icons left">save</i>
    </button>-->
      <div class="Chart">
        <h1 style="text-align:center;">Temperatura</h1>
        <line-example :chart-data="Dados"/>
      </div>
    <!-- {{this.tabDado}} -->
    </div>
    <div
      id="app "
      class="">
      <!-- <button class="waves-effect waves-light btn-small" @click="listar()">
      get<i class="material-icons left">save</i>
    </button>-->
      <div class="Chart">
        <h1 style="text-align:center;">Umidade</h1>
        <line-example :chart-data="Umidade"/>
      </div>
    <!-- {{this.tabDado}} -->
    </div>

  </div>

</template>

<script>
import BarExample from '@/components/examples/BarExample';
import LineExample from '@/components/examples/LineExample';
import dado from '@/services/dado';
export default {
  components: {
    BarExample,
    LineExample
  },
  name: 'App',
  data () {
    return {
      // dados: {
      //   codigo: '',
      //   dado_valor: '',
      //   data: '',
      //   desc_tanque_id: '',
      //   desc_dado_id: ''
      // },
      idTanque: 6,
      Dados: null,
      Umidade: null,
      tabDado: [],
      dadoValor: [],
      hora: [],
      errors: [],
      filtro: ['6', '1', '', '30']
    };
  },
  created () {
    this.listar();
    this.fillDados();
  },
  mounted () {
    // this.listar();
    setInterval(() => {
      this.fillDados();
    }, 6000);
  },
  methods: {
    fillDados () {
      this.Dados = {
        labels: this.gethora(),
        datasets: [
          {
            label: 'Dados',
            backgroundColor: 'rgba(255,120,0,0)',
            borderColor: 'rgb(255,0,0)',
            data: this.getDadoValor()
          }
        ]
      };

      this.Umidade = {
        labels: this.gethora(),
        datasets: [
          {
            label: 'Dados',
            backgroundColor: 'rgba(0,0,255,0)',
            borderColor: 'rgb(0,0,255)',
            data: this.getUmidade()
          }
        ]
      };
    },
    getDadoValor () {
      this.tabDado.content = [
        {
          dado_valor: 30,
          data: '08:00',
          umidade: 60
        },
        {
          dado_valor: 32,
          data: '08:30',
          umidade: 59
        },
        {
          dado_valor: 31,
          data: '09:00',
          umidade: 60
        },
        {
          dado_valor: 33,
          data: '09:30',
          umidade: 54
        }
      ]
      console.log(this.tabDado.content)
      for (let i in this.tabDado.content) { this.dadoValor.push(this.tabDado.content[i].dado_valor); }
      // console.log(this.tabDado[i]);

      return this.dadoValor;
    },
    gethora () {
      this.hora = [];
      for (let i in this.tabDado.content) { this.hora.push(this.tabDado.content[i].data); }
      // console.log(this.hora);
      return this.hora;
    },
    getUmidade () {
      this.umidade = [];
      for (let i in this.tabDado.content) { this.umidade.push(this.tabDado.content[i].umidade); }
      // console.log(this.hora);
      return this.umidade;
    },
    listar () {
      // ?desc_tanque_id=6
      dado
        .listar('/filtro?desc_tanque_id=' + this.filtro[0] + '&desc_dado_id=' + this.filtro[1] + '&data=' + this.filtro[2] + '&size=5')
        .then(resposta => {
          this.tabDado = resposta.data;
          console.log(this.tabDado);
          console.log(this.tabDado.totalElements);
        })
        .catch(e => {
          console.log(e);
        });
    }
  }
};
</script>

<style lang="scss">
.input-filtro{
  width:35%;
}
.conteiner{
  background:rgb(120,120,120);
  padding-top:20px;
}
.float-legend {
  position: fixed;
  width: 10rem;
  right: -8rem;
  transition: all 400ms ease-in-out;
  cursor: pointer;
  box-shadow: -4px 4px 8px #33333380;
  border-radius: 4px;
  background-color: #fff;
  color: #fff;
  &:hover {
    right: 0rem;
    color: #000;
  }
  .card {
    margin: 0;
    border: none;
    background: transparent;
    margin-bottom: 2.5rem;

    .card-body div {
      border-radius: 4px;
    }
  }
}
</style>
