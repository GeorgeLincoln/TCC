<template>
  <div id="divDado">

    <form id="formDado">
      <div class="form-group">
        <label for="valor">Valor<small>*</small></label>
        <input
          type="text"
          :class="{'form-control': true, 'is-danger': errors.has('valor') }"
          class="form-control"
          name="valor"
          ref="valor"
          v-validate="{required: true}"
          v-model="$data.inputForm.valor">
          <small
              class="form-text text-danger"
            v-if="errors.has('valor')">Valor é obrigatório</small>
      </div>

      <div class="form-row">
        <div class="col-6">
          <DatePicker
            id="dataHora"
            name="dataHora"
            ref="dataHora"
            v-model="$data.inputForm.dataHora"
            :default-date="$data.inputForm.dataHora"
            @emit-click="getDataHora">
            <span slot="label">Data e Hora<small>*</small></span>
          </DatePicker>
          <small
            class="form-text text-danger"
            v-if="!validateDate"
          >Data e Hora são obrigatórias</small>
        </div>

      <div class="col-8">
          <div class="form-group">
            <label for="descTanque">Desc. Tanque<small>*</small></label>
            <select
              class="form-control"
              :class="{'form-control': true, 'is-danger': errors.has('descTanque') }"
              id="descTanque"
              name="descTanque"
              v-validate="{required: true}"
              v-model="$data.inputForm.descTanque"
              ref="nivelEnsinoId">
              <option
                v-for="row in getDescTanque"
                :key="row.id"
                :value="row.id">{{ row.descTanque }}</option>
            </select>
            <small
              class="form-text text-danger"
            v-if="errors.has('descTanque')">Desc. Tanque é obrigatório</small>
          </div>
        </div>
      </div>


      <div class="form-row">
        <div class="col-4">
          <div class="form-group">
            <label for="codigo">Código<small>*</small></label>
            <input
              type="text"
              :class="{'form-control': true, 'is-danger': errors.has('codigo') }"
              class="form-control"
              name="codigo"
              v-validate="{required: true}"
              ref="codigo"
              v-model="$data.inputForm.codigo">
              <small
              class="form-text text-danger"
            v-if="errors.has('codigo')">Código é obrigatório</small>
          </div>
        </div>
        <div class="col-8">
          <div class="form-group">
            <label for="descSensor">Desc. Sensor<small>*</small></label>
            <select
              class="form-control"
              :class="{'form-control': true, 'is-danger': errors.has('descSensor') }"
              id="descSensor"
              name="descSensor"
              v-validate="{required: true}"
              v-model="$data.inputForm.descSensor"
              ref="nivelEnsinoId">
              <option
                v-for="row in getDescSensor"
                :key="row.id"
                :value="row.id">{{ row.descSensor }}</option>
            </select>
            <small
              class="form-text text-danger"
            v-if="errors.has('descSensor')">Desc. Sensor é obrigatório</small>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button
          type="button"
          class="btn btn-secondary"
          data-dismiss="modal"
          @click.prevent="closeClick()"
        >Cancelar</button>
        <button
          type="button"
          class="btn btn-primary"
          data-dismiss="modal"
          @click.prevent="emitClick(dto)"
          :disabled="errors.any() || !validateDate"
        >Salvar</button>
      </div>
    </form>
  </div>
</template>

<script>
import getattr from '@/components/mixins/getattr';
import Service from '@/services/aquicultura/Dado';
import GEService from '@/services/admin/GestoresService';
import NEService from '@/services/admin/NiveisEnsinoService';
import BaseFilter from '@/objects/filters/BaseFilter';
import DatePicker from '@/components/controls/DatePicker';
import * as settings from '@/settings';

const baseUrl = settings.baseUrl;

export default {
	props: ['dto'] /* dto is passed in table component to this form */,
	mixins: [getattr],
	data() {
		return {
			inputForm: {
				valor: '',
				dataHora: '',
				descTanque: '',
				codigo: '',
				descSensor: ''
			},

		};
	},
	components: {
		DatePicker
	},
	watch: {
		dto: function() {
			this.errors.clear();
			if (this.dto) {
				this.inputForm = { ...this.dto };
			} else {
				this.clearFields();
			}
		}
	},
	computed: {
		validateDate() {
			return !!this.inputForm.dataInicio && !!this.inputForm.dataTermino;
		}
	},
	methods: {
		clearFields() {
			this.inputForm.valor = '';
			this.inputForm.dataHora = '';
			this.inputForm.descTanque = '';
			this.inputForm.codigo = '';
			this.inputForm.descSensor = '';
		},
		/**
		 * @description Obtem a data de Inicio
		 */
		getDataInicio(dataHora) {
			this.inputForm.dataHora = dataHora;
		},



		/**
		 * @description Evento emitido com o Botão Cancelar no Modal
		 */
		closeClick() {
			this.$emit('close-click');
		},

		/**
		 * @description Evento emitido com o Botão Salvar no Modal
		 */

		emitClick(dto) {
			let formData = {
				valor: this.inputForm.valor,
				dataHora: this.inputForm.dataHora,
				descTanque: this.inputForm.descTanque,
				codigo: this.inputForm.codigo,
				descSensor: this.inputForm.descSensor
			};
			let service = new Service();
			this.$validator.validateAll().then(formValido => {
				if (!formValido) return;

				if (dto != null) {
					formData.id = dto.id;
					service.getById(dto.id).then(data => {
						data.valor = formData.valor;
						data.dataHora = formData.dataHora;
						data.descTanque = formData.descTanque;
						data.codigo = formData.codigo;
						data.descSensor = formData.descSensor;

						service.update(data, data.id).then(success => {
							this.$emit('emit-click', data);
						});
					});
				} else {
					service.create(formData).then(
						success => {
							this.$emit('emit-click', success);
						},
						err => {}
					);
				}
			});
		},

		/**
		 * @description Indica que o formulario ja foi carregado
		 */
		setFirstFormLoading() {
			this.first_form_loading = true;
		}
	},

};
</script>

<style scoped>
div.modal-footer {
	padding-right: 0 !important;
	border-top: 0 !important;
}
.custom-file-input:lang(en) ~ .custom-file-label::after {
	content: 'Navegar';
}
</style>
