<template>
  <div id="divDado">
    <div class="card">
      <h5 class="card-header">Dado</h5>
      <div class="card-body">
        <b-pagination
          align="right"
          :total-rows="totalRows"
          v-model="currentPage"
          :per-page="filter.PageSize"/>
        <div class="table-responsive">
          <table
            id="tableDado"
            class="table table-hover">
            <thead>
              <tr>
                <th>Valor</th>
                <th>Data_Hora</th>
                <th>Desc.Tanque</th>
                <th>Código</th>
                <th>Desc.Sensor</th>
                <th/>
                <th class="text-right">
                  <a
                    class="fa fa-plus-circle"
                    href="#"
                    data-toggle="modal"
                    data-target="#modal"
                    @click="selectRow(index=null, 'create')" />
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="data.length === 0" > <td
                colspan="11"
                class="text-center font-italic"><label> Não existem registros cadastrados </label></td></tr>
              <tr
                v-for="(row, index) in data"
                :key="row.id">
                <td>{{ row.valor }}</td>
                <td>{{ row.data_hora }}</td>
                <td>{{ row.desc_tanque }}</td>
                <td>{{ row.codigo }}</td>
                <td>{{ row.desc_sensor }}</td>
                <td class="text-right">
                  <a
                    class="fa fa-edit"
                    href="#"
                    data-toggle="modal"
                    data-target="#modal"
                    @click="selectRow(index, 'update')"/>
                </td>
                <td class="text-right">
                  <a
                    class="fa fa-trash"
                    href="#"
                    data-toggle="modal"
                    data-target="#modalDelete"
                    @click="selectRow(index, 'delete')"/>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <b-pagination
          align="right"
          :total-rows="totalRows"
          v-model="currentPage"
          :per-page="filter.PageSize"/>
      </div>
    </div>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span
        slot="title"
        v-if="dto!=null">Editar Dado</span>
      <span
        slot="title"
        v-else>Cadastrar Dado</span>
      <div slot="body">
        <Form
          v-bind="{ dto: dto, action: action}"
          @emit-click="getChanges"
          @close-click="clearFields"/>
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"/>

  </div>
</template>

<script>
import Form from '@/components/views/aquicultura/dado/Form';
import Service from '@/services/aquicultura/Dado';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChangeLarge';
import ModalDelete from '@/components/controls/ModalDelete';
import * as settings from '@/settings';

import Mgr from '@/services/SecurityService';
import Vue from 'vue';
import axios from 'axios';

const baseUrl = settings.baseUrl;
const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data () {
    return {
      data: [{
        valor: 30.0,
        data_hora: '08:00',
        desc_tanque: 'Tanque 1',
        codigo: 1,
        desc_sensor: 'Temperatura'
      },
      {
        valor: 32.0,
        data_hora: '08:30',
        desc_tanque: 'Tanque 2',
        codigo: 2,
        desc_sensor: 'Temperatura'
      },
      {
        valor: 31.0,
        data_hora: '09:00',
        desc_tanque: 'Tanque 3',
        codigo: 3,
        desc_sensor: 'Temperatura'
      },
      {
        valor: 33.0,
        data_hora: '09:30',
        desc_tanque: 'Tanque 4',
        codigo: 4,
        desc_sensor: 'Temperatura'
      }],
      dto: {},
      action: null,
      index: null,
      currentStatus: null,
      filter: {
        ...BaseFilter
      },
      currentPage: 1,
      totalRows: 0,
      urlUpload: baseUrl + 'api/Instituicoes/logo/',
      user: new Mgr(),
      token: null
    };
  },
  watch: {
    currentPage: function () {
      this.filter.Page = this.currentPage;
      this.populate();
    }
  },
  components: {
    Form,
    ModalChange,
    ModalDelete
  },
  methods: {
    /**
     * @description Atualiza a linha selecionada na tabela
     * @param {index} indice selecionado na tabela
     * @param {row} linha selecionada na tabela
     */
    selectRow (index, action) {
      // Atualiza a linha selecionada
      this.index = index;

      // Atualiza o objeto selecionado
      this.dto = this.data[this.index];

      // Atualiza a acao selecionada
      this.action = action;

      console.log('selectRow - index', this.index);
      console.log('selectRow - dto', this.dto);
      console.log('selectRow - action', this.action);
    },

    /**
     * @description Obtem o registro modificado de form
     * @param {dto} parametro
     */
    clearFields () {
      this.dto = null;
      this.action = '';
    },
    getChanges (dto) {
      if (this.index != null) {
        this.data[this.index].valor = dto.valor;
        this.data[this.index].data_hora = dto.data_hora;
        this.data[this.index].desc_tanque = dto.desc_tanque;
        this.data[this.index].codigo = dto.codigo;
        this.data[this.index].desc_sensor = dto.desc_sensor;
      } else {
        this.populate();
      }
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected () {
      // remove pelo id
      let id = this.data[this.index].id;
      new Service().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.data.splice(this.index, 1);
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
      this.deleteModal = false;
    },
    populate () {
      this.data = [{
        valor: 30.0,
        data_hora: '08:00',
        desc_tanque: 'Tanque 1',
        codigo: 1,
        desc_sensor: 'Sensor 1'
      }]
    //   new Service().getAll(this.filter, 'count').then(
    //     count => {
    //       this.totalRows = count;
    //     },
    //     err => {}
    //   );

    //   let promise = new Service().getAll(this.filter);
    //   promise.then(
    //     success => {
    //       console.log('sucess ====> ', success);
    //       this.data = success;
    //       this.data.forEach(element => {
    //         let img = this.data[this.data.indexOf(element)].imagem;
    //         this.data[this.data.indexOf(element)].imagem = this.urlUpload + img;
    //       });
    //       this.currentStatus = STATUS_SUCCESS;
    //     },
    //     err => {
    //       this.currentStatus = STATUS_FAILED;
    //     }
    //   );
    // }
    },
    created () {
      var user = new Mgr();
      user.getUser().then(
        sucess => {
          axios.defaults.headers.common['Authorization'] =
          'Bearer ' + sucess.access_token;
        },
        err => {
          console.log(err);
        }
      );

      this.user.getUser().then(
        sucess => {
          this.token = '?access_token=' + sucess.access_token;
        },
        err => {
          console.log(err);
        }
      );
      this.populate();
    }
  }
}

</script>

<style scoped>
table {
  font-size: 20px;
}
.img {
  width: 5ex;
  height: 5ex;
  padding: 0px;
  border-radius: 50em;
  vertical-align: middle;
  border-style: double;
  border-color: #20a8d8;
}
</style>
