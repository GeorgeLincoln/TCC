<template>
  <div id="app">
    <!-- <nav>
      <div class="nav-wrapper blue darken-1">
        <a href="#" class="brand-logo center">tipoTanque Front</a>
      </div>
    </nav>
    <div class="container">
      <ul>
        <li v-for="(erro, index) of errors" :key="index">
          campo <b>{{erro.field}}</b> - {{erro.defaultMessage}}
        </li>
      </ul>
      <form @submit.prevent="salvar">
          <label>Tipo tanque</label>
          <input type="text" placeholder="Tipo tanque" v-model="tipoTanque.tipo_tanque" >

          <button class="waves-effect waves-light btn-small">Salvar<i class="material-icons left">save</i></button>
      </form>
      <table>
        <thead>
          <tr>
            <th>TIPO TANQUE</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="tipoTanque of tipoTanque" :key="tipoTanque.codigo">
            <td>{{ tipoTanque.tipo_tanque }}</td>
            <td>
              <button @click="editar(tipoTanque)" class="waves-effect btn-small blue darken-1"><i class="material-icons">create</i></button>
              <button @click="remover(tipoTanque)" class="waves-effect btn-small red darken-1"><i class="material-icons">delete_sweep</i></button>
            </td>
          </tr>
        </tbody>
      </table>
    </div> -->
    <div class="Chart">
      <h1 style="text-align:center;">Barchart</h1>
      <bar-example/>
    </div>
    <div class="Chart">
      <h1 style="text-align:center;">Linechart</h1>
      <line-example :chart-data="DataTemperatura"/>
    </div>
  </div>
  
</template>

<script>
import BarExample from '@/components/examples/BarExample';
import LineExample from '@/components/examples/LineExample';
import TipoTanque from '@/services/tipoTanque';
export default {
  components: {
    BarExample,
    LineExample
  },
  name: 'app',
  data() {
    return {
      tipoTanque: {
        codigo: '',
        tipo_tanque: ''
      },
      tipoTanque: [],
      errors: []
    };
  },
  mounted() {
    this.listar();
    setInterval(() => {
      this.fillDataTemperatura();
    }, 2000);
  },
  methods: {
    fillDataTemperatura() {
      this.DataTemperatura = {
        labels: this.gethora(),
        datasets: [
          {
            label: ' temperatura',
            backgroundColor: '#03A9F4',
            data: this.getTemperatura()
          }
        ]
      };
    },
    getTemperatura() {
      for (let i = 0; i < 10; ++i) {
        this.temperatura.push(this.placas[i].valortemp);
      }
      return this.temperatura;
    },
    gethora() {
      this.hora = [];
      for (let i = 0; i < 10; ++i) this.hora.push(this.placas[i].datahora);
      return this.hora;
    },
    listar() {
      TipoTanque.listar()
        .then(resposta => {
          this.tipoTanque = resposta.data;
        })
        .catch(e => {
          console.log(e);
        });
    },
    salvar() {
      if (!this.tipoTanque.id) {
        TipoTanque.salvar(this.tipoTanque)
          .then(resposta => {
            this.tipoTanque = {};
            alert('Cadastrado com sucesso!');
            this.listar();
            this.errors = {};
          })
          .catch(e => {
            this.errors = e.response.data.errors;
          });
      } else {
        TipoTanque.atualizar(this.tipoTanque)
          .then(resposta => {
            this.tipoTanque = {};
            this.errors = {};
            alert('Atualizado com sucesso!');
            this.listar();
          })
          .catch(e => {
            this.errors = e.response.data.errors;
          });
      }
    },
    editar(tipoTanque) {
      this.tipoTanque = tipoTanque;
    },
    remover(tipoTanque) {
      if (confirm('Deseja excluir o tipoTanque?')) {
        TipoTanque.apagar(tipoTanque)
          .then(resposta => {
            this.listar();
            this.errors = {};
          })
          .catch(e => {
            this.errors = e.response.data.errors;
          });
      }
    }
  }
};
</script>

<style>
</style>