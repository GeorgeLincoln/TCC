<template>
  <div id="divTanque">
    <div class="card">
      <h5 class="card-header">Tanque
        <a v-if="data.length === 0"
          class="fa fa-print float-right not-print"/>
        <a v-else
        class="fa fa-print float-right"
        href="#"
        @click="printPdf"/>
      </h5>
      <div class="card-body">
        <div
          class="row col-12"
          style="padding:0; margin:0">
          <div
            id="input-search"
            class="col-md-6"
            style="padding:0">
            <FormBusca
              align="left"
              :total-rows-in-page="10"
              :total-rows="totalRows"
              @emit-click="searchClick"/>
          </div>
          <div
            class="col-md-6 navigation-top"
          >
            <wv-paginator
              :total-rows="totalRows"
              :filter="filter"
              class="paginator"
              v-model="filter"
              @input="populate()"
            />
          </div>
        </div>
        <table
          id="tableTanque"
          class="table">
          <thead>
            <tr>
              <th @click="reverse('Nome')">
                Latitude
                <i
                  v-if="filter.SortBy == 'Nome'"
                  class="fa"
                  :class="`fa-sort-${filter.IsAscending ? 'asc' : 'desc'}`"
                />
                
                <th>Longitude</th>
                <th>Ativo</th>
                <th>Descrição</th>
                <th>Código</th>
                <th>Tipo de Tanque</th>
              </th>
              <th class="text-right">
                <a
                  class="fa fa-plus-circle"
                  href="#"
                  data-toggle="modal"
                  data-target="#modal"
                  @click="selectRow(index=null)"/>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="data.length === 0">
              <td
                class="text-center font-italic"
                colspan="2">
                <label>Não existem registros cadastrados</label>
              </td>
            </tr>
            <tr
              v-for="(row, index) in data"
              :key="row.id">
              <td>{{ row.latitude }}</td>
                <td>{{ row.longitude }}</td>
                <td>{{ row.ativo }}</td>
                <td>{{ row.descricao }}</td>
                <td>{{ row.codigo }}</td>
                <td>{{ row.tipo_tanque_id.tipo_tanque }}</td>
              <td class="text-right">
                <a
                  class="fa fa-edit"
                  href="#"
                  data-toggle="modal"
                  data-target="#modal"
                  @click="selectRow(index)"/>
                <a
                  class="fa fa-trash"
                  href="#"
                  data-toggle="modal"
                  data-target="#modalDelete"
                  @click="selectRow(index)"/>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="row">
          <div class="col-12 col-sm-12 col-md-12 col-lg-12">
            <wv-paginator
              :total-rows="totalRows"
              :filter="filter"
              class="paginator"
              v-model="filter"
              @input="populate()"
            />
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para Create & Update -->
    <ModalChange>
      <span
        slot="title"
        v-if="dto!=null">Editar Tanque</span>
      <span
        slot="title"
        v-else>Cadastrar Tanque</span>
      <div slot="body">
        <Form
          v-bind="{ dto: dto}"
          @emit-click="getChanges"
          @close-click="clearFields"/>
      </div>
    </ModalChange>

    <!-- Modal para Delete -->
    <ModalDelete @emit-click="deleteSelected"/>

  </div>
</template>

<script>
import axios from 'axios';
import reportMixin from '@/components/mixins/report';
import Form from '@/components/views/aquicultura/tanque/Form';
import Service from '@/services/aquicultura/Tanque';
import BaseFilter from '@/objects/filters/BaseFilter';
import ModalChange from '@/components/controls/ModalChange';
import ModalDelete from '@/components/controls/ModalDelete';
import FormBusca from '@/components/controls/FormBusca';
import wvPaginator from '@/components/controls/wvPaginator';
import sortFilters from '@/components/mixins/sortFilters';

const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  data () {
    return {
      dados: [],
      descTanque: [],
      errors: [],
      dado: {
        tipo_sensor: 'sensor3'
      },
      data: [],
      dto: {},
      index: null,
      currentStatus: null,
      filter: {
        ...BaseFilter
      },
      currentPage: 1,
      totalRows: 0
    };
  },
  mixins: [sortFilters, reportMixin],
  watch: {
    currentPage: function () {
      this.filter.Page = this.currentPage;
      this.populate();
    }
  },
  components: {
    Form,
    ModalChange,
    ModalDelete,
    FormBusca,
    wvPaginator
  },
  methods: {
    api() {
      axios.defaults.baseURL = `http://10.70.80.40:8080/`;
      axios
        .get(`tanque`)
        .then(respose => {
          this.dados = respose.data;
          console.log(respose.data);
        })
        .catch(e => {
          this.errors.push(e);
        });
    },
    searchClick (search) {
      search != '' ? this.populateSearch(search) : this.populate();
    },
    nextPage (page) {
      this.filter.Page = page;
      search != '' ? this.populateSearch(search) : this.populate();
    },
    /**
     * @description Atualiza a linha selecionada na tabela
     * @param {index} indice selecionado na tabela
     * @param {row} linha selecionada na tabela
     */
    selectRow (index) {
      // Atualiza a linha selecionada
      this.index = index;

      // Atualiza o objeto selecionado
      this.dto = this.data[this.index];
    },

    /**
     * @description Obtem o registro modificado de form
     * @param {dto} parametro
     */
    clearFields () {
      this.dto = null;
      this.action = '';
    },
    getChanges (dto) {
      if (this.index != null) {
        this.data[this.index].nome = dto.nome;
      } else {
        this.populate();
      }
    },

    /**
     * @description Remove o registro pelo id
     */
    deleteSelected () {
      // remove pelo id
      let id = this.data[this.index].id;
      new Service().delete(id).then(
        success => {
          this.currentStatus = STATUS_SUCCESS;
          // atualiza a tabela
          this.populate();
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
      this.deleteModal = false;
    },
    populateSearch (busca) {
      this.filter.Nome = busca;
      let promise = new Service().getAll(this.filter, 'filter');
      promise.then(
        success => {
          this.data = success;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );

      new Service().getAll(this.filter, 'filter/count').then(
        count => {
          this.totalRows = count;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
    },
    populate () {
      // this.filter.Nome = null;
      new Service().getAll(this.filter, 'filter/count').then(
        count => {
          this.totalRows = count;
        },
        err => {}
      );

      let promise = new Service().getAll(this.filter, 'filter');
      promise.then(
        success => {
          this.data = success;
          this.currentStatus = STATUS_SUCCESS;
        },
        err => {
          this.currentStatus = STATUS_FAILED;
        }
      );
    },

    printPdf() {
      // Configurações do Relatórios
      var title = 'Blocos da Instituição';
      var labels = ['Nome'];
      var columns = ['nome'];
      var widths = ['auto'];

      var filter = { ...this.filter };
      filter.GetAll = true;
      let promise = new Service().getAll(filter, 'filter');
      promise.then(
        success => {
          this.buildPdfReport(success, labels, columns, widths, title);
        },
        err => {}
      );
    }, // fim do método printPdf

  },
  created () {
    this.filter.SortBy = 'Nome';
  },
  mounted () {
    this.populate();
  },
   computed: {
    myStyles() {
      return {
        height: `${this.height}px`,
        position: 'relative'
      };
    }
  }
};
</script>

<style scoped>
  table {
    font-size: 20px;
  }
  .navigation-top {
    padding: 0px;
  }
  .not-print{
    color: #9e9e9e !important;
  }
	@media screen and (max-width: 790px) {
  #input-search {
    flex: 0 0 100%;
    max-width: 100%;
  }
  div.navigation-top {
    display: none;
  }
  div.navigation-bottom {
      display: flex;
      justify-content: center;
    }
    .paginator:nth-child(1).display {
      justify-content: center;
    }
}
</style>
