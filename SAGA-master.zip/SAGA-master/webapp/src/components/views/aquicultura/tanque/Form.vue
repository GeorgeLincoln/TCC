<template>
  <div class="card">
    <h5 class="card-header">Dados do Tanque</h5>
    <div
      id="divTanque"
      class="card-body">
      <form
        id="formTanque"
        novalidate>
        <div class="row"/>
        <b-row>
            <b-row>
          <b-col sm="6">
            <b-form-group>
              <label for="latitude">Latitude<small>*</small></label>
              <input
                type="text"
                class="form-control"
                id="latitude"
                name="latitude"
                v-validate="'required'"
                ref="latitude"
                v-model="$data.inputForm.latitude">
                <small
                class="form-text text-danger"
                v-if="errors.has('latitude')">Latitude
              	</small>
            </b-form-group>
          </b-col>
        <b-col sm="6">
            <b-form-group>
              <label for="longitude">Longitude<small>*</small></label>
              <input
                type="text"
                class="form-control"
                id="longitude"
                name="longitude"
                v-validate="'required'"
                ref="longitude"
                v-model="$data.inputForm.longitude">
                <small
                class="form-text text-danger"
                v-if="errors.has('longitude')">Longitude é obrigatório
              </small>
            </b-form-group>
          </b-col>
     
          <b-col sm="6">
               <label for="ativo">Ativo</label>
                <input
                type="checkbox"
                v-model="toggle"
                true-value="yes"
                false-value="no"
                >
              </b-col>
            <b-col sm="6">
              <span>Descrição:</span>
              <p style="white-space: pre-line;">{{ message }}</p>
              <textarea v-model="message" placeholder="Descrição"></textarea>
              </b-col>
        </b-row>
            
          <b-col sm="6">
            <b-form-group>
              <label for="codigo">Código<small>*</small></label>
              <input
                type="text"
                class="form-control"
                name="codigo"
                v-validate="'required'"
                ref="codigo"
                v-model="$data.inputForm.codigo">
                <small
                class="form-text text-danger"
                v-if="errors.has('codigo')"> Código é obrigatório
              </small>
            </b-form-group>
          </b-col>
        </b-row>

        <b-row>
          <b-col sm="6">
            <b-form-group>
              <label for="tipo_tanque_id">Tipo do Tanque<small>*</small></label>
              <input
                type="text"
                class="form-control"
                name="tipo_tanque_id"
                v-validate="'required'"
                ref="tipo_tanque_id"
                v-model="$data.inputForm.tipo_tanque_id">
                <small
                class="form-text text-danger"
                v-if="errors.has('tipo_tanque_id')"> Tipo do Tanque é obrigatório
              </small>
            </b-form-group>
          </b-col>
        </b-row>   

        <div class="modal-footer">
          <button
            id="btnCancelar"
            type="button"
            class="btn btn-secondary"
            @click.prevent="closeClick()">Cancelar</button>
          <button
            id="btnSalvar"
            type="button"
            class="btn btn-primary"
            @click.prevent="emitClick(dto)"
            :disabled="errors.any()">Salvar</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import reportMixin from '@/components/mixins/report';
import estadosMixin from '@/components/mixins/estados';
import getattrMixin from '@/components/mixins/getattr';
import Service from '@/services/aquicultura/Tanque';
import GEService from '@/services/admin/GestoresService';
import NEService from '@/services/admin/NiveisEnsinoService';
import InstituicoesService from '@/services/admin/InstituicoesService';

import BaseFilter from '@/objects/filters/BaseFilter';
import DatePicker from '@/components/controls/DatePicker';
import * as settings from '@/settings';
const baseUrl = settings.baseUrl;
const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  props: ['dto', 'action'] /* dto is passed in table component to this form */,
  mixins: [getattrMixin, estadosMixin, reportMixin],

  data() {
    return {
      inst: null,
      inputForm: {
        latitude: '',
        longitude: '',
        ativo: '',
        descricao: '',
        codigo: '',
        tipo_tanque_id: ''
      },
     
    };
  },

  components: {
    DatePicker
  },
  watch: {
    inst: function() {
      this.inputForm.latitude = this.inst.latitude;
      this.inputForm.longitude = this.inst.longitude;
      this.inputForm.ativo = this.inst.ativo;
      this.inputForm.descricao = this.inst.descricao;
      this.inputForm.codigo = this.inst.codigo;
      this.inputForm.tipo_tanque_id = this.inst.tipo_tanque_id;
    },
  },
  methods: {
    getFileName(file) {
      console.log('getFileName', file);
      if (typeof file === 'object') {
        return file.name;
      } else if (typeof file === 'string') {
        return file;
      }
    },

    /**
     * @description Evento emitido com o Botão Cancelar no Modal
     */
    closeClick() {
      this.setFirstFormLoading();
      var btn = document.getElementById('btnCancelar');
      btn.setAttribute('data-dismiss', 'modal');
      btn = document.getElementById('btnSalvar');
      btn.setAttribute('data-dismiss', 'modal');
    },

    /**
     * @description Evento emitido com o Botão Salvar no Modal
     */
    emitClick(dto) {
      this.setFirstFormLoading();
      this.$validator.validateAll().then(formValido => {
        if (formValido) {
          console.log(dto);
          try {
            console.log('[form][emitClick]');
            console.log(this.inputForm);
            // get form data
            let formData = {
              latitude: this.inputForm.latitude,
              longitude: this.inputForm.longitude,
              ativo: this.inputForm.ativo,
              descricao: this.inputForm.descricao,
              codigo: this.inputForm.codigo,
              tipo_tanque_id: this.inputForm.tipo_tanque_id
            };

            console.log('[form][emitClick] formData');
            console.log(formData);

            let service = new Service();

            /* Form Update */
            let objPromisse = service
              .getById(this.inst.id)
              .then(
                success => {
                  let data = success;
                  data.latitude = formData.latitude;
                  data.longitude = formData.longitude;
                  data.ativo = formData.ativo;
                  data.descricao = formData.descricao;
                  data.codigo = formData.codigo;
                  data.tipo_tanque_id = formData.tipo_tanque_id;

                  console.log('[form][emitClick] data:');
                  // console.log(data);

                  let promise = service.update(data, data.id).then(
                    success => {
                      console.log('[form] update success');
                      console.log('img ===', this.img);
                      formData.imagem = 0;
                      this.$emit('emit-click', formData);
                      // Envia a imagem (logo) para a web api
                      let x = this.uploadSelectedLogo(data.id, formData);

                      // formData.imagem = this.urlUpload+this.img;
                      // this.$emit('emit-click', formData);
                      this.closeClick();
                    },
                    err => {
                      throw err;
                    }
                  );
                },
                err => {
                  throw err;
                }
              )
              .catch(err => {});
          } catch (err) {
            console.log(err);
          }
          console.log('End of Click Method!');
          this.closeClick();
        }
      });
    },

    /**
     * @description Envia a imagem selecionada para a api web
     */
    uploadSelectedLogo(id, formData) {
      let vm = this;
      console.log('uploadSelectedLogo');
      if (typeof this.inputForm.imagem === 'object') {
        var reader = new FileReader();

        reader.readAsDataURL(this.inputForm.imagem);
        reader.onload = function() {
          console.log('reader', reader);

          let service = new Service();
          service.uploadBase64(reader.result, id).then(
            success => {
              formData.imagem = vm.urlUpload + success;
              vm.$emit('emit-click', formData);
              console.log('[form] create success');
            },
            err => {
              console.log('erro ao enviar!');
              throw err;
            }
          );
        };
        // return vm;
      } else {
        // Nenhuma imagem para atualizar
        console.log('Nenhuma imagem para atualizar.');
      }

      // return vm;
    },

    /**
     * @description Indica que o formulario ja foi carregado
     */
    setFirstFormLoading() {
      this.first_form_loading = true;
    },

    /**
     * @description Limpa campos do formulário
     */
    clearFields() {
      // Limpa campos do formulário
      console.log('clearFields');
      this.inputForm.latitude = '';
      this.inputForm.longitude = '';
      this.inputForm.ativo = '';
      this.inputForm.descricao = '';
      this.inputForm.codigo = '';
      this.inputForm.tipo_tanque_id = '';
    }
  },
  created() {
    console.log('created.');

    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService()
      .getAll(BaseFilter)
      .then(data => (this.inst = data[0]));

    new GEService()
      .getAll(BaseFilter, 'dropdown')
      .then(data => (this.ge = data));
    new NEService().getAll(BaseFilter).then(data => (this.ne = data));
  },

  updated() {}
};
</script>

<style scoped>
div.modal-footer {
  padding-right: 0 !important;
  border-top: 0 !important;
}
.custom-file-input:lang(en) ~ .custom-file-label::after {
  content: 'Navegar';
}
input[type='text'] {
  border-radius: 0.25rem;
}
</style>
