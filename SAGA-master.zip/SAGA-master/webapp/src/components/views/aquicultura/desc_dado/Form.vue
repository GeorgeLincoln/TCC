<template>
  <div class="card">
    <h5 class="card-header">Descrição dos Dados</h5>
    <div
      id="divDescDado"
      class="card-body">
      <form
        id="formDescDado"
        novalidate>
        <div class="row"/>
        <b-row>
            <b-row>
          <b-col sm="6">
            <b-form-group>
              <label for="codigo">Código<small>*</small></label>
              <input
                type="text"
                class="form-control"
                id="codigo"
                name="codigo"
                v-validate="'required'"
                ref="codigo"
                v-model="$data.inputForm.codigo">
                <small
                class="form-text text-danger"
                v-if="errors.has('codigo')">Código
              	</small>
            </b-form-group>
          </b-col>
        <b-col sm="6">
            <b-form-group>
              <label for="tipo_sensor_id">Tipo de Sensor<small>*</small></label>
              <input
                type="text"
                class="form-control"
                id="tipo_sensor_id"
                name="tipo_sensor_id"
                v-validate="'required'"
                ref="tipo_sensor_id"
                v-model="$data.inputForm.tipo_sensor_id">
                <small
                class="form-text text-danger"
                v-if="errors.has('tipo_sensor_id')">Tipo de Sensor é obrigatório
              </small>
            </b-form-group>
          </b-col>
     
        </b-row>
            
          <b-col sm="6">
            <b-form-group>
              <label for="tipo_dado_id">Tipo de Dado<small>*</small></label>
              <input
                type="text"
                class="form-control"
                name="tipo_dado_id"
                v-validate="'required'"
                ref="tipo_dado_id"
                v-model="$data.inputForm.tipo_dado_id">
                <small
                class="form-text text-danger"
                v-if="errors.has('tipo_dado_id')">Tipo de Dado é obrigatório
              </small>
            </b-form-group>
          </b-col>
        </b-row>

        <div class="modal-footer">
          <button
            id="btnCancelar"
            type="button"
            class="btn btn-secondary"
            @click.prevent="closeClick()">Cancelar</button>
          <button
            id="btnSalvar"
            type="button"
            class="btn btn-primary"
            @click.prevent="emitClick(dto)"
            :disabled="errors.any()">Salvar</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import reportMixin from '@/components/mixins/report';
import estadosMixin from '@/components/mixins/estados';
import getattrMixin from '@/components/mixins/getattr';
import Service from '@/services/aquicultura/DescDado';
import GEService from '@/services/admin/GestoresService';
import NEService from '@/services/admin/NiveisEnsinoService';
import InstituicoesService from '@/services/admin/InstituicoesService';

import BaseFilter from '@/objects/filters/BaseFilter';
import DatePicker from '@/components/controls/DatePicker';
import * as settings from '@/settings';
const baseUrl = settings.baseUrl;
const STATUS_INITIAL = 0,
  STATUS_SAVING = 1,
  STATUS_SUCCESS = 2,
  STATUS_FAILED = 3;

export default {
  props: ['dto', 'action'] /* dto is passed in table component to this form */,
  mixins: [getattrMixin, estadosMixin, reportMixin],

  data() {
    return {
      inst: null,
      inputForm: {
        codigo: '',
        tipo_sensor_id: '',
        tipo_dado_id: ''
      },
     
    };
  },

  components: {
    DatePicker
  },
  watch: {
    inst: function() {
      this.inputForm.codigo = this.inst.codigo;
      this.inputForm.tipo_sensor_id = this.inst.tipo_sensor_id;
      this.inputForm.tipo_dado_id = this.inst.tipo_dado_id;
    },
  },
  methods: {
    getFileName(file) {
      console.log('getFileName', file);
      if (typeof file === 'object') {
        return file.name;
      } else if (typeof file === 'string') {
        return file;
      }
    },

    /**
     * @description Evento emitido com o Botão Cancelar no Modal
     */
    closeClick() {
      this.setFirstFormLoading();
      var btn = document.getElementById('btnCancelar');
      btn.setAttribute('data-dismiss', 'modal');
      btn = document.getElementById('btnSalvar');
      btn.setAttribute('data-dismiss', 'modal');
    },

    /**
     * @description Evento emitido com o Botão Salvar no Modal
     */
    emitClick(dto) {
      this.setFirstFormLoading();
      this.$validator.validateAll().then(formValido => {
        if (formValido) {
          console.log(dto);
          try {
            console.log('[form][emitClick]');
            console.log(this.inputForm);
            // get form data
            let formData = {
              codigo: this.inputForm.codigo,
              tipo_sensor_id: this.inputForm.tipo_sensor_id,
              tipo_dado_id: this.inputForm.tipo_dado_id
            };

            console.log('[form][emitClick] formData');
            console.log(formData);

            let service = new Service();

            /* Form Update */
            let objPromisse = service
              .getById(this.inst.id)
              .then(
                success => {
                  let data = success;
                  data.codigo = formData.codigo;
                  data.tipo_sensor_id = formData.tipo_sensor_id;
                  data.tipo_dado_id = formData.tipo_dado_id;

                  console.log('[form][emitClick] data:');
                  // console.log(data);

                  let promise = service.update(data, data.id).then(
                    success => {
                      console.log('[form] update success');
                      console.log('img ===', this.img);
                      formData.imagem = 0;
                      this.$emit('emit-click', formData);
                      // Envia a imagem (logo) para a web api
                      let x = this.uploadSelectedLogo(data.id, formData);

                      // formData.imagem = this.urlUpload+this.img;
                      // this.$emit('emit-click', formData);
                      this.closeClick();
                    },
                    err => {
                      throw err;
                    }
                  );
                },
                err => {
                  throw err;
                }
              )
              .catch(err => {});
          } catch (err) {
            console.log(err);
          }
          console.log('End of Click Method!');
          this.closeClick();
        }
      });
    },

    /**
     * @description Envia a imagem selecionada para a api web
     */
    uploadSelectedLogo(id, formData) {
      let vm = this;
      console.log('uploadSelectedLogo');
      if (typeof this.inputForm.imagem === 'object') {
        var reader = new FileReader();

        reader.readAsDataURL(this.inputForm.imagem);
        reader.onload = function() {
          console.log('reader', reader);

          let service = new Service();
          service.uploadBase64(reader.result, id).then(
            success => {
              formData.imagem = vm.urlUpload + success;
              vm.$emit('emit-click', formData);
              console.log('[form] create success');
            },
            err => {
              console.log('erro ao enviar!');
              throw err;
            }
          );
        };
        // return vm;
      } else {
        // Nenhuma imagem para atualizar
        console.log('Nenhuma imagem para atualizar.');
      }

      // return vm;
    },

    /**
     * @description Indica que o formulario ja foi carregado
     */
    setFirstFormLoading() {
      this.first_form_loading = true;
    },

    /**
     * @description Limpa campos do formulário
     */
    clearFields() {
      // Limpa campos do formulário
      console.log('clearFields');
      this.inputForm.codigo = '';
      this.inputForm.tipo_sensor_id = '';
      this.inputForm.tipo_dado_id = '';
    }
  },
  created() {
    console.log('created.');

    // temporário (até se definir como obter a instituicao corrente)
    new InstituicoesService()
      .getAll(BaseFilter)
      .then(data => (this.inst = data[0]));

    new GEService()
      .getAll(BaseFilter, 'dropdown')
      .then(data => (this.ge = data));
    new NEService().getAll(BaseFilter).then(data => (this.ne = data));
  },

  updated() {}
};
</script>

<style scoped>
div.modal-footer {
  padding-right: 0 !important;
  border-top: 0 !important;
}
.custom-file-input:lang(en) ~ .custom-file-label::after {
  content: 'Navegar';
}
input[type='text'] {
  border-radius: 0.25rem;
}
</style>
