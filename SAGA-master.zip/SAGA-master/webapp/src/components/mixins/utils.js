export default {
  methods: {
    /**
     * @description Retorna a data formatada como dd/mm/aaaa
     * @param {strData} String representando uma data. Ex.: "2018-01-01T13:45"
     */
    formatedDate (strData) {
      var data = new Date(strData)
      var dia = data.getDate()
      if (dia.toString().length === 1) dia = '0' + dia
      var mes = data.getMonth() + 1
      if (mes.toString().length === 1) mes = '0' + mes
      var ano = data.getFullYear()
      return dia + '/' + mes + '/' + ano
    },
    formatedTime (strData) {
      let data = new Date(strData)
      let hora = data.getHours()
      let minuto = data.getMinutes()
      if (minuto.toString().length === 1) minuto = '0' + minuto
      return hora + ':' + minuto
    },
    formatedDateTime (strData) {
      let data = new Date(strData)
      let dia = data.getDate()
      let hora = data.getHours()
      let minuto = data.getMinutes()
      if (dia.toString().length === 1) dia = '0' + dia
      let mes = data.getMonth() + 1
      if (mes.toString().length === 1) mes = '0' + mes
      let ano = data.getFullYear()
      if (minuto.toString().length === 1) minuto = '0' + minuto
      return dia + '/' + mes + '/' + ano + ' ' + hora + ':' + minuto
    }
  }
}
