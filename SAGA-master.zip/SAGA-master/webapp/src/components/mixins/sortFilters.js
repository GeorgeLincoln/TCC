export default {
  methods: {
    reverse (key) {
      if (this.filter.SortBy === key) { this.filter.IsAscending = !this.filter.IsAscending; } else this.filter.SortBy = key;
      this.populate();
    }
  }
}
