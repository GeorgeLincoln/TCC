<template>
  <div class="app">
    <AppHeader/>
    <div class="app-body">
      <Sidebar :nav-items="navItems"/>
      <main class="main">
        <breadcrumb :list="list"/>
        <div class="container-fluid">
          <router-view/>
        </div>
      </main>
      <AppAside/>
    </div>
    <AppFooter/>
  </div>
</template>

<script>
import nav from '@/_nav'
import { Header as AppHeader, Sidebar, Aside as AppAside, Footer as AppFooter, Breadcrumb } from '@/components/'

export default {
  name: 'Full',
  components: {
    AppHeader,
    Sidebar,
    AppAside,
    AppFooter,
    Breadcrumb
  },
  computed: {
    navItems () {
      const ENUM_MENU = this.$store.getters.getMenu || 'Gestor';

      if (ENUM_MENU === 'Gestor') {
        return nav.Gestor
      } else if (ENUM_MENU === 'Professor') {
        return nav.Professor
      } else if (ENUM_MENU === 'Aluno') {
        return nav.Aluno
      } else if (ENUM_MENU === 'Integração') {
        return nav.Integracao
      }
    },
    name () {
      return this.$route.name
    },
    list () {
      const routes = this.$route.matched.slice(1);

      return routes.filter(route => route.path !== '/home/admin' && route.path !== '/home/acad' && route.path !== '/home/comum')
    }
  }
}
</script>
