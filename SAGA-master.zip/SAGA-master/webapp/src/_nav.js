import Gestor from './_nav-gestor'
import Professor from './_nav-professor'
import Aluno from './_nav-aluno'
import Integracao from './_nav-integracao'
export default {
  Gestor,
  Professor,
  Aluno,
  Integracao
}
