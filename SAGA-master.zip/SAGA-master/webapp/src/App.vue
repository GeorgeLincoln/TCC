<template >
  <div v-if="signedIn">
    <div id="App">
      <router-view/>
    </div>
  </div>
</template>

<script>
import Mgr from './services/SecurityService';
export default {
  name: 'App',
  data () {
    if (process.env.npm_lifecycle_event === 'sec') {
      return {
        mgr: new Mgr(),
        signedIn: false
      };
    } else {
      return {
        signedIn: false
      };
    }
  },
  mounted () {
    // DEV and SEC
    if (process.env.npm_lifecycle_event === 'sec') {
      this.mgr.getSignedIn().then(
        sucess => {
          this.signedIn = sucess;
        },
        err => {
          console.log(err);
        }
      );
    } else {
      this.signedIn = true;
    }
  }
};
</script>

<style>
/* Import Font Awesome Icons Set */
@import '~flag-icon-css/css/flag-icon.min.css';
/* Import Font Awesome Icons Set */
/* $fa-font-path: '~font-awesome/fonts/'; */
@import '~font-awesome/css/font-awesome.min.css';
/* Import Simple Line Icons Set */
/* $simple-line-font-path: '~simple-line-icons/fonts/'; */
@import '~simple-line-icons/css/simple-line-icons.css';
/* Import Bootstrap Vue Styles */
@import '~bootstrap-vue/dist/bootstrap-vue.css';
</style>

<style lang="scss">
// Import Main styles for this application
@import './scss/style';
</style>