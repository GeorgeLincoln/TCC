// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import BootstrapVue from 'bootstrap-vue';
import App from './App';
import router from './router';
import VueTheMask from 'vue-the-mask';
import VeeValidate, { Validator } from 'vee-validate';
import CpfValidator from './utils/cpf.validator';
import Dictionary from './utils/dictionary';
import VueAuthImage from 'vue-auth-image';
import 'toastr/build/toastr.css';
import VueRouter from 'vue-router';
import store from './store';
import Mgr from '@/services/SecurityService';
import StarRating from 'vue-star-rating';

let mgr;

if (process.env.npm_lifecycle_event === 'sec') {
  mgr = new Mgr();
}

Validator.extend('cpf', CpfValidator);

Vue.use(VueTheMask);
Vue.use(VeeValidate, {
  locale: 'pt',
  dictionay: Dictionary,
  fieldsBagName: '$fields'
});
Vue.component('star-rating', StarRating);
Vue.use(VueRouter);
Vue.use(BootstrapVue);
Vue.use(VueAuthImage);

function findInArray (arr, obj) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === obj) {
      return true;
    }
  }
  return false;
}

router.beforeEach((to, from, next) => {
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  if (requiresAuth) {
    if (process.env.npm_lifecycle_event === 'sec') {
      mgr.getRole().then(
        sucess => {
          if (findInArray(to.meta.role, sucess)) {
            next();
          } else {
            next('/home/');
          }
        },
        err => {
          console.log(err);
        }
      );
    } else {
      next();
    }
  } else {
    next();
  }
});

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: {
    App
  }
});