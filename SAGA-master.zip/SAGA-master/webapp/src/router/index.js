import Vue from 'vue';
import Router from 'vue-router';

// Containers
import Full from '@/containers/Full';
// import Thin from '@/containers/Thin';

// Views
import Home from '@/views/Home';
import DashboardAmbientes from '@/components/Dashboard';

import Colors from '@/views/theme/Colors';
import Typography from '@/views/theme/Typography';

import Charts from '@/views/Charts';
import Widgets from '@/views/Widgets';

// Views - Components
import Cards from '@/views/base/Cards';
import Forms from '@/views/base/Forms';
import Switches from '@/views/base/Switches';
import Tables from '@/views/base/Tables';
import Breadcrumbs from '@/views/base/Breadcrumbs';
import Carousels from '@/views/base/Carousels';
import Collapses from '@/views/base/Collapses';
import Jumbotrons from '@/views/base/Jumbotrons';
import ListGroups from '@/views/base/ListGroups';
import Navs from '@/views/base/Navs';
import Navbars from '@/views/base/Navbars';
import Paginations from '@/views/base/Paginations';
import Popovers from '@/views/base/Popovers';
import ProgressBars from '@/views/base/ProgressBars';
import Tooltips from '@/views/base/Tooltips';

// Views - Buttons
import StandardButtons from '@/views/buttons/StandardButtons';
import ButtonGroups from '@/views/buttons/ButtonGroups';
import Dropdowns from '@/views/buttons/Dropdowns';
import SocialButtons from '@/views/buttons/SocialButtons';

// Views - Icons
import Flags from '@/views/icons/Flags';
import FontAwesome from '@/views/icons/FontAwesome';
import SimpleLineIcons from '@/views/icons/SimpleLineIcons';

// Views - Notifications
import Alerts from '@/views/notifications/Alerts';
import Badges from '@/views/notifications/Badges';
import Modals from '@/views/notifications/Modals';

// Views - Pages
import Page404 from '@/views/pages/Page404';
import Page500 from '@/views/pages/Page500';
import Login from '@/views/pages/Login';
import Register from '@/views/pages/Register';

///////////////Aquicultura///////////////////

// tanque
import TanqueForm from '@/components/views/aquicultura/tanque/Form';
import TanqueTable from '@/components/views/aquicultura/tanque/Table';

// usuario
import UsuarioForm from '@/components/views/aquicultura/usuario/Form';
import UsuarioTable from '@/components/views/aquicultura/usuario/Table';

// tipo_dado
import TipoDadoForm from '@/components/views/aquicultura/tipo_dado/Form';
import TipoDadoTable from '@/components/views/aquicultura/tipo_dado/Table';

// tipo_sensor
import TipoSensorForm from '@/components/views/aquicultura/tipo_sensor/Form';
import TipoSensorTable from '@/components/views/aquicultura/tipo_sensor/Table';

// tipo_tanque
import TipoTanqueForm from '@/components/views/aquicultura/tipo_tanque/Form';
import TipoTanqueTable from '@/components/views/aquicultura/tipo_tanque/Table';
import TipoTanque from '@/components/views/aquicultura/tipo_tanque/tipoTanque';

// tipo_fase
import TipoFaseForm from '@/components/views/aquicultura/tipo_fase/Form';
import TipoFaseTable from '@/components/views/aquicultura/tipo_fase/Table';

// desc_tanque
import DescTanqueForm from '@/components/views/aquicultura/desc_tanque/Form';
import DescTanqueTable from '@/components/views/aquicultura/desc_tanque/Table';

// desc_dado
import DescDadoForm from '@/components/views/aquicultura/desc_dado/Form';
import DescDadoTable from '@/components/views/aquicultura/desc_dado/Table';

// dado
import DadoForm from '@/components/views/aquicultura/dado/Form';
import DadoTable from '@/components/views/aquicultura/dado/Table';
import Dado from '@/components/views/aquicultura/dado/Dado';

// Home dos Módulos
import HomeAluno from '@/views/home/homealuno'
import HomeProfessor from '@/views/home/homeprofessor'
import HomeIntegracao from '@/views/home/homeintegracao'


// import ExemploForm from '@/templates/exemplo/Form';
import ExemploTable from '@/templates/exemplo/Table';

Vue.use(Router);

function homeScreen(arr, obj) {
  if (process.env.npm_lifecycle_event === 'sec') {
    return '/home/gestor'
  } else {
    // return '/login'
    return '/home/gestor'
  }
}

export default new Router({
  mode: 'hash', // Demo is living in GitHub.io, so required!
  linkActiveClass: 'open active',
  scrollBehavior: () => ({
    y: 0
  }),
  routes: [{
    path: '/',
    redirect: homeScreen(),
    name: 'Teach in Touch',
    component: {
      render(c) {
        return c('router-view');
      }
    },
    children: [{
        path: '404',
        name: 'Page404',
        component: Page404
      },
      {
        path: '500',
        name: 'Page500',
        component: Page500
      },

      {
        path: 'Registro',
        name: 'Registro',
        component: Register
      },
      {
        path: 'login',
        name: 'Login',
        component: Login
      },
      {
        path: 'home',
        name: 'Full',
        meta: {
          label: 'Página Inicial'
        },
        redirect: '/home/gestor',
        component: Full,
        children: [{
            path: 'professor',
            name: 'Professor',
            component: HomeProfessor
          },
          {
            path: 'aluno',
            name: 'Aluno',
            component: HomeAluno
          },
          {
            path: 'integracao',
            name: 'Integração',
            component: HomeIntegracao
          },
          {
            path: 'dashboard',
            name: 'Informação dos Tanques',
            component: DashboardAmbientes
          },
          {
            path: 'gestor',
            name: 'Gestor',
            component: Home
          },
          {
            path: '/exemplo',
            name: 'ExemploTable',
            meta: {
              label: 'Tabela Exemplo'
            },
            component: ExemploTable
          },
          {
            path: 'aquicultura',
            name: 'aquicultura',
            component: {
              render(c) {
                return c('router-view');
              }
            },
            children: [{
                // http://localhost:8080/#/aquicultura/tanque/form
                path: '/aquicultura/tanque/form',
                name: 'Tanque',
                component: TanqueForm
              },
              {
                // http://localhost:8080/#/aquicultura/tanque/table
                path: '/aquicultura/tanque/table',
                name: 'Tanque',
                component: TanqueTable
              },
              {
                // http://localhost:8080/#/aquicultura/usuario/form
                path: '/aquicultura/usuario/form',
                name: 'usuario',
                component: UsuarioForm
              },
              {
                // http://localhost:8080/#/aquicultura/usuario/table
                path: '/aquicultura/usuario/table',
                name: 'usuario',
                component: UsuarioTable
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_dado/form
                path: '/aquicultura/tipo_dado/form',
                name: 'tipo_dado',
                component: TipoDadoForm
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_dado/table
                path: '/aquicultura/tipo_dado/table',
                name: 'tipo_dado',
                component: TipoDadoTable
              }, 
              {
                // http://localhost:8080/#/aquicultura/tipo_sensor/form
                path: '/aquicultura/tipo_sensor/form',
                name: 'tipo_sensor',
                component: TipoSensorForm
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_sensor/table
                path: '/aquicultura/tipo_sensor/table',
                name: 'tipo_sensor',
                component: TipoSensorTable
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_tanque/form
                path: '/aquicultura/tipo_tanque/form',
                name: 'tipo_tanque',
                component: TipoTanqueForm
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_tanque/table
                path: '/aquicultura/tipo_tanque/table',
                name: 'tipo_tanque',
                component: TipoTanqueTable
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_tanque/TipoTanque
                path: '/aquicultura/tipo_tanque/TipoTanque',
                name: 'tipo_tanque',
                component: TipoTanque
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_fase/form
                path: '/aquicultura/tipo_fase/form',
                name: 'tipo_fase',
                component: TipoFaseForm
              },
              {
                // http://localhost:8080/#/aquicultura/tipo_fase/table
                path: '/aquicultura/tipo_fase/table',
                name: 'tipo_fase',
                component: TipoFaseTable
              },
              {
                // http://localhost:8080/#/aquicultura/desc_tanque/form
                path: '/aquicultura/desc_tanque/form',
                name: 'desc_tanque',
                component: DescTanqueForm
              },
              {
                // http://localhost:8080/#/aquicultura/desc_tanque/table
                path: '/aquicultura/desc_tanque/table',
                name: 'desc_tanque',
                component: DescTanqueTable
              },
              {
                // http://localhost:8080/#/aquicultura/desc_dado/form
                path: '/aquicultura/desc_dado/form',
                name: 'desc_dado',
                component: DescDadoForm
              },
              {
                // http://localhost:8080/#/aquicultura/desc_dado/table
                path: '/aquicultura/desc_dado/table',
                name: 'desc_dado',
                component: DescDadoTable
              },
              {
                // http://localhost:8080/#/aquicultura/dado/dado
                path: '/aquicultura/dado/dado',
                name: 'dado',
                component: Dado
              },
              {
                // http://localhost:8080/#/aquicultura/dado/form
                path: '/aquicultura/dado/form',
                name: 'dado',
                component: DadoForm
              },
              {
                // http://localhost:8080/#/aquicultura/dado/table
                path: '/aquicultura/dado/table',
                name: 'dado',
                component: DadoTable
              },
              {
                // http://localhost:8080/#/dado/dado
                path: '/aquicultura/dado/dado',
                name: 'dado',
                component: DadoTable
              },
            ]
          },
          {
            path: 'theme',
            redirect: '/theme/colors',
            name: 'Theme',
            component: {
              render(c) {
                return c('router-view');
              }
            },
            children: [{
                path: 'colors',
                name: 'Colors',
                component: Colors
              },
              {
                path: 'typography',
                name: 'Typography',
                component: Typography
              }
            ]
          },
          {
            path: 'charts',
            name: 'Charts',
            component: Charts
          },
          {
            path: 'widgets',
            name: 'Widgets',
            component: Widgets
          },
          {
            path: 'base',
            redirect: '/base/cards',
            name: 'Base',
            component: {
              render(c) {
                return c('router-view');
              }
            },
            children: [{
                path: 'cards',
                name: 'Cards',
                component: Cards
              },
              {
                path: 'forms',
                name: 'Forms',
                component: Forms
              },
              {
                path: 'switches',
                name: 'Switches',
                component: Switches
              },
              {
                path: 'tables',
                name: 'Tables',
                component: Tables
              },
              {
                path: 'breadcrumbs',
                name: 'Breadcrumbs',
                component: Breadcrumbs
              },
              {
                path: 'carousels',
                name: 'Carousels',
                component: Carousels
              },
              {
                path: 'collapses',
                name: 'Collapses',
                component: Collapses
              },
              {
                path: 'jumbotrons',
                name: 'Jumbotrons',
                component: Jumbotrons
              },
              {
                path: 'list-groups',
                name: 'List Groups',
                component: ListGroups
              },
              {
                path: 'navs',
                name: 'Navs',
                component: Navs
              },
              {
                path: 'navbars',
                name: 'Navbars',
                component: Navbars
              },
              {
                path: 'paginations',
                name: 'Paginations',
                component: Paginations
              },
              {
                path: 'popovers',
                name: 'Popovers',
                component: Popovers
              },
              {
                path: 'progress-bars',
                name: 'Progress Bars',
                component: ProgressBars
              },
              {
                path: 'tooltips',
                name: 'Tooltips',
                component: Tooltips
              }
            ]
          }, 
          
        ]
        },
        {
          path: 'theme',
          redirect: '/theme/colors',
          name: 'Theme',
          component: {
            render (c) {
              return c('router-view');
            }
          },
          children: [{
            path: 'colors',
            name: 'Colors',
            component: Colors
          },
          {
            path: 'typography',
            name: 'Typography',
            component: Typography
          }
          ]
        },
        {
          path: 'charts',
          name: 'Charts',
          component: Charts
        },
        {
          path: 'widgets',
          name: 'Widgets',
          component: Widgets
        },
        {
          path: 'base',
          redirect: '/base/cards',
          name: 'Base',
          component: {
            render (c) {
              return c('router-view');
            }
          },
          children: [{
            path: 'cards',
            name: 'Cards',
            component: Cards
          },
          {
            path: 'forms',
            name: 'Forms',
            component: Forms
          },
          {
            path: 'switches',
            name: 'Switches',
            component: Switches
          },
          {
            path: 'tables',
            name: 'Tables',
            component: Tables
          },
          {
            path: 'breadcrumbs',
            name: 'Breadcrumbs',
            component: Breadcrumbs
          },
          {
            path: 'carousels',
            name: 'Carousels',
            component: Carousels
          },
          {
            path: 'collapses',
            name: 'Collapses',
            component: Collapses
          },
          {
            path: 'jumbotrons',
            name: 'Jumbotrons',
            component: Jumbotrons
          },
          {
            path: 'list-groups',
            name: 'List Groups',
            component: ListGroups
          },
          {
            path: 'navs',
            name: 'Navs',
            component: Navs
          },
          {
            path: 'navbars',
            name: 'Navbars',
            component: Navbars
          },
          {
            path: 'paginations',
            name: 'Paginations',
            component: Paginations
          },
          {
            path: 'popovers',
            name: 'Popovers',
            component: Popovers
          },
          {
            path: 'progress-bars',
            name: 'Progress Bars',
            component: ProgressBars
          },
          {
            path: 'tooltips',
            name: 'Tooltips',
            component: Tooltips
          }
          ]
        },
        {
          path: 'buttons',
          redirect: '/buttons/buttons',
          name: 'Buttons',
          component: {
            render (c) {
              return c('router-view');
            }
          },
          children: [{
            path: 'standard-buttons',
            name: 'Standard Buttons',
            component: StandardButtons
          },
          {
            path: 'button-groups',
            name: 'Button Groups',
            component: ButtonGroups
          },
          {
            path: 'dropdowns',
            name: 'Dropdowns',
            component: Dropdowns
          },
          {
            path: 'social-buttons',
            name: 'Social Buttons',
            component: SocialButtons
          }
          ]
        },
        {
          path: 'icons',
          redirect: '/icons/font-awesome',
          name: 'Icons',
          component: {
            render (c) {
              return c('router-view');
            }
          },
          children: [{
            path: 'flags',
            name: 'Flags',
            component: Flags
          },
          {
            path: 'font-awesome',
            name: 'Font Awesome',
            component: FontAwesome
          },
          {
            path: 'simple-line-icons',
            name: 'Simple Line Icons',
            component: SimpleLineIcons
          }
          ]
        },
        {
          path: 'notifications',
          redirect: '/notifications/alerts',
          name: 'Notifications',
          component: {
            render (c) {
              return c('router-view');
            }
          },
          children: [{
            path: 'alerts',
            name: 'Alerts',
            component: Alerts
          },
          {
            path: 'badges',
            name: 'Badges',
            component: Badges
          },
          {
            path: 'modals',
            name: 'Modals',
            component: Modals
          }
        ]
      }

    ]
  }]
});
