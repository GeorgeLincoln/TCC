import ApiService from '../ApiService'
import axios from 'axios'
import toastr from 'toastr'

export default class AulasService extends ApiService {
  constructor() {
    super('aulas');
    
  }
  vincular(newObject, id, filter = {}) {
    let params = {
      params: filter,
    };
    return new Promise((resolve, reject) => {
      axios
        .put(this.url + 'vinculacao' + '/' + id, newObject, params)
        .then(res => {
          toastr.success('Vinculação realizada com sucesso!');
          resolve(res.data);
        })
        .catch(err => {
          reject(err.response);
          toastr.error('Falha ao vincular!')
        });
    });
  }
}
