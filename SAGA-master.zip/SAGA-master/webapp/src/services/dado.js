import { http } from './config';

export default {
  listar: filter => {
    return http.get('dado' + filter).catch(e => {
      this.errors.push(e);
    });
  }
};
