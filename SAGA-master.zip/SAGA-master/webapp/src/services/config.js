import axios from 'axios';

export const http = axios.create({
  baseURL: 'http://10.70.80.40:8080/',
  headers: {
    'Content-type': 'application/json'
  }
});
