import { http } from './config';

export default {
  listar: () => {
    return http.get('tipo_tanque').catch(e => {
      this.errors.push(e);
    });
  }
};
