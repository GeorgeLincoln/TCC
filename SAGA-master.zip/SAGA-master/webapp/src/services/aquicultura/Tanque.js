import ApiService from '../ApiService'

export default class TanqueService extends ApiService {
  constructor () {
    super('tanque')
  }
}
