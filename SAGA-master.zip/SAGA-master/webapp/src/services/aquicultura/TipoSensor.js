import ApiService from '../ApiService'

export default class TipoSensorService extends ApiService {
  constructor () {
    super('tipo_sensor')
  }
}
