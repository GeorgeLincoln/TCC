import ApiService from '../ApiService'

export default class DescDadoService extends ApiService {
  constructor () {
    super('desc_dado')
  }
}
