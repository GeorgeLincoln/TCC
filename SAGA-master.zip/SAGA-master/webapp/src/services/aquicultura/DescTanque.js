import ApiService from '../ApiService'

export default class DescTanqueService extends ApiService {
  constructor () {
    super('desc_tanque')
  }
}
