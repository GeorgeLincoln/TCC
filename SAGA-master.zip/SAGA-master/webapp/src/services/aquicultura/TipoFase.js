import ApiService from '../ApiService'

export default class TipoFaseService extends ApiService {
  constructor () {
    super('tipo_fase')
  }
}
