import ApiService from '../ApiService'

export default class TipoDadoService extends ApiService {
  constructor () {
    super('tipo_dado')
  }
}
