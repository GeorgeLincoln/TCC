import ApiService from '../ApiService'

export default class DadoService extends ApiService {
  constructor () {
    super('dado')
  }
}
