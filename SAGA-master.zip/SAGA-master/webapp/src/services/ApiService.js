import axios from 'axios'
import * as settings from '@/settings'

import toastr from 'toastr'
import messages from '@/utils/messages'

import Mgr from '@/services/SecurityService'

const baseUrl = settings.baseUrl + 'api/'

export default class ApiService {
  constructor (serviceName) {
    this.serviceName = serviceName
    if (serviceName != null && serviceName !== undefined) {
      this.url = baseUrl + this.serviceName + '/'
    } else {
      this.url = baseUrl
    }
  }

  async defineHeaderAxios () {
    // DEV and SEC
    if (process.env.npm_lifecycle_event === 'sec') {
      var user = new Mgr()

      await user.getUser().then(
        sucess => {
          axios.defaults.headers.common['Authorization'] = 'Bearer ' + sucess.access_token
        }, err => {
          console.log(err)
        })
    }
  }

  // GetAll
  async getAll (filter = {}, sub = '') {
    let params = {
      params: filter
    }
    await this.defineHeaderAxios()
    return axios
      .get(this.url + sub, params)
      .then(response => response.data)
      .catch(err => {
        console.log(err);
        toastr.error('Falha ao carregar os dados');
      })
  }

  async getById (id, sub = '') {
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .get(this.url + sub + id)
        .then(res => resolve(res.data))
        .catch(err => {
          reject(err.response)
          toastr.error('Erro!', err.response)
        })
    })
  }

  async create (newObject = {}, sub = '') {
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .post(this.url + sub, newObject)
        .then(res => {
          resolve(res.data)
          toastr.success(messages.create_success)
        })
        .catch(err => {
          reject(err.response)
          toastr.error(messages.create_error)
        })
    })
  }

  async update (newObject, id, sub = '') {
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .put(this.url + sub + id, newObject)
        .then(res => {
          resolve(res.data)
          toastr.success(messages.update_success)
        })
        .catch(err => {
          reject(err.response)
          toastr.error(messages.update_error)
        })
    })
  }

  async delete (id, sub = '') {
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .delete(this.url + sub + id)
        .then(res => {
          resolve(res.data)
          toastr.success(messages.delete_success)
        })
        .catch(err => {
          // if (err.response.data) {
            // toastr.error(err.response.data)
          // } else {
            toastr.error(messages.delete_error)
          // }
          reject(err.response)
        })
    })
  }

  count () {}

  async uploadBase64 (base64string, id, sub = 'upload/') {
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .put(this.url + sub + id, {
          file: base64string
        })
        .then(res => {
          resolve(res.data)
          toastr.success('Imagem enviada!')
        })
        .catch(err => {
          reject(err.response)
          toastr.error('Erro ao enviar:' + err.response);
        })
    })
  }

  async uploadCsv (csv, sub = '') {
    let config = {
      headers: {
        'Content-Type': 'text/csv'
      }
    }
    await this.defineHeaderAxios()
    return new Promise((resolve, reject) => {
      axios
        .post(this.url + sub + '/import', csv, config)
        .then(res => {
          console.log(res)
          resolve(res.data)
          if (res.status === 200) {
            toastr.success(messages.default_success)
          } else if (res.status === 400 || res.status === 404 || res.status === 500) {
            toastr.error('Erro ao fazer o upload')
          }
        })
        .catch(err => {
          console.log('ERROR', err.response)
          reject(err.response)

          toastr.error('Erro ao fazer o upload')
        })
    })
  }
}
