
import ApiService from '../ApiService'

export default class PessoasService extends ApiService {
  constructor () {
    super('pessoas')
  }

  async createPessoa (newObject = {}) {
    return this.create(newObject, 'tipo')
  }

  async updatePessoa (newObject = {}, id) {
    return this.update(newObject, id, 'tipo/')
  }
}
