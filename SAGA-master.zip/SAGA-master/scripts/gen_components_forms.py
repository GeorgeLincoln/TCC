# coding: utf-8
import os

# subdominios em dominios
subdomains = ['Academico', 'Administrativo', 'Comum']

def extract_entity(path, file):
    content = []
    full_path = os.path.join(path, file)
    if os.path.exists(full_path):
        f = open(full_path, 'r')
        for line in f.readlines():
            if 'public' in line \
            and not 'virtual' in line \
            and not 'DeletedAt' in line \
            and not '(' in line \
            and not 'id' in line \
            and not line == '':
                line = line.replace('{ get; set; }', '')
                line = line.replace('public', '')
                line = line.replace('get', '')
                line = line.replace('set', '')
                line = line.replace('{', '')
                line = line.replace('}', '')
                line = line.replace('IEntity', '')
                line = line.replace(':', '') 
                line = line.replace(';', '')
                line = line.replace('class', '')  
                line = line.replace('\n', '')
                line = line.replace('string', '')
                line = line.replace('Nullable', '')
                line = line.replace('?', '')
                line = line.replace('>', '')
                line = line.replace('<', '')
                line = line.replace('int', '')
                line = line.replace('System.DateTime', '') 
                line = line.replace('Datetime', '')
                line = line.replace('short', '')
                line = line.replace('DateTime', '')
                line = line.replace('short', '')
                if line.strip().replace(' ', '').replace('\t', '') == 'Id':
                    continue
                content.append(line)
        f.close()

        result = ''
        variable_name = 'x'
        for i, line in enumerate(content):
            if i == 0:
                continue
            else:
                # line eh o nome do campo
                line = line.replace(' ', '')
                
                # prediz o tipo do campo, para imprimir o controle apropriado
                tipo = ''
                if line.lower()[-2:] == 'id':
                    campo = '''
                <div class="form-group">
                    <label for="{1}">{0}</label>
                    <select class="form-control" id="{1}">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>\n'''.format(line, line.lower())
                    result +=  campo   
                elif 'hora' in line.lower() or 'datahora' in line.lower() or 'data' in line.lower():
                    campo = '''
                <div class="form-group">
                    <label for="{1}">{0}</label>
                    <input type="datetime-local" class="form-control" id="{1}" placeholder="{0}">
                </div>\n'''.format(line, line.lower())
                    result +=  campo
                else:
                    campo = '''
                <div class="form-group">
                    <label for="{1}">{0}</label>
                    <input type="text" class="form-control" id="{1}" placeholder="{0}">
                </div>\n'''.format(line, line.lower())
                    result +=  campo



        return result

def getEntities(path):
    entities = list()
    d = dict()
    count = 0
    for file in os.listdir(path):
        if 'Entity' in file:
            continue
        key = file.replace('.cs', '')
        d[key] = extract_entity(path, file)
        count = count + 1
    return d

def get_instance_samples( domain_path):
    d = {}
    for subdomain in subdomains:
        d_temp = getEntities('{0}/{1}/Entities'.format(domain_path, subdomain)) 
        d = dict(d, **d_temp)
    return d

if __name__ == "__main__":
    domain_path = 'TitBackend/src/Domain/'
    samples = get_instance_samples( domain_path)
    f_instances = open('temp_frontend_forms/output_instances.txt', 'w')
    
    for instance in samples:
        f_instances.writelines('<div id="div{0}">\n'.format(instance))
        f_instances.writelines('    <h1>{0}</h1>\n'.format(instance))
        f_instances.writelines('    <form id="form{0}">'.format(instance))
        f_instances.writelines(samples[instance])
        f_instances.writelines('    </form>\n\n')
        f_instances.writelines('</div>\n\n')
    print('done.')