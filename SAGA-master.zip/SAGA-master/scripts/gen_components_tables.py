# coding: utf-8
import os

# subdominios em dominios
temp_folder = 'gen_components_tables'
subdomains = ['Academico', 'Administrativo', 'Comum']
domain_path = '../../TitBackend/src/Domain/'

uncapitalize = lambda s: s[:1].lower() + s[1:] if s else ''

def extract_entity(path, file):
    content = []
    full_path = os.path.join(path, file)
    if os.path.exists(full_path):
        f = open(full_path, 'r')
        for line in f.readlines():
            if 'public' in line \
            and not 'virtual' in line \
            and not 'DeletedAt' in line \
            and not '(' in line \
            and not 'id' in line \
            and not line == '':
                line = line.replace('{ get; set; }', '')
                line = line.replace('public', '')
                line = line.replace('get', '')
                line = line.replace('set', '')
                line = line.replace('{', '')
                line = line.replace('}', '')
                line = line.replace('IEntity', '')
                line = line.replace(':', '') 
                line = line.replace(';', '')
                line = line.replace('class', '')  
                line = line.replace('\n', '')
                line = line.replace('string', '')
                line = line.replace('Nullable', '')
                line = line.replace('?', '')
                line = line.replace('>', '')
                line = line.replace('<', '')
                line = line.replace('int', '')
                line = line.replace('System.DateTime', '') 
                line = line.replace('Datetime', '')
                line = line.replace('short', '')
                line = line.replace('DateTime', '')
                line = line.replace('short', '')
                #if line.strip().replace(' ', '').replace('\t', '') == 'Id':
                #    continue
                line = line.replace(' ', '')
                content.append(line)
        f.close()

        result = ''
        result += '        <thead>\n'
        result += '            <tr>\n'
        for i, campo in enumerate(content):
            if i == 0:
                continue    
            result +=  '                <td>{0}</td>\n'.format(campo) 
        result += '            </tr>\n'
        result += '        </thead>\n'

        result += '        <tbody>\n'
        result += '            <tr v-for="row in data" v-bind:key="row.id">\n'
        for i, line in enumerate(content):
            if i == 0:
                continue
            attrb = uncapitalize(line.replace(' ',''))  
            result +=  '                <td>{{{{ row.{0} }}}}</td>\n'.format(attrb)

        result +=  '                <td><a class="fa fa-edit" href="#"></a></td>\n'
        result +=  '                <td><a class="fa fa-trash"  href="#"></a></td>\n'

        result += '            </tr>\n'
        result += '        </tbody>\n'

        return result

def getEntities(path):
    entities = list()
    d = dict()
    count = 0
    for file in os.listdir(path):
        if 'Entity' in file:
            continue
        key = file.replace('.cs', '')
        d[key] = extract_entity(path, file)
        count = count + 1
    return d

def get_instance_samples( domain_path):
    samples = {}
    
    for subdomain in subdomains:
        samples[subdomain] = {}

    for subdomain in subdomains:
        d_temp = getEntities('{0}/{1}/Entities'.format(domain_path, subdomain)) 
        samples[subdomain] = dict(samples[subdomain], **d_temp)
    return samples

def create_temp_folder():
    
    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

if __name__ == "__main__":
    create_temp_folder()
    samples = get_instance_samples( domain_path)
    f_instances = open(os.path.join(temp_folder, 'gen_components_tables.txt'), 'w')
    for domain in samples:
        for instance in samples[domain]:
            f_instances.writelines('<div id="div{0}">\n'.format(instance))
            f_instances.writelines('    <table id="table{0}" class="table">\n'.format(instance))
            f_instances.writelines(samples[domain][instance])
            f_instances.writelines('    </table>\n')
            f_instances.writelines('</div>\n\n')
    print('done.')