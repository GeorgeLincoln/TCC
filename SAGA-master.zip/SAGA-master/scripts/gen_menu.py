# coding: utf-8
import os

# subdominios em dominios
temp_folder = 'gen_components_menu'
subdomains = ['acad', 'admin', 'comum']
domain_path = '../../Tit-Frontend/new/src/router/'

uncapitalize = lambda s: s[:1].lower() + s[1:] if s else ''

def extract_entity(path, file):
    content = []
    full_path = os.path.join(path, file)
    if os.path.exists(full_path):
        f = open(full_path, 'r')
        for line in f.readlines():
            pass
        f.close()
        return '???'

def getItensMenu(path):
    entities = list()
    d = dict()
    count = 0
    print('')
    for file in os.listdir(path):
        key = file.replace('.js', '')
        
        d[key] = extract_entity(path, file)
        count = count + 1
    return d

def get_instance_samples(domain_path):
    samples = {}
    
    for subdomain in subdomains:
        samples[subdomain] = {}

    for subdomain in subdomains:
        print('subdomain:', subdomain)
        d_temp = getItensMenu('{0}/{1}'.format(domain_path, subdomain)) 
        samples[subdomain] = dict(samples[subdomain], **d_temp)
    return samples

def create_temp_folder():
    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

if __name__ == "__main__":
    create_temp_folder()
    samples = get_instance_samples( domain_path)
    f_instances = open(os.path.join(temp_folder, 'gen_menu.txt'), 'w')
    for domain in samples:
        f_instances.writelines('\n\n//{0}'.format(domain))
        for instance in samples[domain]:
            f_instances.writelines('\t{{ titulo:\'{1}\', href:\'/{0}/{1}/table\' }},\n'.format(domain, instance))
            #f_instances.writelines('    <table id="table{0}" class="table">\n'.format(instance))
            #f_instances.writelines(samples[domain][instance])
            #f_instances.writelines('    </table>\n')
            #f_instances.writelines('</div>\n\n')
    print('done.')