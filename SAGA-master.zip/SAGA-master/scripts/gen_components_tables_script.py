# coding: utf-8
import os,sys, re

# template para script
template = """
<script>
import Service  from '@/services/DOMAIN/ENTITYsService'

export default {
  data() {
    return {
      data: [],
      errors: [],
    }
  },

  created(){
    let service = new Service();

    let promise = service.getAll({
      Page: 1,
      PageSize: 2,
      SortBy: 'id',
      IsAscending: false,
    });
    promise.then(data => this.data = data);
  }
}
</script>
"""

# subdominios em dominios
temp_folder = 'gen_components_tables'
subdomains = ['Academico', 'Administrativo', 'Comum']
map = {'Academico':'acad', 'Administrativo':'admin', 'Comum': 'comum'}
domain_path = '../../TitBackend/src/Domain/'

uncapitalize = lambda s: s[:1].lower() + s[1:] if s else ''


def multiple_replacer(*key_values):
    replace_dict = dict(key_values)
    replacement_function = lambda match: replace_dict[match.group(0)]
    pattern = re.compile("|".join([re.escape(k) for k, v in key_values]), re.M)
    return lambda string: pattern.sub(replacement_function, string)

def multiple_replace(string, *key_values):
    return multiple_replacer(*key_values)(string)


def extract_entity(path, file):
    content = []
    full_path = os.path.join(path, file)
    if os.path.exists(full_path):
        f = open(full_path, 'r')
        for line in f.readlines():
            if 'public' in line \
            and not 'virtual' in line \
            and not 'DeletedAt' in line \
            and not '(' in line \
            and not 'id' in line \
            and not line == '':
                line = line.replace('{ get; set; }', '')
                line = line.replace('public', '')
                line = line.replace('get', '')
                line = line.replace('set', '')
                line = line.replace('{', '')
                line = line.replace('}', '')
                line = line.replace('IEntity', '')
                line = line.replace(':', '') 
                line = line.replace(';', '')
                line = line.replace('class', '')  
                line = line.replace('\n', '')
                line = line.replace('string', '')
                line = line.replace('Nullable', '')
                line = line.replace('?', '')
                line = line.replace('>', '')
                line = line.replace('<', '')
                line = line.replace('int', '')
                line = line.replace('System.DateTime', '') 
                line = line.replace('Datetime', '')
                line = line.replace('short', '')
                line = line.replace('DateTime', '')
                line = line.replace('short', '')
                #if line.strip().replace(' ', '').replace('\t', '') == 'Id':
                #    continue
                line = line.replace(' ', '')
                content.append(line)
        f.close()

        result = ''
        result += '        <thead>\n'
        result += '            <tr>\n'
        for i, campo in enumerate(content):
            if i == 0:
                continue    
            result +=  '                <td>{0}</td>\n'.format(campo) 
        result += '            </tr>\n'
        result += '        </thead>\n'

        result += '        <tbody>\n'
        result += '            <tr v-for="row in data" v-bind:key="row.id">\n'
        for i, line in enumerate(content):
            if i == 0:
                continue
            attrb = uncapitalize(line.replace(' ',''))  
            result +=  '                <td>{{{{ row.{0} }}}}</td>\n'.format(attrb)

        result +=  '                <td><a class="fa fa-edit" href="#"></a></td>\n'
        result +=  '                <td><a class="fa fa-trash"  href="#"></a></td>\n'

        result += '            </tr>\n'
        result += '        </tbody>\n'

        return result

def getEntities(path):
    entities = list()
    d = dict()
    count = 0
    for file in os.listdir(path):
        if 'Entity' in file:
            continue
        key = file.replace('.cs', '')
        d[key] = extract_entity(path, file)
        count = count + 1
    return d

def get_instance_samples( domain_path):
    samples = {}
    
    for subdomain in subdomains:
        samples[subdomain] = {}

    for subdomain in subdomains:
        d_temp = getEntities('{0}/{1}/Entities'.format(domain_path, subdomain)) 
        samples[subdomain] = dict(samples[subdomain], **d_temp)
    return samples

def create_temp_folder():
    
    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

if __name__ == "__main__":
    create_temp_folder()
    samples = get_instance_samples( domain_path)
    f_instances = open(os.path.join(temp_folder, 'gen_components_tables_script.txt'), 'w')
    for domain in samples:
        for instance in samples[domain]:
            name = samples[domain][instance]
            replacements = ("DOMAIN", map[domain]), ('ENTITY', instance)
            s = multiple_replace(template, *replacements)
            f_instances.writelines(s)
    print('done.')
    f_instances.close()